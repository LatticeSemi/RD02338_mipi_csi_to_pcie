/* SPDX-License-Identifier: MIT */
/*   ==================================================================

    >>>>>>>>>>>>>>>>>>>>>>> COPYRIGHT NOTICE <<<<<<<<<<<<<<<<<<<<<<<<<
    ------------------------------------------------------------------
    Copyright (c) 2026 by Lattice Semiconductor Corporation
    ALL RIGHTS RESERVED
    ------------------------------------------------------------------

    DISCLAIMER:

   LATTICE MAKES NO WARRANTIES ON THIS FILE OR ITS CONTENTS,
   WHETHER EXPRESSED, IMPLIED, STATUTORY,
   OR IN ANY PROVISION OF THE LATTICE PROPEL LICENSE AGREEMENT OR
   COMMUNICATION WITH LICENSEE,
   AND LATTICE SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
   MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
   LATTICE DOES NOT WARRANT THAT THE FUNCTIONS CONTAINED HEREIN WILL MEET
   LICENSEE 'S REQUIREMENTS, OR THAT LICENSEE' S OPERATION OF ANY DEVICE,
   SOFTWARE OR SYSTEM USING THIS FILE OR ITS CONTENTS WILL BE
   UNINTERRUPTED OR ERROR FREE,
   OR THAT DEFECTS HEREIN WILL BE CORRECTED.
   LICENSEE ASSUMES RESPONSIBILITY FOR SELECTION OF MATERIALS TO ACHIEVE
   ITS INTENDED RESULTS, AND FOR THE PROPER INSTALLATION, USE,
   AND RESULTS OBTAINED THEREFROM.
   LICENSEE ASSUMES THE ENTIRE RISK OF THE FILE AND ITS CONTENTS PROVING
   DEFECTIVE OR FAILING TO PERFORM PROPERLY AND IN SUCH EVENT,
   LICENSEE SHALL ASSUME THE ENTIRE COST AND RISK OF ANY REPAIR, SERVICE,
   CORRECTION,
   OR ANY OTHER LIABILITIES OR DAMAGES CAUSED BY OR ASSOCIATED WITH THE
   SOFTWARE.IN NO EVENT SHALL LATTICE BE LIABLE TO ANY PARTY FOR DIRECT,
   INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES,
   INCLUDING LOST PROFITS,
   ARISING OUT OF THE USE OF THIS FILE OR ITS CONTENTS,
   EVEN IF LATTICE HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
   LATTICE 'S SOLE LIABILITY, AND LICENSEE' S SOLE REMEDY,
   IS SET FORTH ABOVE.
   LATTICE DOES NOT WARRANT OR REPRESENT THAT THIS FILE,
   ITS CONTENTS OR USE THEREOF DOES NOT INFRINGE ON THIRD PARTIES'
   INTELLECTUAL PROPERTY RIGHTS, INCLUDING ANY PATENT. IT IS THE USER' S
   RESPONSIBILITY TO VERIFY THE USER SOFTWARE DESIGN FOR CONSISTENCY AND
   FUNCTIONALITY THROUGH THE USE OF FORMAL SOFTWARE VALIDATION METHODS.
    ------------------------------------------------------------------

    ================================================================== */

/**
 * @file lsc_pcie_if.h
 * @brief User-space C++ interface to the Lattice PCIe DMA character device driver.
 */

#ifndef __LSC_PCIE_IF_H__
#define __LSC_PCIE_IF_H__

#include <unistd.h>
#include <syslog.h>
#include <iostream>
#include <cstdint>
#include <vector>
#include <exception>

/* Include common definitions shared with kernel driver */
#include "../include/lsc_pcie.h"

using namespace std;

/* User-space specific definitions */
#define MAX_DEV_FILENAME_SIZE 1024
#define MAX_FUNCTION_NAME_SIZE 64

#define ERRORSTR(a) syslog(LOG_ERR, "%s", a); cout<<a

#define LINE_BUFFER_SIZE 256

#define PCI_CFG_START 0x00
#define PCI_CFG_END 0x40
#define PCI_CAP_START 0x40
#define PCI_CAP_END 0xc0

typedef int HANDLE;

/**
 * @class PCIEDMA_IF
 * @brief User-space interface to the Lattice PCIe DMA character device.
 *
 * Opens /dev/<device_name> and wraps driver ioctls for BAR MMIO access,
 * PCI configuration space, user MSI vector setup, and DMA operations.
 * Implementation is in lsc_pcie_if.cpp.
 */
class PCIEDMA_IF
{

public:
	/**
	 * @brief Open the driver device and query PCI resources.
	 * @param pDeviceName Base device name (opens /dev/pDeviceName). Must be non-NULL and non-empty.
	 * @throws PCIEDMA_IF_Error on invalid name, open failure, or IOCTL_PCIE_GET_RESOURCES failure.
	 */
	PCIEDMA_IF(const char *pDeviceName);

	/** @brief Close the device handle if open. */
	~PCIEDMA_IF();

	/** @brief Return the open device file descriptor, or -1 if closed. */
	int getFileDescriptor() const { return hDev; }

	/**
	 * @brief Copy the 256-byte PCI configuration image from the driver.
	 * @param pCfg Output buffer (at least 256 bytes). Must not be NULL.
	 * @return true on success, false if IOCTL_PCIE_GET_RESOURCES fails.
	 */
	bool getPCIConfigRegs(uint8_t *pCfg);

	/**
	 * @brief Query the FPGA IP operating mode.
	 * @return deviceMode_t value (as int) from IOCTL_PCIE_GET_DEVICE_MODE.
	 * @throws PCIEDMA_IF_Error if the ioctl fails.
	 */
	int getPCIeDeviceMode();

	/**
	 * @brief Retrieve BAR and PCI resource information from the driver.
	 * @param pInfo Optional output; when non-NULL, receives a copy of PCIResourceInfo.
	 * @return true on success, false if IOCTL_PCIE_GET_RESOURCES fails.
	 */
	bool getPCIBarInfo(struct PCIResourceInfo *pInfo);

	/**
	 * @brief Program a user interrupt MSI vector routing entry.
	 * @param usr_int User interrupt index (0..15).
	 * @param vec_val MSI vector number (0..0x1F).
	 * @throws PCIEDMA_IF_Error if IOCTL_PCIE_USR_VEC_ALLOC fails.
	 */
	void setUserIntMSIVector(uint8_t usr_int, uint8_t vec_val);

	/** @brief Read 8 bits from BAR0 at @p offset. @throws PCIEDMA_IF_Error on ioctl failure. */
	uint8_t readReg8(uint32_t offset);
	/** @brief Write 8 bits to BAR0 at @p offset. @throws PCIEDMA_IF_Error on ioctl failure. */
	void writeReg8(uint32_t offset, uint8_t val);
	/** @brief Read 16 bits from BAR0 at @p offset. @throws PCIEDMA_IF_Error on ioctl failure. */
	uint16_t readReg16(uint32_t offset);
	/** @brief Write 16 bits to BAR0 at @p offset. @throws PCIEDMA_IF_Error on ioctl failure. */
	void writeReg16(uint32_t offset, uint16_t val);
	/** @brief Read 32 bits from BAR0 at @p offset. @throws PCIEDMA_IF_Error on ioctl failure. */
	uint32_t readReg32(uint32_t offset);
	/** @brief Write 32 bits to BAR0 at @p offset. @throws PCIEDMA_IF_Error on ioctl failure. */
	void writeReg32(uint32_t offset, uint32_t val);
	/** @brief Read 64 bits from BAR0 at @p offset. @throws PCIEDMA_IF_Error on ioctl failure. */
	uint64_t readReg64(uint32_t offset);
	/** @brief Write 64 bits to BAR0 at @p offset. @throws PCIEDMA_IF_Error on ioctl failure. */
	void writeReg64(uint32_t offset, uint64_t val);

	/** @brief Read 8 bits from @p bar_num at @p offset. @throws PCIEDMA_IF_Error on ioctl failure. */
	uint8_t read8(uint8_t bar_num, uint32_t offset);
	/** @brief Write 8 bits to @p bar_num at @p offset. @throws PCIEDMA_IF_Error on ioctl failure. */
	void write8(uint8_t bar_num, uint32_t offset, uint8_t val);
	/** @brief Read 16 bits from @p bar_num at @p offset. @throws PCIEDMA_IF_Error on ioctl failure. */
	uint16_t read16(uint8_t bar_num, uint32_t offset);
	/** @brief Write 16 bits to @p bar_num at @p offset. @throws PCIEDMA_IF_Error on ioctl failure. */
	void write16(uint8_t bar_num, uint32_t offset, uint16_t val);
	/** @brief Read 32 bits from @p bar_num at @p offset. @throws PCIEDMA_IF_Error on ioctl failure. */
	uint32_t read32(uint8_t bar_num, uint32_t offset);
	/** @brief Write 32 bits to @p bar_num at @p offset. @throws PCIEDMA_IF_Error on ioctl failure. */
	void write32(uint8_t bar_num, uint32_t offset, uint32_t val);
	/** @brief Read 64 bits from @p bar_num at @p offset. @throws PCIEDMA_IF_Error on ioctl failure. */
	uint64_t read64(uint8_t bar_num, uint32_t offset);
	/** @brief Write 64 bits to @p bar_num at @p offset. @throws PCIEDMA_IF_Error on ioctl failure. */
	void write64(uint8_t bar_num, uint32_t offset, uint64_t val);

	/** @brief Read 8 bits from PCI config space at @p offset. @throws PCIEDMA_IF_Error on ioctl failure. */
	uint8_t readConfig8(uint32_t offset);
	/** @brief Write 8 bits to PCI config space at @p offset. @throws PCIEDMA_IF_Error on ioctl failure. */
	void writeConfig8(uint32_t offset, uint8_t val);
	/** @brief Read 16 bits from PCI config space at @p offset. @throws PCIEDMA_IF_Error on ioctl failure. */
	uint16_t readConfig16(uint32_t offset);
	/** @brief Write 16 bits to PCI config space at @p offset. @throws PCIEDMA_IF_Error on ioctl failure. */
	void writeConfig16(uint32_t offset, uint16_t val);
	/** @brief Read 32 bits from PCI config space at @p offset. @throws PCIEDMA_IF_Error on ioctl failure. */
	uint32_t readConfig32(uint32_t offset);
	/** @brief Write 32 bits to PCI config space at @p offset. @throws PCIEDMA_IF_Error on ioctl failure. */
	void writeConfig32(uint32_t offset, uint32_t val);

	/** @brief Read a block of @p len 8-bit values from BAR @p bar_num memory at @p offset. @throws PCIEDMA_IF_Error on failure. */
	bool readBlock8(uint8_t bar_num, uint32_t offset, std::vector<uint8_t> &val,
			size_t len, bool incAddr = true);
	/** @brief Write a block of @p len 8-bit values to BAR @p bar_num memory at @p offset. @throws PCIEDMA_IF_Error on failure. */
	bool writeBlock8(uint8_t bar_num, uint32_t offset,
			 const std::vector<uint8_t> &val, size_t len,
			 bool incAddr = true);
	/** @brief Read a block of @p len 16-bit values from BAR @p bar_num memory at @p offset. @throws PCIEDMA_IF_Error on failure. */
	bool readBlock16(uint8_t bar_num, uint32_t offset, std::vector<uint16_t> &val,
			 size_t len, bool incAddr = true);
	/** @brief Write a block of @p len 16-bit values to BAR @p bar_num memory at @p offset. @throws PCIEDMA_IF_Error on failure. */
	bool writeBlock16(uint8_t bar_num, uint32_t offset,
			  const std::vector<uint16_t> &val, size_t len,
			  bool incAddr = true);
	/** @brief Read a block of @p len 32-bit values from BAR @p bar_num memory at @p offset. @throws PCIEDMA_IF_Error on failure. */
	bool readBlock32(uint8_t bar_num, uint32_t offset, std::vector<uint32_t> &val,
			 size_t len, bool incAddr = true);
	/** @brief Write a block of @p len 32-bit values to BAR @p bar_num memory at @p offset. @throws PCIEDMA_IF_Error on failure. */
	bool writeBlock32(uint8_t bar_num, uint32_t offset,
			  const std::vector<uint32_t> &val, size_t len,
			  bool incAddr = true);
	/** @brief Read a block of @p len 64-bit values from BAR @p bar_num memory at @p offset. @throws PCIEDMA_IF_Error on failure. */
	bool readBlock64(uint8_t bar_num, uint32_t offset, std::vector<uint64_t> &val,
			 size_t len, bool incAddr = true);
	/** @brief Write a block of @p len 64-bit values to BAR @p bar_num memory at @p offset. @throws PCIEDMA_IF_Error on failure. */
	bool writeBlock64(uint8_t bar_num, uint32_t offset,
			  const std::vector<uint64_t> &val, size_t len,
			  bool incAddr = true);

	/**
	 * @brief Build DMA descriptors for a user buffer (IOCTL_PCIEDMA_GEN_DESC).
	 * @param arg [in] dma_ubuf_ioctl_arg with buffer addresses and transfer
	 *        parameters populated (see dma_ubuf_ioctl_arg in lsc_pcie.h).
	 * @return 0 on success.
	 * @throws PCIEDMA_IF_Error on ioctl failure.
	 */
	int dmaGenDescriptor(struct dma_ubuf_ioctl_arg *arg);

	/**
	 * @brief Start DMA without waiting for completion (IOCTL_PCIEDMA_START).
	 * @param direction DMA_DIR_H2F or DMA_DIR_F2H.
	 * @return 0 on success.
	 * @throws PCIEDMA_IF_Error on ioctl failure.
	 */
	int dmaStart(uint8_t direction);

	/**
	 * @brief Stop a running DMA transfer (IOCTL_PCIEDMA_STOP).
	 * @param direction DMA_DIR_H2F or DMA_DIR_F2H.
	 * @return 0 on success.
	 * @throws PCIEDMA_IF_Error on ioctl failure.
	 */
	int dmaStop(uint8_t direction);

	/**
	 * @brief Start DMA and block until completion or timeout (IOCTL_PCIEDMA_START_WAIT_COMPLETION).
	 * @param status_arg [in] dir, timeout_ms (0 = driver default 1000 ms).
	 *        [out] status_reg, completed_desc_cnt, expected_desc_cnt, dma_error on success.
	 * @return 0 on success.
	 * @throws PCIEDMA_IF_Error on ioctl failure (e.g. -EBUSY, -ETIME).
	 */
	int dmaStartWaitCompletionWithStatus(struct dma_status_ioctl_arg *status_arg);

	/**
	 * @brief Poll current DMA channel status (IOCTL_PCIEDMA_STATUS_CHECK).
	 * @param status_arg [in] dir. [out] status_reg, completed_desc_cnt,
	 *        expected_desc_cnt, dma_error on success.
	 * @return 0 on success.
	 * @throws PCIEDMA_IF_Error on ioctl failure.
	 */
	int dmaStatusGet(struct dma_status_ioctl_arg *status_arg);

	/**
	 * @brief Query descriptor counts for a channel/buffer (IOCTL_PCIEDMA_GET_DESC_INFO).
	 * @param info [in] dir, buf_idx. [out] mapped_nents, total_descriptors,
	 *        ubuf_cnt, circ_buffer_on on success.
	 * @return 0 on success.
	 * @throws PCIEDMA_IF_Error on ioctl failure.
	 */
	int dmaGetDescInfo(struct dma_desc_info_ioctl_arg *info);

	/**
	 * @brief Run kernel-side throughput measurement (IOCTL_PCIEDMA_MEAS_THROUGHPUT).
	 * @param throughput_arg [in] dir, iterations. [out] start_time_in_ns,
	 *        end_time_in_ns on success.
	 * @return 0 on success.
	 * @throws PCIEDMA_IF_Error on ioctl failure.
	 */
	int dmaMeasureThroughput(struct dma_throughput_ioctl_arg *throughput_arg);

	/**
	 * @brief Release driver DMA state for a direction (IOCTL_PCIEDMA_CLEANUP).
	 * @param direction DMA_DIR_H2F or DMA_DIR_F2H.
	 * @return 0 on success.
	 * @throws PCIEDMA_IF_Error on ioctl failure.
	 */
	int dmaCleanup(uint8_t direction);

protected:
	/** Open device file descriptor, or -1 when closed. */
	HANDLE hDev;
	/** PCI resource snapshot from constructor IOCTL_PCIE_GET_RESOURCES. */
	struct PCIResourceInfo PCIinfo;

private:

};


/**
 * @class PCIEDMA_IF_Error
 * @brief Fatal error exception for PCIEDMA_IF operations.
 *
 * Thrown when an ioctl or device open fails and the caller cannot continue.
 * Inspect what() for a short error string.
 */
class PCIEDMA_IF_Error : public exception
{
public:
	/**
	 * @brief Construct with a caller-owned error message string.
	 * @param s NUL-terminated error message (stored by pointer; must remain
	 *          valid for the lifetime of this object).
	 */
	PCIEDMA_IF_Error(char *s) { msg = s; }
	virtual const char *what(void) const throw()
	{
		return (msg);
	}

private:
	/** Pointer to caller-owned error message string. */
	char *msg;

};

#endif /* __LSC_PCIE_IF_H__ */
