// SPDX-License-Identifier: MIT
/*
 * ==================================================================
 *
 * >>>>>>>>>>>>>>>>>>>>> COPYRIGHT NOTICE <<<<<<<<<<<<<<<<<<<<<<<<<
 * ------------------------------------------------------------------
 * Copyright (c) 2019-2024 by Lattice Semiconductor Corporation
 * ALL RIGHTS RESERVED
 * ------------------------------------------------------------------
 *
 * DISCLAIMER:
 *
 * LATTICE MAKES NO WARRANTIES ON THIS FILE OR ITS CONTENTS,
 * WHETHER EXPRESSED, IMPLIED, STATUTORY,
 * OR IN ANY PROVISION OF THE LATTICE PROPEL LICENSE AGREEMENT OR
 * COMMUNICATION WITH LICENSEE,
 * AND LATTICE SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
 * MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
 * LATTICE DOES NOT WARRANT THAT THE FUNCTIONS CONTAINED HEREIN WILL MEET
 * LICENSEE 'S REQUIREMENTS, OR THAT LICENSEE' S OPERATION OF ANY DEVICE,
 * SOFTWARE OR SYSTEM USING THIS FILE OR ITS CONTENTS WILL BE
 * UNINTERRUPTED OR ERROR FREE,
 * OR THAT DEFECTS HEREIN WILL BE CORRECTED.
 * LICENSEE ASSUMES RESPONSIBILITY FOR SELECTION OF MATERIALS TO ACHIEVE
 * ITS INTENDED RESULTS, AND FOR THE PROPER INSTALLATION, USE,
 * AND RESULTS OBTAINED THEREFROM.
 * LICENSEE ASSUMES THE ENTIRE RISK OF THE FILE AND ITS CONTENTS PROVING
 * DEFECTIVE OR FAILING TO PERFORM PROPERLY AND IN SUCH EVENT,
 * LICENSEE SHALL ASSUME THE ENTIRE COST AND RISK OF ANY REPAIR, SERVICE,
 * CORRECTION,
 * OR ANY OTHER LIABILITIES OR DAMAGES CAUSED BY OR ASSOCIATED WITH THE
 * SOFTWARE.IN NO EVENT SHALL LATTICE BE LIABLE TO ANY PARTY FOR DIRECT,
 * INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES,
 * INCLUDING LOST PROFITS,
 * ARISING OUT OF THE USE OF THIS FILE OR ITS CONTENTS,
 * EVEN IF LATTICE HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * LATTICE 'S SOLE LIABILITY, AND LICENSEE' S SOLE REMEDY,
 * IS SET FORTH ABOVE.
 * LATTICE DOES NOT WARRANT OR REPRESENT THAT THIS FILE,
 * ITS CONTENTS OR USE THEREOF DOES NOT INFRINGE ON THIRD PARTIES'
 * INTELLECTUAL PROPERTY RIGHTS, INCLUDING ANY PATENT. IT IS THE USER' S
 * RESPONSIBILITY TO VERIFY THE USER SOFTWARE DESIGN FOR CONSISTENCY AND
 * FUNCTIONALITY THROUGH THE USE OF FORMAL SOFTWARE VALIDATION METHODS.
 * ------------------------------------------------------------------
 *
 * ==================================================================
 */

#ifndef __PCIE_REGS_H__
#define __PCIE_REGS_H__
/*Register Offsets*/
/* Register name, address and offset */

#define INT_MODE_REG				         0x400
#define USR_INT_VEC_P1_REG                   0x40C
#define USR_INT_VEC_P2_REG                   0x410
#define USR_INT_VEC_P3_REG                   0x414
#define USR_INT_VEC_P4_REG                   0x418

#define USRx_INT_VEC                          0x1F

#define GEN_STS_REG                          0x500
#define GEN_STS_DMA_SUPPORT_MASK         0x00000038
#define GEN_STS_DMA_H2F_F2H              0x00000000
#define GEN_STS_DMA_F2H                  0x00000008
#define GEN_STS_DMA_H2F                  0x00000010
#define GEN_STS_DMA_NO_SUP               0x00000018


#define MSIX_0_TABLE_ADDR_LOW                0x8000
#define MSIX_0_TABLE_ADDR_HIGH               0x8004
#define MSIX_0_DATA                          0x8008
#define MSIX_0_MASK                          0x800C

#define MSIX_1_TABLE_ADDR_LOW                0x8010
#define MSIX_1_TABLE_ADDR_HIGH               0x8014
#define MSIX_1_DATA                          0x8018
#define MSIX_1_MASK                          0x801C

#define MSIX_2_TABLE_ADDR_LOW                0x8020
#define MSIX_2_TABLE_ADDR_HIGH               0x8024
#define MSIX_2_DATA                          0x8028
#define MSIX_2_MASK                          0x802C

#define MSIX_3_TABLE_ADDR_LOW                0x8030
#define MSIX_3_TABLE_ADDR_HIGH               0x8034
#define MSIX_3_DATA                          0x8038
#define MSIX_3_MASK                          0x803C

#define MSIX_4_TABLE_ADDR_LOW                0x8040
#define MSIX_4_TABLE_ADDR_HIGH               0x8044
#define MSIX_4_DATA                          0x8048
#define MSIX_4_MASK                          0x804C

#define MSIX_5_TABLE_ADDR_LOW                0x8050
#define MSIX_5_TABLE_ADDR_HIGH               0x8054
#define MSIX_5_DATA                          0x8058
#define MSIX_5_MASK                          0x805C

#define MSIX_6_TABLE_ADDR_LOW                0x8060
#define MSIX_6_TABLE_ADDR_HIGH               0x8064
#define MSIX_6_DATA                          0x8068
#define MSIX_6_MASK                          0x806C

#define MSIX_7_TABLE_ADDR_LOW                0x8070
#define MSIX_7_TABLE_ADDR_HIGH               0x8074
#define MSIX_7_DATA                          0x8078
#define MSIX_7_MASK                          0x807C

#define MSIX_8_TABLE_ADDR_LOW                0x8080
#define MSIX_8_TABLE_ADDR_HIGH               0x8084
#define MSIX_8_DATA                          0x8088
#define MSIX_8_MASK                          0x808C

#define MSIX_9_TABLE_ADDR_LOW                0x8090
#define MSIX_9_TABLE_ADDR_HIGH               0x8094
#define MSIX_9_DATA                          0x8098
#define MSIX_9_MASK                          0x809C

#define MSIX_10_TABLE_ADDR_LOW                0x80A0
#define MSIX_10_TABLE_ADDR_HIGH               0x80A4
#define MSIX_10_DATA                          0x80A8
#define MSIX_10_MASK                          0x80AC

#define MSIX_11_TABLE_ADDR_LOW                0x80B0
#define MSIX_11_TABLE_ADDR_HIGH               0x80B4
#define MSIX_11_DATA                          0x80B8
#define MSIX_11_MASK                          0x80BC

#define MSIX_12_TABLE_ADDR_LOW                0x80C0
#define MSIX_12_TABLE_ADDR_HIGH               0x80C4
#define MSIX_12_DATA                          0x80C8
#define MSIX_12_MASK                          0x80CC

#define MSIX_13_TABLE_ADDR_LOW                0x80D0
#define MSIX_13_TABLE_ADDR_HIGH               0x80D4
#define MSIX_13_DATA                          0x80D8
#define MSIX_13_MASK                          0x80DC

#define MSIX_14_TABLE_ADDR_LOW                0x80E0
#define MSIX_14_TABLE_ADDR_HIGH               0x80E4
#define MSIX_14_DATA                          0x80E8
#define MSIX_14_MASK                          0x80EC

#define MSIX_15_TABLE_ADDR_LOW                0x80F0
#define MSIX_15_TABLE_ADDR_HIGH               0x80F4
#define MSIX_15_DATA                          0x80F8
#define MSIX_15_MASK                          0x80FC




#endif   // #ifndef __PCIE_REGS_H__
