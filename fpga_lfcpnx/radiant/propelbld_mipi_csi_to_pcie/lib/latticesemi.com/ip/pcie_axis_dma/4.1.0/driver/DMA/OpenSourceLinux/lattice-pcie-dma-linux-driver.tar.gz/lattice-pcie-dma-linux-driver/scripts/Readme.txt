To compile app, lib and driver:
Run "sudo ./compile.sh"

To load driver:
Run "sudo ./install_drv.sh"

To unload driver:
Run "sudo ./rm_drv.sh"

To load demo application:
Run "sudo ./exedemo.sh"

