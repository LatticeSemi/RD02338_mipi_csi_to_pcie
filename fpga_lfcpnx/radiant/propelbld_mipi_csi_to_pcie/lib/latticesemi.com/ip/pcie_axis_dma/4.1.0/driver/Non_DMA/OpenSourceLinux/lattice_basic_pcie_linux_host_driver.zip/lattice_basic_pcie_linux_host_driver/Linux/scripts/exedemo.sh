#!/bin/bash

# Function to display usage
usage() {
    echo "Usage: $0 [-c cmd] [-b bar_num] [-o offset] [-s size] [-d data] [-l length]"
    echo "Commands:"
    echo "  cap: Requires no other arguments"
    echo "  rr: Requires -b bar_num -o offset -s size"
    echo "  wr: Requires -b bar_num -o offset -s size -d data"
    exit 1
}

# Initialize optional arguments
cmd=""
bar_num=""
offset=""
size=""
data=""
length=""

# Parse command line arguments
while getopts ":c:b:o:s:d:l:" opt; do
    case $opt in
        c) cmd="$OPTARG"
        ;;
        b) bar_num="$OPTARG"
        ;;
        o) offset="$OPTARG"
        ;;
        s) size="$OPTARG"
        ;; 
        d) data="$OPTARG"
        ;;
        l) length="$OPTARG"
        ;;
        \?) echo "Invalid option -$OPTARG" >&2
            usage
        ;;
        :) echo "Option -$OPTARG requires an argument." >&2
            usage
        ;;
    esac
done

# Validate command and arguments
case $cmd in
    cap)
        echo "Printing Detailed PCI Capabilities"
        ;;
    menu)
        echo "Running Debugger"
        ;;
    rr)
        if [ -z "$bar_num" ] || [ -z "$offset" ] || [ -z "$size" ]; then
            echo "Error: -b bar_num, -o offset, and -s size are required for rb command."
            usage
        fi
        echo "Executing BAR read with bar_num: $bar_num, offset: $offset, size: $size"
        ;;
    wr)
        if [ -z "$bar_num" ] || [ -z "$offset" ] || [ -z "$size" ] || [ -z "$data" ]; then
            echo "Error: -b bar_num, -o offset, -s size, and -d data are required for wb command."
            usage
        fi
        echo "Executing BAR write with bar_num: $bar_num, offset: $offset, size: $size, data: $data"
        ;;
    "")
        echo "No command provided. Running pcie_app with default settings."
        ;;
    *)
        echo "Error: Unknown command '$cmd'."
        usage
        ;;
esac

# Execute the appropriate command
cd ../app_src
case "$cmd" in
    cap)
        ./pcie_app "$cmd"
        ;;
    menu)
        ./pcie_app "$cmd"
        ;;
    rr)
        ./pcie_app "$cmd" "$bar_num" "$offset" "$size"
        ;;
    wr)
        ./pcie_app "$cmd" "$bar_num" "$offset" "$size" "$data"
        ;;
    "")
        ./pcie_app
        usage
        ;;
    *)
        echo "Error: Unknown command '$cmd'."
        usage
        ;;
esac
cd - || { echo "Error: Failed to return to the original directory"; exit 1; }