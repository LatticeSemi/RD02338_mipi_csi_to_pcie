// SPDX-License-Identifier: MIT
/*
 * Lattice Semiconductor PCIe DMA Driver - Character Device Interface
 *
 * Character device creation/destruction, file_operations callbacks (open,
 * release, ioctl, mmap, read, write), and module-level chrdev region and
 * sysfs class management.
 *
 * The cdev layer calls into the core driver (lsc_pcie_core.c) for register I/O
 * and the DMA engine
 * library (lsc_pcie_dma.c) for DMA operations, keeping all VFS /
 * copy_to_user / copy_from_user logic here.
 *
 * Copyright (c) 2026 by Lattice Semiconductor Corporation
 * ALL RIGHTS RESERVED
 */

#include <linux/module.h>
#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/err.h>
#include <linux/uaccess.h>
#include <linux/pci.h>
#include <linux/version.h>
#include <linux/idr.h>
#include "lsc_pcie_core.h"
#include "lsc_pcie_dma.h"
#include "lsc_pcie_cdev.h"

/* Driver-wide (global) cdev state — one instance per loaded module */
static struct class *g_lsc_class;
static dev_t g_devnum;
static DEFINE_IDA(g_ida);

static int lsc_pcie_validate_bar_access(struct lsc_pcie *pBrd, u8 bar_num,
					u32 offset, size_t width)
{
	u64 end = (u64)offset + width;

	if (bar_num >= NUM_BARS) {
		dev_err(&pBrd->pdev->dev, "invalid BAR index %u\n", bar_num);
		return -EINVAL;
	}

	if (!pBrd->ctrlBARaddr[bar_num] || !pBrd->Dev_BARs[bar_num].len) {
		dev_err(&pBrd->pdev->dev, "BAR %u is not mapped\n", bar_num);
		return -ENODEV;
	}

	if (end > pBrd->Dev_BARs[bar_num].len) {
		dev_err(&pBrd->pdev->dev,
			"BAR %u access out of range: offset=0x%x width=%zu len=0x%llx\n",
			bar_num, offset, width, pBrd->Dev_BARs[bar_num].len);
		return -EINVAL;
	}

	return 0;
}

/* Enforce single-open and attach board context to filp->private_data. */
static int lsc_pcie_cdev_open(struct inode *inode, struct file *filp)
{
	struct lsc_cdev *lcdev = container_of(inode->i_cdev,
					      struct lsc_cdev, cdev);
	struct lsc_pcie *pBrd = container_of(lcdev, struct lsc_pcie, chrdev);

	dev_info(&pBrd->pdev->dev, "open minor=%d\n",
		 MINOR(lcdev->cdevno));

	if (pBrd->ID == 0) {
		dev_err(&pBrd->pdev->dev, "device not configured correctly!\n");
		return -ENODEV;
	}
	if (!atomic_dec_and_test(&lcdev->open_token)) {
		dev_err(&pBrd->pdev->dev, "device already open!\n");
		atomic_inc(&lcdev->open_token);
		return -EBUSY;
	}

	filp->private_data = pBrd;

	return 0;
}

/* Release DMA xfer state and allow the device to be opened again. */
static int lsc_pcie_cdev_release(struct inode *inode, struct file *filp)
{
	struct lsc_pcie *pBrd = filp->private_data;

	dev_info(&pBrd->pdev->dev, "closing device: %s%d\n",
		 DRV_MODULE_NAME, MINOR(pBrd->chrdev.cdevno));

	dma_xfer_cleanup(pBrd, DMA_DIR_H2F);
	dma_xfer_cleanup(pBrd, DMA_DIR_F2H);

	atomic_inc(&pBrd->chrdev.open_token);

	return 0;
}

/**
 * lsc_pcie_cdev_ioctl - User-space IOCTL dispatcher for PCIe and DMA operations.
 * @filp: Open file handle; private_data points to struct lsc_pcie.
 * @cmd:  IOCTL command defined in include/lsc_pcie.h.
 * @arg:  User-space argument pointer (ioctl payload).
 *
 * This is the primary userspace API surface for the driver.  Commands include:
 *
 * - Device query: IOCTL_PCIE_GET_DEVICE_MODE, IOCTL_PCIE_GET_RESOURCES
 * - BAR MMIO access: IOCTL_PCIE_READ/WRITE_{8,16,32,64}BIT
 * - PCI config space: IOCTL_PCIE_CFG_REG_{READ,WRITE}_{8,16,32}Bit
 * - User interrupt setup: IOCTL_PCIE_USR_VEC_ALLOC
 * - DMA setup/run: IOCTL_PCIEDMA_GEN_DESC, START, START_WAIT_COMPLETION,
 *   STOP, GET_DESC_INFO, MEAS_THROUGHPUT, STATUS_CHECK, CLEANUP
 *
 * DMA ioctls require a prior successful GEN_DESC on the same direction.
 * copy_from_user / copy_to_user failures return -EFAULT or -EACCES depending
 * on the code path.
 *
 * Return: 0 on success, negative errno on failure (-EINVAL, -EFAULT,
 *         -EACCES, -ENOBUFS, -EALREADY, -ENOMEM, etc.).
 */
static long lsc_pcie_cdev_ioctl(struct file *filp, unsigned int cmd,
				unsigned long arg)
{
	struct lsc_pcie *pBrd;
	struct PCIResourceInfo *p_info;
	void *uaddr[MAX_NUM_FRAME_BUF];
	struct rw_ioctl rw;
	struct usr_vec_data usr_vec;
	struct dma_ubuf_ioctl_arg data;
	struct dma_status_ioctl_arg dma_status;
	enum dma_direction direction;
	int i;
	int ret;

	u32 deviceMode = 0;

	pBrd = filp->private_data;
	switch (cmd) {
	case IOCTL_PCIE_GET_DEVICE_MODE:
		deviceMode = (u32)pBrd->dev_mode;
		if (copy_to_user((void *)arg, &deviceMode, sizeof(deviceMode)) != 0)
			return -EFAULT;
		break;

	case IOCTL_PCIE_GET_RESOURCES:
		p_info = kzalloc(sizeof(struct PCIResourceInfo), GFP_KERNEL);
		if (!p_info)
			return -EFAULT;

		p_info->numBARs = pBrd->num_bars;
		for (i = 0; i < MAX_PCI_BARS; i++) {
			p_info->BAR[i].nBAR = pBrd->Dev_BARs[i].bar;
			p_info->BAR[i].physStartAddr = (u64)pBrd->Dev_BARs[i].pci_addr;
			p_info->BAR[i].size = pBrd->Dev_BARs[i].len;
			p_info->BAR[i].memMapped = (pBrd->Dev_BARs[i].kvm_addr) ? 1 : 0;
			p_info->BAR[i].flags = (u32)pBrd->Dev_BARs[i].pci_flags;
		}
		for (i = 0; i < 0x100; ++i)
			pci_read_config_byte(pBrd->pdev, i, &p_info->PCICfgReg[i]);

		/* BDF from pci_dev (matches lspci / sysfs); bus from bus->number */
		p_info->bus = (uint8_t)pBrd->pdev->bus->number;
		p_info->device = (uint8_t)PCI_SLOT(pBrd->pdev->devfn);
		p_info->function = (uint8_t)PCI_FUNC(pBrd->pdev->devfn);

		if (copy_to_user((void *)arg, (void *)p_info, sizeof(struct PCIResourceInfo)) != 0) {
			kfree(p_info);
			return -EFAULT;
		}

		kfree(p_info);
		break;

	case IOCTL_PCIE_READ_8BIT:
		if (copy_from_user(&rw, (struct rw_ioctl *)arg, sizeof(struct rw_ioctl)))
			return -EACCES;

		ret = lsc_pcie_validate_bar_access(pBrd, rw.bar_num, rw.reg,
						   sizeof(u8));
		if (ret)
			return ret;

		rw.value = lsc_pcie_read_reg8(pBrd, rw.bar_num, rw.reg);
		if (copy_to_user((void *)arg, &rw, sizeof(struct rw_ioctl))) {
			dev_err(&pBrd->pdev->dev, "copy_to_user failed.\n");
			return -EACCES;
		}
		break;

	case IOCTL_PCIE_READ_16BIT:
		if (copy_from_user(&rw, (struct rw_ioctl *)arg, sizeof(struct rw_ioctl)))
			return -EACCES;

		ret = lsc_pcie_validate_bar_access(pBrd, rw.bar_num, rw.reg,
						   sizeof(u16));
		if (ret)
			return ret;

		rw.value = lsc_pcie_read_reg16(pBrd, rw.bar_num, rw.reg);
		if (copy_to_user((void *)arg, &rw, sizeof(struct rw_ioctl))) {
			dev_err(&pBrd->pdev->dev, "copy_to_user failed.\n");
			return -EACCES;
		}
		break;

	case IOCTL_PCIE_READ_32BIT:
		if (copy_from_user(&rw, (struct rw_ioctl *)arg, sizeof(struct rw_ioctl)))
			return -EACCES;

		ret = lsc_pcie_validate_bar_access(pBrd, rw.bar_num, rw.reg,
						   sizeof(u32));
		if (ret)
			return ret;

		rw.value = lsc_pcie_read_reg32(pBrd, rw.bar_num, rw.reg);
		if (copy_to_user((void *)arg, &rw, sizeof(struct rw_ioctl))) {
			dev_err(&pBrd->pdev->dev, "copy_to_user failed.\n");
			return -EACCES;
		}
		break;

	case IOCTL_PCIE_READ_64BIT:
		if (copy_from_user(&rw, (struct rw_ioctl *)arg, sizeof(struct rw_ioctl)))
			return -EACCES;

		ret = lsc_pcie_validate_bar_access(pBrd, rw.bar_num, rw.reg,
						   sizeof(u64));
		if (ret)
			return ret;

		rw.value = lsc_pcie_read_reg64(pBrd, rw.bar_num, rw.reg);
		if (copy_to_user((void *)arg, &rw, sizeof(struct rw_ioctl))) {
			dev_err(&pBrd->pdev->dev, "copy_to_user failed.\n");
			return -EACCES;
		}
		break;

	case IOCTL_PCIE_WRITE_8BIT:
		if (copy_from_user(&rw, (struct rw_ioctl *)arg, sizeof(struct rw_ioctl))) {
			dev_err(&pBrd->pdev->dev, "w8 copy_from_user failed.\n");
			return -EACCES;
		}
		ret = lsc_pcie_validate_bar_access(pBrd, rw.bar_num, rw.reg,
						   sizeof(u8));
		if (ret)
			return ret;
		lsc_pcie_write_reg8(pBrd, rw.bar_num, rw.reg, rw.value);
		break;

	case IOCTL_PCIE_WRITE_16BIT:
		if (copy_from_user(&rw, (struct rw_ioctl *)arg, sizeof(struct rw_ioctl))) {
			dev_err(&pBrd->pdev->dev, "w16 copy_from_user failed.\n");
			return -EACCES;
		}
		ret = lsc_pcie_validate_bar_access(pBrd, rw.bar_num, rw.reg,
						   sizeof(u16));
		if (ret)
			return ret;
		lsc_pcie_write_reg16(pBrd, rw.bar_num, rw.reg, rw.value);
		break;

	case IOCTL_PCIE_WRITE_32BIT:
		if (copy_from_user(&rw, (struct rw_ioctl *)arg, sizeof(struct rw_ioctl))) {
			dev_err(&pBrd->pdev->dev, "w32 copy_from_user failed.\n");
			return -EACCES;
		}
		ret = lsc_pcie_validate_bar_access(pBrd, rw.bar_num, rw.reg,
						   sizeof(u32));
		if (ret)
			return ret;
		lsc_pcie_write_reg32(pBrd, rw.bar_num, rw.reg, rw.value);
		break;

	case IOCTL_PCIE_WRITE_64BIT:
		if (copy_from_user(&rw, (struct rw_ioctl *)arg, sizeof(struct rw_ioctl))) {
			dev_err(&pBrd->pdev->dev, "w64 copy_from_user failed.\n");
			return -EACCES;
		}
		ret = lsc_pcie_validate_bar_access(pBrd, rw.bar_num, rw.reg,
						   sizeof(u64));
		if (ret)
			return ret;
		lsc_pcie_write_reg64(pBrd, rw.bar_num, rw.reg, rw.value);
		break;

	case IOCTL_PCIE_CFG_REG_READ_8Bit:
		if (copy_from_user(&rw, (struct rw_ioctl *)arg, sizeof(struct rw_ioctl))) {
			dev_info(&pBrd->pdev->dev, "unable to access user buffer\n");
			return -EACCES;
		}
		ret = lsc_pcie_read_config_byte(pBrd, rw.reg, (u8 *)&rw.value);
		if (ret < 0)
			return ret;
		if (copy_to_user((void *)arg, &rw, sizeof(struct rw_ioctl))) {
			dev_info(&pBrd->pdev->dev, "unable to update buffer to user\n");
			return -EACCES;
		}
		break;

	case IOCTL_PCIE_CFG_REG_WRITE_8Bit:
		if (copy_from_user(&rw, (struct rw_ioctl *)arg, sizeof(struct rw_ioctl))) {
			dev_info(&pBrd->pdev->dev, "unable to access user buffer\n");
			return -EACCES;
		}
		ret = lsc_pcie_write_config_byte(pBrd, rw.reg, rw.value);
		if (ret < 0)
			return ret;
		break;

	case IOCTL_PCIE_CFG_REG_READ_16Bit:
		if (copy_from_user(&rw, (struct rw_ioctl *)arg, sizeof(struct rw_ioctl))) {
			dev_info(&pBrd->pdev->dev, "unable to access user buffer\n");
			return -EACCES;
		}
		ret = lsc_pcie_read_config_word(pBrd, rw.reg, (u16 *)&rw.value);
		if (ret < 0)
			return ret;
		if (copy_to_user((void *)arg, &rw, sizeof(struct rw_ioctl))) {
			dev_info(&pBrd->pdev->dev, "unable to update buffer to user\n");
			return -EACCES;
		}
		break;

	case IOCTL_PCIE_CFG_REG_WRITE_16Bit:
		if (copy_from_user(&rw, (struct rw_ioctl *)arg, sizeof(struct rw_ioctl))) {
			dev_info(&pBrd->pdev->dev, "unable to access user buffer\n");
			return -EACCES;
		}
		ret = lsc_pcie_write_config_word(pBrd, rw.reg, rw.value);
		if (ret < 0)
			return ret;
		break;

	case IOCTL_PCIE_CFG_REG_READ_32Bit:
		if (copy_from_user(&rw, (struct rw_ioctl *)arg, sizeof(struct rw_ioctl))) {
			dev_info(&pBrd->pdev->dev, "unable to access user buffer\n");
			return -EACCES;
		}
		ret = lsc_pcie_read_config_dword(pBrd, rw.reg, (u32 *)&rw.value);
		if (ret < 0)
			return ret;
		if (copy_to_user((void *)arg, &rw, sizeof(struct rw_ioctl))) {
			dev_info(&pBrd->pdev->dev, "unable to update buffer to user\n");
			return -EACCES;
		}
		break;

	case IOCTL_PCIE_CFG_REG_WRITE_32Bit:
		if (copy_from_user(&rw, (struct rw_ioctl *)arg, sizeof(struct rw_ioctl))) {
			dev_info(&pBrd->pdev->dev, "unable to access user buffer\n");
			return -EACCES;
		}
		ret = lsc_pcie_write_config_dword(pBrd, rw.reg, rw.value);
		if (ret < 0)
			return ret;
		break;

	case IOCTL_PCIE_USR_VEC_ALLOC:
		if (copy_from_user(&usr_vec, (struct usr_vec_data *)arg,
				   sizeof(struct usr_vec_data)))
			return -EFAULT;

		lsc_set_user_msi_vector_reg(pBrd, usr_vec.usr_int, usr_vec.vec_val);
		break;

	case IOCTL_PCIEDMA_GEN_DESC:
	{
		struct lsc_dma_engine *engine;

		if (copy_from_user(&data, (void __user *)arg, _IOC_SIZE(cmd)))
			return -EFAULT;

		ret = validate_dma_xfer_params(&pBrd->pdev->dev, data.dir, data.buf_cnt,
					       data.fpga_addr, data.len);
		if (ret)
			return ret;

		engine = lsc_dma_engine_get(pBrd, (enum dma_direction)data.dir);
		if (engine->xfer.ubuf_cnt > 0) /* already set, must cleanup first */
			return -EALREADY;

		if (copy_from_user(uaddr, (void __user *)data.addr,
				   data.buf_cnt * sizeof(void *)))
			return -EFAULT;

		if (dma_ubuf_map(pBrd, uaddr, data.len, data.buf_cnt, data.dir))
			return -ENOMEM;

		engine->xfer.ubuf_cnt = data.buf_cnt;

		if (dma_gen_desc(pBrd, data.dir, data.fpga_addr, data.circ_buf)) {
			dma_xfer_cleanup(pBrd, (enum dma_direction)data.dir);
			return -ENOMEM;
		}

		if (data.circ_buf == 1)
			engine->xfer.circ_buffer_on = true;
		else
			engine->xfer.circ_buffer_on = false;

		break;
	}

	case IOCTL_PCIEDMA_START_WAIT_COMPLETION:
	{
		struct dma_completion_result result;
		struct lsc_dma_engine *engine;

		if (copy_from_user(&dma_status, (void __user *)arg, _IOC_SIZE(cmd)))
			return -EFAULT;

		if (dma_status.dir >= NUM_DMA_DIRECTIONS)
			return -EINVAL;

		direction = (enum dma_direction)dma_status.dir;
		engine = lsc_dma_engine_get(pBrd, direction);
		if (engine->xfer.ubuf_cnt == 0) /* not init */
			return -ENOBUFS;

		ret = dma_start_and_wait(pBrd, direction,
					 dma_status.timeout_ms,
					 NULL, NULL, &result);
		if (ret < 0)
			return ret;

		dma_status.status_reg         = result.status_reg;
		dma_status.dma_error           = result.error;
		dma_status.completed_desc_cnt = result.completed_desc_cnt;
		dma_status.expected_desc_cnt  = result.expected_desc_cnt;

		if (copy_to_user((void __user *)arg, &dma_status, sizeof(dma_status)))
			return -EFAULT;
		break;
	}

	case IOCTL_PCIEDMA_START:
	{
		u8 dir;
		struct lsc_dma_engine *engine;

		if (copy_from_user(&dir, (void __user *)arg, _IOC_SIZE(cmd)))
			return -EFAULT;

		if (dir >= NUM_DMA_DIRECTIONS)
			return -EINVAL;

		engine = lsc_dma_engine_get(pBrd, (enum dma_direction)dir);
		if (engine->xfer.ubuf_cnt == 0) /* not init */
			return -ENOBUFS;

		ret = dma_start(pBrd, (enum dma_direction)dir);
		if (ret < 0)
			return ret;

		break;
	}

	case IOCTL_PCIEDMA_STOP:
	{
		u8 dir;
		struct lsc_dma_engine *engine;

		if (copy_from_user(&dir, (void __user *)arg, _IOC_SIZE(cmd)))
			return -EFAULT;

		if (dir >= NUM_DMA_DIRECTIONS)
			return -EINVAL;

		engine = lsc_dma_engine_get(pBrd, (enum dma_direction)dir);
		if (engine->xfer.ubuf_cnt == 0) /* not init */
			return -ENOBUFS;

		ret = dma_stop(pBrd, (enum dma_direction)dir);
		if (ret < 0)
			return ret;

		break;
	}

	case IOCTL_PCIEDMA_GET_DESC_INFO:
	{
		struct dma_desc_info_ioctl_arg info;
		struct lsc_dma_engine *engine;

		if (copy_from_user(&info, (void __user *)arg, _IOC_SIZE(cmd)))
			return -EFAULT;

		if (info.dir >= NUM_DMA_DIRECTIONS)
			return -EINVAL;

		engine = lsc_dma_engine_get(pBrd, (enum dma_direction)info.dir);
		if (engine->xfer.ubuf_cnt == 0) /* not init */
			return -ENOBUFS;

		if (info.buf_idx >= engine->xfer.ubuf_cnt)
			return -EINVAL;

		info.mapped_nents = engine->xfer.mapped_nents[info.buf_idx];
		info.total_descriptors = engine->xfer.total_descriptors;
		info.ubuf_cnt = engine->xfer.ubuf_cnt;
		info.circ_buffer_on = engine->xfer.circ_buffer_on;

		if (copy_to_user((void __user *)arg, &info, _IOC_SIZE(cmd)))
			return -EFAULT;

		break;
	}

	case IOCTL_PCIEDMA_MEAS_THROUGHPUT:
	{
		struct dma_throughput_ioctl_arg dma_throughput_arg;
		struct lsc_dma_engine *engine;

		if (copy_from_user(&dma_throughput_arg, (void __user *)arg, _IOC_SIZE(cmd)))
			return -EFAULT;

		if (dma_throughput_arg.dir >= NUM_DMA_DIRECTIONS)
			return -EINVAL;

		engine = lsc_dma_engine_get(pBrd, (enum dma_direction)dma_throughput_arg.dir);
		if (engine->xfer.ubuf_cnt == 0) /* not init */
			return -ENOBUFS;

		ret = dma_measure_throughput_chained(pBrd, &dma_throughput_arg);

		if (ret < 0)
			return ret;

		if (copy_to_user((void __user *)arg, &dma_throughput_arg, _IOC_SIZE(cmd)))
			return -EFAULT;

		break;
	}

	case IOCTL_PCIEDMA_STATUS_CHECK:
	{
		struct lsc_dma_engine *engine;

		if (copy_from_user(&dma_status, (void __user *)arg, _IOC_SIZE(cmd)))
			return -EFAULT;

		if (dma_status.dir >= NUM_DMA_DIRECTIONS)
			return -EINVAL;

		engine = lsc_dma_engine_get(pBrd, (enum dma_direction)dma_status.dir);
		if (engine->xfer.ubuf_cnt == 0) /* not init */
			return -ENOBUFS;

		ret = dma_status_check(pBrd, &dma_status);
		if (ret < 0)
			return ret;

		if (copy_to_user((void __user *)arg, &dma_status, _IOC_SIZE(cmd)))
			return -EFAULT;

		break;
	}

	case IOCTL_PCIEDMA_CLEANUP:
	{
		u8 dir;
		struct lsc_dma_engine *engine;

		if (copy_from_user(&dir, (void __user *)arg, _IOC_SIZE(cmd)))
			return -EFAULT;

		if (dir >= NUM_DMA_DIRECTIONS)
			return -EINVAL;

		engine = lsc_dma_engine_get(pBrd, (enum dma_direction)dir);
		if (engine->xfer.ubuf_cnt == 0) /* not init */
			return -ENOBUFS;

		dma_xfer_cleanup(pBrd, (enum dma_direction)dir);

		break;
	}

	default:
		return -EINVAL;
	}

	return 0;
}

/* Stub: BAR mmap is not implemented; always returns 0. */
static int lsc_pcie_cdev_mmap(struct file *filp, struct vm_area_struct *vma)
{
	return 0;
}

/* Stub: returns 0 bytes. */
static ssize_t lsc_pcie_cdev_read(struct file *filp, char __user *user_buf,
				  size_t len, loff_t *offp)
{
	struct lsc_pcie *pBrd = filp->private_data;

	(void)pBrd; // Suppress unused variable warning
	return 0;
}

/* Stub: returns 0 bytes. */
static ssize_t lsc_pcie_cdev_write(struct file *filp,
				   const char __user *user_buf, size_t len,
				   loff_t *offp)
{
	struct lsc_pcie *pBrd = filp->private_data;

	(void)pBrd; // Suppress unused variable warning
	return 0;
}

/* Character device file_operations wired to the handlers above. */
static const struct file_operations lsc_pcie_cdev_fops = {
	.owner          = THIS_MODULE,
	.open           = lsc_pcie_cdev_open,
	.release        = lsc_pcie_cdev_release,
	.unlocked_ioctl = lsc_pcie_cdev_ioctl,
	.mmap           = lsc_pcie_cdev_mmap,
	.read           = lsc_pcie_cdev_read,
	.write          = lsc_pcie_cdev_write,
};

/**
 * lsc_pcie_cdev_init - Allocate chrdev region and create sysfs class.
 *
 * Module-wide setup called once from module_init().  Registers a dynamic
 * major/minor range for up to MAX_MINORS device nodes and creates the
 * sysfs class used by device_create() in lsc_pcie_cdev_create().
 *
 * Return: 0 on success, negative errno on failure.
 */
int lsc_pcie_cdev_init(void)
{
	int result;

	result = alloc_chrdev_region(&g_devnum, 0, MAX_MINORS, DRV_MODULE_NAME);
	if (result < 0) {
		pr_err("can't get major/minor numbers!\n");
		return result;
	}

	pr_info("Major=%d\n", MAJOR(g_devnum));

#if (KERNEL_VERSION(6, 4, 0) <= LINUX_VERSION_CODE)
	g_lsc_class = class_create(DRV_MODULE_NAME);
#else
	g_lsc_class = class_create(THIS_MODULE, DRV_MODULE_NAME);
#endif
	if (IS_ERR(g_lsc_class)) {
		int err = PTR_ERR(g_lsc_class);

		pr_err("Error creating sysfs class: %d\n", err);
		unregister_chrdev_region(g_devnum, MAX_MINORS);
		return err;
	}

	return 0;
}

/**
 * lsc_pcie_cdev_cleanup - Destroy sysfs class and free chrdev region.
 *
 * Module-wide teardown called once from module_exit().  Reverses
 * lsc_pcie_cdev_init() and destroys the IDA used for minor allocation.
 */
void lsc_pcie_cdev_cleanup(void)
{
	if (g_lsc_class)
		class_destroy(g_lsc_class);
	unregister_chrdev_region(g_devnum, MAX_MINORS);
	ida_destroy(&g_ida);
}

/**
 * lsc_pcie_cdev_create - Create a character device node for one PCIe board.
 * @pBrd: Per-board state (struct lsc_cdev is embedded in struct lsc_pcie).
 * @pdev: PCI device used as the parent for device_create().
 *
 * Allocates a unique minor number, registers the cdev, and creates the
 * /dev/<DRV_MODULE_NAME>N sysfs node.  Called from probe after
 * lsc_pcie_device_open() succeeds.
 *
 * Return: 0 on success, negative errno on failure.
 */
int lsc_pcie_cdev_create(struct lsc_pcie *pBrd, struct pci_dev *pdev)
{
	struct lsc_cdev *lcdev = &pBrd->chrdev;
	int minor, err;

	minor = ida_alloc_max(&g_ida, MAX_MINORS - 1, GFP_KERNEL);
	if (minor < 0)
		return minor;

	lcdev->cdevno = MKDEV(MAJOR(g_devnum), minor);
	atomic_set(&lcdev->open_token, 1);

	cdev_init(&lcdev->cdev, &lsc_pcie_cdev_fops);
	lcdev->cdev.owner = THIS_MODULE;

	err = cdev_add(&lcdev->cdev, lcdev->cdevno, 1);
	if (err) {
		dev_err(&pdev->dev, "error adding char device\n");
		goto err_ida;
	}

	lcdev->sys_device = device_create(g_lsc_class, &pdev->dev,
					  lcdev->cdevno, NULL,
					  "%s%d", DRV_MODULE_NAME, minor);
	if (IS_ERR(lcdev->sys_device)) {
		err = PTR_ERR(lcdev->sys_device);
		lcdev->sys_device = NULL;
		dev_err(&pdev->dev, "error creating device node\n");
		goto err_cdev;
	}

	dev_info(&pdev->dev, "added device: %s%d\n", DRV_MODULE_NAME, minor);
	return 0;

err_cdev:
	cdev_del(&lcdev->cdev);
err_ida:
	ida_free(&g_ida, minor);
	return err;
}

/**
 * lsc_pcie_cdev_destroy - Remove the character device node for one board.
 * @pBrd: Per-board state whose chrdev was created by lsc_pcie_cdev_create().
 *
 * Destroys the sysfs device entry, deletes the cdev, and frees the minor
 * number.  Called from remove before lsc_pcie_device_close().
 */
void lsc_pcie_cdev_destroy(struct lsc_pcie *pBrd)
{
	struct lsc_cdev *lcdev = &pBrd->chrdev;

	device_destroy(g_lsc_class, lcdev->cdevno);
	cdev_del(&lcdev->cdev);
	ida_free(&g_ida, MINOR(lcdev->cdevno));
}
