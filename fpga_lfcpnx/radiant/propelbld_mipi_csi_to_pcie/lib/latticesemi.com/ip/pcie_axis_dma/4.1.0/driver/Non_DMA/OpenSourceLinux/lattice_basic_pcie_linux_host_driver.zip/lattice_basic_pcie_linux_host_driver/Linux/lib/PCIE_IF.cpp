// SPDX-License-Identifier: MIT
/*   ==================================================================
 
     >>>>>>>>>>>>>>>>>>>>>>> COPYRIGHT NOTICE <<<<<<<<<<<<<<<<<<<<<<<<<
     ------------------------------------------------------------------
     Copyright (c) 2025 by Lattice Semiconductor Corporation
     ALL RIGHTS RESERVED
     ------------------------------------------------------------------
 
     DISCLAIMER:
 
    LATTICE MAKES NO WARRANTIES ON THIS FILE OR ITS CONTENTS,
    WHETHER EXPRESSED, IMPLIED, STATUTORY,
    OR IN ANY PROVISION OF THE LATTICE PROPEL LICENSE AGREEMENT OR
    COMMUNICATION WITH LICENSEE,
    AND LATTICE SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
    MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
    LATTICE DOES NOT WARRANT THAT THE FUNCTIONS CONTAINED HEREIN WILL MEET
    LICENSEE 'S REQUIREMENTS, OR THAT LICENSEE' S OPERATION OF ANY DEVICE,
    SOFTWARE OR SYSTEM USING THIS FILE OR ITS CONTENTS WILL BE
    UNINTERRUPTED OR ERROR FREE,
    OR THAT DEFECTS HEREIN WILL BE CORRECTED.
    LICENSEE ASSUMES RESPONSIBILITY FOR SELECTION OF MATERIALS TO ACHIEVE
    ITS INTENDED RESULTS, AND FOR THE PROPER INSTALLATION, USE,
    AND RESULTS OBTAINED THEREFROM.
    LICENSEE ASSUMES THE ENTIRE RISK OF THE FILE AND ITS CONTENTS PROVING
    DEFECTIVE OR FAILING TO PERFORM PROPERLY AND IN SUCH EVENT,
    LICENSEE SHALL ASSUME THE ENTIRE COST AND RISK OF ANY REPAIR, SERVICE,
    CORRECTION,
    OR ANY OTHER LIABILITIES OR DAMAGES CAUSED BY OR ASSOCIATED WITH THE
    SOFTWARE.IN NO EVENT SHALL LATTICE BE LIABLE TO ANY PARTY FOR DIRECT,
    INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES,
    INCLUDING LOST PROFITS,
    ARISING OUT OF THE USE OF THIS FILE OR ITS CONTENTS,
    EVEN IF LATTICE HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
    LATTICE 'S SOLE LIABILITY, AND LICENSEE' S SOLE REMEDY,
    IS SET FORTH ABOVE.
    LATTICE DOES NOT WARRANT OR REPRESENT THAT THIS FILE,
    ITS CONTENTS OR USE THEREOF DOES NOT INFRINGE ON THIRD PARTIES'
    INTELLECTUAL PROPERTY RIGHTS, INCLUDING ANY PATENT. IT IS THE USER' S
    RESPONSIBILITY TO VERIFY THE USER SOFTWARE DESIGN FOR CONSISTENCY AND
    FUNCTIONALITY THROUGH THE USE OF FORMAL SOFTWARE VALIDATION METHODS.
     ------------------------------------------------------------------
 
     ================================================================== */


#include <string.h>
#include <sstream>
#include <iomanip>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/mman.h>
using namespace std;

#include "PCIE_IF.h"

/**
 * @brief Creates an interface to a Lattice PCIe Driver and evaluation board.
 *
 * This constructor opens the kernel driver device file and initializes the PCIE_IF
 * object for subsequent operations. It validates the device name, opens the device
 * file, and retrieves PCI resource information from the driver.
 *
 * @param pDeviceName Pointer to the device name string (e.g., "pcie_lattice").
 *                    The device file "/dev/pDeviceName" will be opened.
 *                    Must not be NULL or empty.
 *
 * @throws PCIE_IF_Error if:
 *         - Device name is NULL or empty
 *         - Device name string is too large
 *         - Failed to format device path
 *         - Device file cannot be opened
 *         - IOCTL call to get PCI resources fails
 */
PCIE_IF::PCIE_IF(const char *pDeviceName)
{
    char drivername[MAX_DEV_FILENAME_SIZE];
    hDev = -1;

    if (pDeviceName == NULL) {
        throw(PCIE_IF_Error("ERROR: Device name is NULL\n"));
    }
    
    // Check if device name is empty
    if (pDeviceName[0] == '\0') {
        throw(PCIE_IF_Error("ERROR: Device name is empty\n"));
    }
    
    // Check if device name will fit in buffer with "/dev/" prefix and null terminator
    if (strlen(pDeviceName) > (MAX_DEV_FILENAME_SIZE - 6)) {
        throw(PCIE_IF_Error("ERROR: Device name string too large\n"));
    }
        
    cout << "Device Name: " << pDeviceName << endl;

    // Open the kernel driver using the device name (using snprintf for safety)
    int ret = snprintf(drivername, sizeof(drivername), "/dev/%s", pDeviceName);
    if (ret < 0 || ret >= (int)sizeof(drivername)) {
        throw(PCIE_IF_Error("ERROR: Failed to format device path\n"));
    }
    cout << "Opening " << drivername << endl;

    hDev = open(drivername, O_RDWR, 0666); 
    if (hDev == -1) {
        perror("PCIE_IF: open");
        throw(PCIE_IF_Error("ERROR: Device file not found!\n"));
    }

    // Use driver specific IOCTL call to get PCI info from the driver
    if (ioctl(hDev, IOCTL_PCIE_GET_RESOURCES, &PCIinfo) != 0)
    {
        close(hDev);
        hDev = -1;
        throw(PCIE_IF_Error("ERROR: ioctl GET PCI RESOURCES Failed!\n"));
    }
    
    // Extract and display Vendor ID and Device ID from PCI configuration space
    uint16_t vendorId = PCIinfo.PCICfgReg[0] | (PCIinfo.PCICfgReg[1] << 8);
    uint16_t deviceId = PCIinfo.PCICfgReg[2] | (PCIinfo.PCICfgReg[3] << 8);
    cout << "Vendor ID: 0x" << hex << vendorId << ", Device ID: 0x" << deviceId << dec << endl;
    cout << "PCI Location: Bus " << (int)PCIinfo.bus << ", Device " << (int)PCIinfo.device 
         << ", Function " << (int)PCIinfo.function << endl;
    
    // printf("PCIE_IF Get_RESOURCES:\n");
    // printf("hasInt: %d\n", PCIinfo.hasInterrupt);
    // printf("Int Vect: %d\n", PCIinfo.intrVector);
    // printf("Num BARs: %d\n", PCIinfo.numBARs);
    // for (uint32_t i = 0; i < PCIinfo.numBARs; i++)
    // {
    //     printf("BAR Num: %d\n", PCIinfo.BAR[i].nBAR);
    //     printf("BAR Addr: 0x%lx\n", PCIinfo.BAR[i].physStartAddr);
    //     printf("BAR Size: %d\n", PCIinfo.BAR[i].size);
    //     printf("BAR Mapped: %d\n", PCIinfo.BAR[i].memMapped);
    // }

}

/**
 * @brief Destructor for the PCIE_IF class.
 *
 * This destructor closes the device handle if it is open.
 * It ensures that the device handle is properly closed and
 * set to an invalid state.
 */
PCIE_IF::~PCIE_IF()
{
    if (hDev != -1)
    {
        close(hDev);
        hDev = -1;  
    }
}

/**
 * @brief Retrieves the 256 bytes of the device's PCI configuration space registers.
 *
 * This function reads the PCI configuration space registers from the device.
 * These registers must be present on any PCI/PCIe device and have a standard format.
 * The configuration space contains device identification, capabilities, and
 * resource information.
 *
 * @param pCfg Pointer to a buffer where the 256 bytes of PCI configuration
 *             registers will be stored. The buffer must be at least 256 bytes
 *             in size. Must not be NULL.
 *
 * @return true if the operation succeeds, false if the driver reports an error.
 */
bool PCIE_IF::getPCIConfigRegs(uint8_t *pCfg)
{
    struct PCIResourceInfo PCIinfo;

    if (ioctl(hDev, IOCTL_PCIE_GET_RESOURCES, &PCIinfo) != 0)
        return(false);

    memcpy(pCfg, PCIinfo.PCICfgReg, sizeof(PCIinfo.PCICfgReg));
    return(true);
}

/**
 * @brief Retrieves the PCIe device mode.
 *
 * This function uses an ioctl system call to communicate with the device driver
 * and retrieve the PCIe device mode information. The mode is stored in the 
 * `pcie_mode` variable and returned to the caller.
 * @return The PCIe device mode as an integer.
 */
int PCIE_IF::getPCIeDeviceMode()
{
    int pcie_mode = 0;

    if (ioctl(hDev, IOCTL_PCIE_GET_DEVICE_MODE, &pcie_mode) < 0) {
        throw(PCIE_IF_Error("PCIE_IF: Failed to obtain PCIE device mode\n"));
    }
    return pcie_mode;
}

/**
 * @brief Retrieves information about the PCI Base Address Registers (BARs).
 * 
 * This function uses an IOCTL call to retrieve information about the PCI BARs
 * from the device. The retrieved information is copied into the provided buffer.
 * 
 * @param pInfo Pointer to a PCIResourceInfo_t structure where the BAR information
 *              will be stored. If nullptr is passed, no data will be copied.
 * @return true if the IOCTL call succeeds, false otherwise.
 */
bool PCIE_IF::getPCIBarInfo(struct PCIResourceInfo *pInfo)
{
    struct PCIResourceInfo PCIinfo;

    if (ioctl(hDev, IOCTL_PCIE_GET_RESOURCES, &PCIinfo) != 0)
        return(false);
    // Copy the retrieved data into the provided buffer
    if (pInfo != nullptr) {
        memcpy(pInfo, &PCIinfo, sizeof(struct PCIResourceInfo));
    }
    
    return(true);
}


/**
 * @brief Allocates and configures a user interrupt vector.
 *
 * This function sends an IOCTL command to allocate and configure a user interrupt
 * vector with the specified interrupt number and vector value. The function communicates
 * with the kernel driver using the `IOCTL_PCIE_USR_VEC_ALLOC` command.
 *
 * @param usr_int The user interrupt number to configure (valid range: 0 to 15).
 * @param vec_val The vector value to assign to the interrupt (valid range: 0 to 0x1F).
 *
 * @throws PCIE_IF_Error If the IOCTL call fails, an exception is thrown with an
 *         appropriate error message.
 */
void PCIE_IF::setUserIntMSIVector(uint8_t usr_int, uint8_t vec_val)
{
    struct usr_vec_data usr_vec;
    usr_vec.usr_int = usr_int;
    usr_vec.vec_val = vec_val;
    if(ioctl(hDev, IOCTL_PCIE_USR_VEC_ALLOC, &usr_vec) != 0) {
        throw(PCIE_IF_Error("PCIE_IF: setUserIntMSIVector failed! \n"));
    }
}


/**
 * @brief Reads an 8-bit value from a specified offset in the PCIe device's BAR0.
 * 
 * This function performs an IOCTL call to read an 8-bit value from the specified 
 * offset in the PCIe device's BAR0. If the IOCTL call fails, an exception of type 
 * PCIE_IF_Error is thrown.
 * 
 * @param offset The offset within BAR0 from which the 8-bit value is to be read.
 * @return uint8_t The 8-bit value read from the specified offset.
 * @throws PCIE_IF_Error if the IOCTL call fails.
 */
uint8_t PCIE_IF::readReg8(uint32_t offset) 
{
    struct rw_ioctl rw;
    uint8_t val;
    uint8_t bar_num = 0; 
    rw.bar_num = bar_num; // Set the BAR number to 0, as we are using BAR0 for register access
    rw.reg = offset;
    rw.value = 0;
    
    if (ioctl(hDev, IOCTL_PCIE_READ_8BIT, &rw) != 0) {
        throw(PCIE_IF_Error("PCIE_IF: readReg8 failed! \n"));
    }
    
    val = (uint8_t)rw.value;

    return(val);
}
    

/**
 * @brief Writes an 8-bit value to a specified offset in the PCIe device's BAR0.
 * 
 * This function performs an IOCTL call to write an 8-bit value to the specified 
 * offset in the PCIe device's BAR0. If the IOCTL call fails, an exception of type 
 * PCIE_IF_Error is thrown.
 * 
 * @param offset The offset within BAR0 to which the 8-bit value is to be written.
 * @param val The 8-bit value to be written to the specified offset.
 * @return void
 * @throws PCIE_IF_Error if the IOCTL call fails.
 */
void PCIE_IF::writeReg8(uint32_t offset, uint8_t val)
{
    struct rw_ioctl rw;
    uint8_t bar_num = 0; 
    rw.bar_num = bar_num; // Set the BAR number to 0, as we are using BAR0 for register access    
    rw.reg = offset;
    rw.value = val;

    if (ioctl(hDev, IOCTL_PCIE_WRITE_8BIT, &rw) != 0)
    {
        throw(PCIE_IF_Error("PCIE_IF: writeReg8 failed! \n"));
    }
    
}


/**
 * @brief Reads a 16-bit value from a specified offset in the PCIe device's BAR0.
 * 
 * This function performs an IOCTL call to read a 16-bit value from the specified 
 * offset in the PCIe device's BAR0. If the IOCTL call fails, an exception of type 
 * PCIE_IF_Error is thrown.
 * 
 * @param offset The offset within BAR0 from which the 16-bit value is to be read.
 * @return uint16_t The 16-bit value read from the specified offset.
 * @throws PCIE_IF_Error if the IOCTL call fails.
 */
uint16_t PCIE_IF::readReg16(uint32_t offset)
{
    struct rw_ioctl rw;
    uint16_t val;
    uint8_t bar_num = 0; 
    rw.bar_num = bar_num; // Set the BAR number to 0, as we are using BAR0 for register access
    rw.reg = offset;
    rw.value = 0;
    
    if (ioctl(hDev, IOCTL_PCIE_READ_16BIT, &rw) != 0)
    {
        throw(PCIE_IF_Error("PCIE_IF: readReg16 failed! \n"));
    }
    
    val = (uint16_t)rw.value;

    return(val);
}


/**
 * @brief Writes a 16-bit value to a specified offset in the PCIe device's BAR0.
 * 
 * This function performs an IOCTL call to write a 16-bit value to the specified 
 * offset in the PCIe device's BAR0. If the IOCTL call fails, an exception of type 
 * PCIE_IF_Error is thrown.
 * 
 * @param offset The offset within BAR0 to which the 16-bit value is to be written.
 * @param val The 16-bit value to be written to the specified offset.
 * @return void
 * @throws PCIE_IF_Error if the IOCTL call fails.
 */
void PCIE_IF::writeReg16(uint32_t offset, uint16_t val)
{
    struct rw_ioctl rw;
    uint8_t bar_num = 0; 
    rw.bar_num = bar_num; // Set the BAR number to 0, as we are using BAR0 for register access    
    rw.reg = offset;
    rw.value = val;

    if (ioctl(hDev, IOCTL_PCIE_WRITE_16BIT, &rw) != 0)
    {
        throw(PCIE_IF_Error("PCIE_IF: writeReg16 failed! \n"));
    }

}

/**
 * @brief Reads a 32-bit value from a specified offset in the PCIe device's BAR0.
 * 
 * This function performs an IOCTL call to read a 32-bit value from the specified 
 * offset in the PCIe device's BAR0. If the IOCTL call fails, an exception of type 
 * PCIE_IF_Error is thrown.
 * 
 * @param offset The offset within BAR0 from which the 32-bit value is to be read.
 * @return uint32_t The 32-bit value read from the specified offset.
 * @throws PCIE_IF_Error if the IOCTL call fails.
 */
uint32_t PCIE_IF::readReg32(uint32_t offset)
{
    struct rw_ioctl rw;
    uint32_t val;
    uint8_t bar_num = 0; 
    rw.bar_num = bar_num; // Set the BAR number to 0, as we are using BAR0 for register access
    rw.reg = offset;
    rw.value = 0;
    
    if (ioctl(hDev, IOCTL_PCIE_READ_32BIT, &rw) != 0)
    {
        throw(PCIE_IF_Error("PCIE_IF: readReg32 failed! \n"));
    }
    
    val = (uint32_t)rw.value;

    return(val);
}
    
/**
 * @brief Writes a 32-bit value to a specified offset in the PCIe device's BAR0.
 * 
 * This function performs an IOCTL call to write a 32-bit value to the specified 
 * offset in the PCIe device's BAR0. If the IOCTL call fails, an exception of type 
 * PCIE_IF_Error is thrown.
 * 
 * @param offset The offset within BAR0 to which the 32-bit value is to be written.
 * @param val The 32-bit value to be written to the specified offset.
 * @return void
 * @throws PCIE_IF_Error if the IOCTL call fails.
 */
void PCIE_IF::writeReg32(uint32_t offset, uint32_t val)
{
    struct rw_ioctl rw;
    uint8_t bar_num = 0; 
    rw.bar_num = bar_num; // Set the BAR number to 0, as we are using BAR0 for register access    
    rw.reg = offset;
    rw.value = val;

    if (ioctl(hDev, IOCTL_PCIE_WRITE_32BIT, &rw) != 0)
    {
        throw(PCIE_IF_Error("PCIE_IF: writeReg32 failed! \n"));
    }

}

/**
 * @brief Reads a 64-bit value from a specified offset in the PCIe device's BAR0.
 * 
 * This function performs an IOCTL call to read a 64-bit value from the specified 
 * offset in the PCIe device's BAR0. If the IOCTL call fails, an exception of type 
 * PCIE_IF_Error is thrown.
 * 
 * @param offset The offset within BAR0 from which the 64-bit value is to be read.
 * @return uint64_t The 64-bit value read from the specified offset.
 * @throws PCIE_IF_Error if the IOCTL call fails.
 */
uint64_t PCIE_IF::readReg64(uint32_t offset)
{
    struct rw_ioctl rw;
    uint64_t val;
    uint8_t bar_num = 0; 
    rw.bar_num = bar_num; // Set the BAR number to 0, as we are using BAR0 for register access
    rw.reg = offset;
    rw.value = 0;
    
    if (ioctl(hDev, IOCTL_PCIE_READ_64BIT, &rw) != 0)
    {
        throw(PCIE_IF_Error("PCIE_IF: readReg64 failed! \n"));
    }
    
    val = (uint32_t)rw.value;

    return(val);
}
    
/**
 * @brief Writes a 64-bit value to a specified offset in the PCIe device's BAR0.
 * 
 * This function performs an IOCTL call to write a 64-bit value to the specified 
 * offset in the PCIe device's BAR0. If the IOCTL call fails, an exception of type 
 * PCIE_IF_Error is thrown.
 * 
 * @param offset The offset within BAR0 to which the 64-bit value is to be written.
 * @param val The 64-bit value to be written to the specified offset.
 * @return void
 * @throws PCIE_IF_Error if the IOCTL call fails.
 */
void PCIE_IF::writeReg64(uint32_t offset, uint64_t val)
{
    struct rw_ioctl rw;
    uint8_t bar_num = 0; 
    rw.bar_num = bar_num; // Set the BAR number to 0, as we are using BAR0 for register access    
    rw.reg = offset;
    rw.value = val;
    if (ioctl(hDev, IOCTL_PCIE_WRITE_64BIT, &rw) != 0)
    {
        throw(PCIE_IF_Error("PCIE_IF: writeReg64 failed! \n"));
    }

}

/**
 * @brief Reads a block of 8-bit values from a specified offset in the PCIe device's BAR.
 * 
 * This function performs multiple IOCTL calls to read a block of 8-bit values from the 
 * specified offset in the PCIe device's BAR. If the IOCTL call fails, an exception of 
 * type PCIE_IF_Error is thrown.
 * 
 * @param bar_num The BAR number to access.
 * @param offset The starting offset within the BAR from which the 8-bit values are to be read.
 * @param val A reference to a vector where the read 8-bit values will be stored.
 * @param len The number of 8-bit values to read.
 * @param incAddr If true, the offset is incremented after each read.
 * @return bool True if the operation is successful.
 * @throws PCIE_IF_Error if any IOCTL call fails.
 */
bool PCIE_IF::readBlock8(uint8_t bar_num, uint32_t offset, std::vector<uint8_t> &val, size_t len, bool incAddr)
{
    struct rw_ioctl rw;
    rw.value = 0;
    rw.bar_num = bar_num;
    val.resize(len);
    for (size_t i = 0; i < len; ++i)
    {
        rw.reg = offset;
        if (ioctl(hDev, IOCTL_PCIE_READ_8BIT, &rw) != 0)
        {
            throw PCIE_IF_Error("PCIE_IF: block read8 failed!");
        }
        val[i] = static_cast<uint8_t>(rw.value);

        if (incAddr)
        {
            offset += sizeof(uint8_t);
        }
    }

    return(true);
}

/**
 * @brief Writes a block of 8-bit values to a specified offset in the PCIe device's BAR.
 * 
 * This function performs multiple IOCTL calls to write a block of 8-bit values to the 
 * specified offset in the PCIe device's BAR. If the IOCTL call fails, an exception of 
 * type PCIE_IF_Error is thrown.
 * 
 * @param bar_num The BAR number to access.
 * @param offset The starting offset within the BAR to which the 8-bit values are to be written.
 * @param val A reference to a vector containing the 8-bit values to be written.
 * @param len The number of 8-bit values to write.
 * @param incAddr If true, the offset is incremented after each write.
 * @return bool True if the operation is successful.
 * @throws PCIE_IF_Error if any IOCTL call fails.
 */
bool PCIE_IF::writeBlock8(uint8_t bar_num, uint32_t offset, const std::vector<uint8_t> &val, size_t len, bool incAddr)
{
    struct rw_ioctl rw;
    rw.bar_num = bar_num;
    for (size_t i = 0; i < len; ++i)
    {
        rw.reg = offset;
        rw.value = val[i];
        if (ioctl(hDev, IOCTL_PCIE_WRITE_8BIT, &rw) != 0)
        {
            throw PCIE_IF_Error("PCIE_IF: block write8 failed!");
        }

        if (incAddr)
        {
            offset += sizeof(uint8_t);;
        }
    }

    return(true);
}

/**
 * @brief Reads a block of 16-bit values from a specified offset in the PCIe device's BAR.
 * 
 * This function performs multiple IOCTL calls to read a block of 16-bit values from the 
 * specified offset in the PCIe device's BAR. If the IOCTL call fails, an exception of 
 * type PCIE_IF_Error is thrown.
 * 
 * @param bar_num The BAR number to access.
 * @param offset The starting offset within the BAR from which the 16-bit values are to be read.
 * @param val A reference to a vector where the read 16-bit values will be stored.
 * @param len The number of 16-bit values to read.
 * @param incAddr If true, the offset is incremented after each read.
 * @return bool True if the operation is successful.
 * @throws PCIE_IF_Error if any IOCTL call fails.
 */
bool PCIE_IF::readBlock16(uint8_t bar_num, uint32_t offset, std::vector<uint16_t> &val, size_t len, bool incAddr)
{
    struct rw_ioctl rw;
    rw.value = 0;
    rw.bar_num = bar_num;
    val.resize(len);
    for (size_t i = 0; i < len; ++i)
    {
        rw.reg = offset;
        if (ioctl(hDev, IOCTL_PCIE_READ_16BIT, &rw) != 0)
        {
            throw PCIE_IF_Error("PCIE_IF: block read16 failed!");
        }
        val[i] = static_cast<uint16_t>(rw.value);

        if (incAddr)
        {
            offset += sizeof(uint16_t);
        }
    }

    return(true);
}

/**
 * @brief Writes a block of 16-bit values to a specified offset in the PCIe device's BAR.
 * 
 * This function performs multiple IOCTL calls to write a block of 16-bit values to the 
 * specified offset in the PCIe device's BAR. If the IOCTL call fails, an exception of 
 * type PCIE_IF_Error is thrown.
 * 
 * @param bar_num The BAR number to access.
 * @param offset The starting offset within the BAR to which the 16-bit values are to be written.
 * @param val A reference to a vector containing the 16-bit values to be written.
 * @param len The number of 16-bit values to write.
 * @param incAddr If true, the offset is incremented after each write.
 * @return bool True if the operation is successful.
 * @throws PCIE_IF_Error if any IOCTL call fails.
 */
bool PCIE_IF::writeBlock16(uint8_t bar_num, uint32_t offset, const std::vector<uint16_t> &val, size_t len, bool incAddr)
{
    struct rw_ioctl rw;
    rw.bar_num = bar_num;
    for (size_t i = 0; i < len; ++i)
    {
        rw.reg = offset;
        rw.value = val[i];
        if (ioctl(hDev, IOCTL_PCIE_WRITE_16BIT, &rw) != 0)
        {
            throw PCIE_IF_Error("PCIE_IF: block write16 failed!");
        }

        if (incAddr)
        {
            offset += sizeof(uint16_t);;
        }
    }

    return(true);
}

/**
 * @brief Reads a block of 32-bit values from a specified offset in the PCIe device's BAR.
 * 
 * This function performs multiple IOCTL calls to read a block of 32-bit values from the 
 * specified offset in the PCIe device's BAR. If the IOCTL call fails, an exception of 
 * type PCIE_IF_Error is thrown.
 * 
 * @param bar_num The BAR number to access.
 * @param offset The starting offset within the BAR from which the 32-bit values are to be read.
 * @param val A reference to a vector where the read 32-bit values will be stored.
 * @param len The number of 32-bit values to read.
 * @param incAddr If true, the offset is incremented after each read.
 * @return bool True if the operation is successful.
 * @throws PCIE_IF_Error if any IOCTL call fails.
 */
bool PCIE_IF::readBlock32(uint8_t bar_num, uint32_t offset, std::vector<uint32_t> &val, size_t len, bool incAddr)
{
    struct rw_ioctl rw;
    rw.value = 0;
    rw.bar_num = bar_num;
    val.resize(len);
    for (size_t i = 0; i < len; ++i)
    {
        rw.reg = offset;
        if (ioctl(hDev, IOCTL_PCIE_READ_32BIT, &rw) != 0)
        {
            throw PCIE_IF_Error("PCIE_IF: block read32 failed!");
        }

        val[i] = static_cast<uint32_t>(rw.value);

        if (incAddr)
        {
            offset += sizeof(uint32_t);
        }
    }

    return(true);
}

/**
 * @brief Writes a block of 32-bit values to a specified offset in the PCIe device's BAR.
 * 
 * This function performs multiple IOCTL calls to write a block of 32-bit values to the 
 * specified offset in the PCIe device's BAR. If the IOCTL call fails, an exception of 
 * type PCIE_IF_Error is thrown.
 * 
 * @param bar_num The BAR number to access.
 * @param offset The starting offset within the BAR to which the 32-bit values are to be written.
 * @param val A reference to a vector containing the 32-bit values to be written.
 * @param len The number of 32-bit values to write.
 * @param incAddr If true, the offset is incremented after each write.
 * @return bool True if the operation is successful.
 * @throws PCIE_IF_Error if any IOCTL call fails.
 */
bool PCIE_IF::writeBlock32(uint8_t bar_num, uint32_t offset, const std::vector<uint32_t> &val, size_t len, bool incAddr)
{
    struct rw_ioctl rw;
    rw.bar_num = bar_num;
    for (size_t i = 0; i < len; ++i)
    {
        rw.reg = offset;
        rw.value = val[i];
        if (ioctl(hDev, IOCTL_PCIE_WRITE_32BIT, &rw) != 0)
        {
            throw PCIE_IF_Error("PCIE_IF: block write32 failed!");
        }

        if (incAddr)
        {
            offset += sizeof(uint32_t);;
        }
    }

    return(true);
}

/**
 * @brief Reads a block of 64-bit values from a specified offset in the PCIe device's BAR.
 * 
 * This function performs multiple IOCTL calls to read a block of 64-bit values from the 
 * specified offset in the PCIe device's BAR. If the IOCTL call fails, an exception of 
 * type PCIE_IF_Error is thrown.
 * 
 * @param bar_num The BAR number to access.
 * @param offset The starting offset within the BAR from which the 64-bit values are to be read.
 * @param val A reference to a vector where the read 64-bit values will be stored.
 * @param len The number of 64-bit values to read.
 * @param incAddr If true, the offset is incremented after each read.
 * @return bool True if the operation is successful.
 * @throws PCIE_IF_Error if any IOCTL call fails.
 */
bool PCIE_IF::readBlock64(uint8_t bar_num, uint32_t offset, std::vector<uint64_t> &val, size_t len, bool incAddr)
{
    struct rw_ioctl rw;
    rw.value = 0;
    rw.bar_num = bar_num;
    val.resize(len);
    for (size_t i = 0; i < len; ++i)
    {
        rw.reg = offset;
        if (ioctl(hDev, IOCTL_PCIE_READ_64BIT, &rw) != 0)
        {
            throw PCIE_IF_Error("PCIE_IF: block read64 failed!");
        }

        val[i] = static_cast<uint64_t>(rw.value);

        if (incAddr)
        {
            offset += sizeof(uint64_t);
        }
    }

    return(true);
}

/**
 * @brief Writes a block of 64-bit values to a specified offset in the PCIe device's BAR.
 * 
 * This function performs multiple IOCTL calls to write a block of 64-bit values to the 
 * specified offset in the PCIe device's BAR. If the IOCTL call fails, an exception of 
 * type PCIE_IF_Error is thrown.
 * 
 * @param bar_num The BAR number to access.
 * @param offset The starting offset within the BAR to which the 64-bit values are to be written.
 * @param val A reference to a vector containing the 64-bit values to be written.
 * @param len The number of 64-bit values to write.
 * @param incAddr If true, the offset is incremented after each write.
 * @return bool True if the operation is successful.
 * @throws PCIE_IF_Error if any IOCTL call fails.
 */
bool PCIE_IF::writeBlock64(uint8_t bar_num, uint32_t offset, const std::vector<uint64_t> &val, size_t len, bool incAddr)
{
    struct rw_ioctl rw;
    rw.bar_num = bar_num;
    for (size_t i = 0; i < len; ++i)
    {
        rw.reg = offset;
        rw.value = val[i];
        if (ioctl(hDev, IOCTL_PCIE_WRITE_64BIT, &rw) != 0)
        {
            throw PCIE_IF_Error("PCIE_IF: block write64 failed!");
        }

        if (incAddr)
        {
            offset += sizeof(uint64_t);;
        }
    }

    return(true);
}

/**
 * @brief Reads an 8-bit value from a specified offset in the PCIe device's BAR.
 * 
 * This function performs an IOCTL call to read an 8-bit value from the specified 
 * offset in the PCIe device's BAR. If the IOCTL call fails, an exception of type 
 * PCIE_IF_Error is thrown.
 * 
 * @param bar_num The BAR number to access.
 * @param offset The offset within the BAR to read from.
 * @return uint8_t The 8-bit value read from the specified offset.
 * @throws PCIE_IF_Error if the IOCTL call fails.
 */
uint8_t PCIE_IF::read8(uint8_t bar_num, uint32_t offset)
{
    struct rw_ioctl rw;
    uint8_t val;
    rw.bar_num = bar_num;
    rw.reg = offset;
    rw.value = 0;
    if (ioctl(hDev, IOCTL_PCIE_READ_8BIT, &rw) != 0)
    {
        throw(PCIE_IF_Error("PCIE_IF: read8 failed! \n"));
    }
    
    val = (uint8_t)rw.value;

    return(val);
}

/**
 * @brief Writes an 8-bit value to a specified offset in the PCIe device's BAR.
 * 
 * This function performs an IOCTL call to write an 8-bit value to the specified 
 * offset in the PCIe device's BAR. If the IOCTL call fails, an exception of type 
 * PCIE_IF_Error is thrown.
 * 
 * @param bar_num The BAR number to access.
 * @param offset The offset within the BAR to write to.
 * @param val The 8-bit value to write to the specified offset.
 * @return void
 * @throws PCIE_IF_Error if the IOCTL call fails.
 */
void PCIE_IF::write8(uint8_t bar_num, uint32_t offset, uint8_t val)
{
    struct rw_ioctl rw;
    rw.bar_num = bar_num;
    rw.reg = offset;
    rw.value = val;

    if (ioctl(hDev, IOCTL_PCIE_WRITE_8BIT, &rw) != 0)
    {
        throw(PCIE_IF_Error("PCIE_IF: write8 failed! \n"));
    }
}

/**
 * @brief Reads a 16-bit value from a specified offset in the PCIe device's BAR.
 * 
 * This function performs an IOCTL call to read a 16-bit value from the specified 
 * offset in the PCIe device's BAR. If the IOCTL call fails, an exception of type 
 * PCIE_IF_Error is thrown.
 * 
 * @param bar_num The BAR number to access.
 * @param offset The offset within the BAR to read from.
 * @return uint16_t The 16-bit value read from the specified offset.
 * @throws PCIE_IF_Error if the IOCTL call fails.
 */
uint16_t PCIE_IF::read16(uint8_t bar_num, uint32_t offset)
{
    struct rw_ioctl rw;
    uint16_t val;
    rw.bar_num = bar_num;
    rw.reg = offset;
    rw.value = 0;
    if (ioctl(hDev, IOCTL_PCIE_READ_16BIT, &rw) != 0)
    {
        throw(PCIE_IF_Error("PCIE_IF: read16 failed! \n"));
    }
    
    val = (uint16_t)rw.value;

    return(val);
}

/**
 * @brief Writes a 16-bit value to a specified offset in the PCIe device's BAR.
 * 
 * This function performs an IOCTL call to write a 16-bit value to the specified 
 * offset in the PCIe device's BAR. If the IOCTL call fails, an exception of type 
 * PCIE_IF_Error is thrown.
 * 
 * @param bar_num The BAR number to access.
 * @param offset The offset within the BAR to write to.
 * @param val The 16-bit value to write to the specified offset.
 * @return void
 * @throws PCIE_IF_Error if the IOCTL call fails.
 */
void PCIE_IF::write16(uint8_t bar_num, uint32_t offset, uint16_t val)
{
    struct rw_ioctl rw;
    rw.bar_num = bar_num;
    rw.reg = offset;
    rw.value = val;

    if (ioctl(hDev, IOCTL_PCIE_WRITE_16BIT, &rw) != 0)
    {
        throw(PCIE_IF_Error("PCIE_IF: write16 failed! \n"));
    }
}

/**
 * @brief Reads a 32-bit value from a specified offset in the PCIe device's BAR.
 * 
 * This function performs an IOCTL call to read a 32-bit value from the specified 
 * offset in the PCIe device's BAR. If the IOCTL call fails, an exception of type 
 * PCIE_IF_Error is thrown.
 * 
 * @param bar_num The BAR number to access.
 * @param offset The offset within the BAR to read from.
 * @return uint32_t The 32-bit value read from the specified offset.
 * @throws PCIE_IF_Error if the IOCTL call fails.
 */
uint32_t PCIE_IF::read32(uint8_t bar_num, uint32_t offset)
{
    struct rw_ioctl rw;
    uint32_t val;
    rw.bar_num = bar_num;
    rw.reg = offset;
    rw.value = 0;
    if (ioctl(hDev, IOCTL_PCIE_READ_32BIT, &rw) != 0)
    {
        throw(PCIE_IF_Error("PCIE_IF: read32 failed! \n"));
    }
    
    val = (uint32_t)rw.value;

    return(val);
}

/**
 * @brief Writes a 32-bit value to a specified offset in the PCIe device's BAR.
 * 
 * This function performs an IOCTL call to write a 32-bit value to the specified 
 * offset in the PCIe device's BAR. If the IOCTL call fails, an exception of type 
 * PCIE_IF_Error is thrown.
 * 
 * @param bar_num The BAR number to access.
 * @param offset The offset within the BAR to write to.
 * @param val The 32-bit value to write to the specified offset.
 * @return void
 * @throws PCIE_IF_Error if the IOCTL call fails.
 */
void PCIE_IF::write32(uint8_t bar_num, uint32_t offset, uint32_t val)
{
    struct rw_ioctl rw;
    rw.bar_num = bar_num;
    rw.reg = offset;
    rw.value = val;

    if (ioctl(hDev, IOCTL_PCIE_WRITE_32BIT, &rw) != 0)
    {
        throw(PCIE_IF_Error("PCIE_IF: write32 failed! \n"));
    }
}

/**
 * @brief Reads a 64-bit value from a specified offset in the PCIe device's BAR.
 * 
 * This function performs an IOCTL call to read a 64-bit value from the specified 
 * offset in the PCIe device's BAR. If the IOCTL call fails, an exception of type 
 * PCIE_IF_Error is thrown.
 * 
 * @param bar_num The BAR number to access.
 * @param offset The offset within the BAR to read from.
 * @return uint64_t The 64-bit value read from the specified offset.
 * @throws PCIE_IF_Error if the IOCTL call fails.
 */
uint64_t PCIE_IF::read64(uint8_t bar_num, uint32_t offset)
{
    struct rw_ioctl rw;
    uint64_t val;
    rw.bar_num = bar_num;
    rw.reg = offset;
    rw.value = 0;
    if (ioctl(hDev, IOCTL_PCIE_READ_64BIT, &rw) != 0)
    {
        throw(PCIE_IF_Error("PCIE_IF: read64 failed! \n"));
    }
    
    val = (uint64_t)rw.value;

    return(val);
}

/**
 * @brief Writes a 64-bit value to a specified offset in the PCIe device's BAR.
 * 
 * This function performs an IOCTL call to write a 64-bit value to the specified 
 * offset in the PCIe device's BAR. If the IOCTL call fails, an exception of type 
 * PCIE_IF_Error is thrown.
 * 
 * @param bar_num The BAR number to access.
 * @param offset The offset within the BAR to write to.
 * @param val The 64-bit value to write to the specified offset.
 * @return void
 * @throws PCIE_IF_Error if the IOCTL call fails.
 */
void PCIE_IF::write64(uint8_t bar_num, uint32_t offset, uint64_t val)
{
    struct rw_ioctl rw;
    rw.bar_num = bar_num;
    rw.reg = offset;
    rw.value = val;

    if (ioctl(hDev, IOCTL_PCIE_WRITE_64BIT, &rw) != 0)
    {
        throw(PCIE_IF_Error("PCIE_IF: write64 failed! \n"));
    }
}

/**
 * @brief Reads an 8-bit value from a specified offset in the PCIe configuration space.
 * 
 * This function performs an IOCTL call to read an 8-bit value from the specified 
 * offset in the PCIe configuration space. If the IOCTL call fails, an exception 
 * of type PCIE_IF_Error is thrown.
 * 
 * @param offset The offset within the PCIe configuration space to read from.
 * @return uint8_t The 8-bit value read from the specified offset.
 * @throws PCIE_IF_Error if the IOCTL call fails.
 */
uint8_t PCIE_IF::readConfig8(uint32_t offset)
{
    struct rw_ioctl rw;
    uint8_t val;
    rw.reg = offset;
    rw.value = 0;
    if (ioctl(hDev, IOCTL_PCIE_CFG_REG_READ_8Bit, &rw) != 0)
    {
        throw(PCIE_IF_Error("PCIE_IF: readConfig8 failed! \n"));
    }
    
    val = (uint8_t)rw.value;

    return(val);
}
    
/**
 * @brief Writes an 8-bit value to a specified offset in the PCIe configuration space.
 * 
 * This function performs an IOCTL call to write an 8-bit value to the specified 
 * offset in the PCIe configuration space. If the IOCTL call fails, an exception 
 * of type PCIE_IF_Error is thrown.
 * 
 * @param offset The offset within the PCIe configuration space to write to.
 * @param val The 8-bit value to write to the specified offset.
 * @return void
 * @throws PCIE_IF_Error if the IOCTL call fails.
 */
void PCIE_IF::writeConfig8(uint32_t offset, uint8_t val)
{
    struct rw_ioctl rw;
    
    rw.reg = offset;
    rw.value = val;

    if (ioctl(hDev, IOCTL_PCIE_CFG_REG_WRITE_8Bit, &rw) != 0)
    {
        throw(PCIE_IF_Error("PCIE_IF: writeConfig8 failed! \n"));
    }

}

/**
 * @brief Reads a 16-bit value from a specified offset in the PCIe configuration space.
 * 
 * This function performs an IOCTL call to read a 16-bit value from the specified 
 * offset in the PCIe configuration space. If the IOCTL call fails, an exception 
 * of type PCIE_IF_Error is thrown.
 * 
 * @param offset The offset within the PCIe configuration space to read from.
 * @return uint16_t The 16-bit value read from the specified offset.
 * @throws PCIE_IF_Error if the IOCTL call fails.
 */
uint16_t PCIE_IF::readConfig16(uint32_t offset)
{
    struct rw_ioctl rw;
    uint16_t val;
    rw.reg = offset;
    rw.value = 0;
    if (ioctl(hDev, IOCTL_PCIE_CFG_REG_READ_16Bit, &rw) != 0)
    {
        throw(PCIE_IF_Error("PCIE_IF: readConfig16 failed! \n"));
    }
    
    val = (uint16_t)rw.value;

    return(val);
}
    
/**
 * @brief Writes a 16-bit value to a specified offset in the PCIe configuration space.
 * 
 * This function performs an IOCTL call to write a 16-bit value to the specified 
 * offset in the PCIe configuration space. If the IOCTL call fails, an exception 
 * of type PCIE_IF_Error is thrown.
 * 
 * @param offset The offset within the PCIe configuration space to write to.
 * @param val The 16-bit value to write to the specified offset.
 * @return void
 * @throws PCIE_IF_Error if the IOCTL call fails.
 */
void PCIE_IF::writeConfig16(uint32_t offset, uint16_t val)
{
    struct rw_ioctl rw;
    
    rw.reg = offset;
    rw.value = val;

    if (ioctl(hDev, IOCTL_PCIE_CFG_REG_WRITE_16Bit, &rw) != 0)
    {
        throw(PCIE_IF_Error("PCIE_IF: writeConfig16 failed! \n"));
    }

}

/**
 * @brief Reads a 32-bit value from a specified offset in the PCIe configuration space.
 * 
 * This function performs an IOCTL call to read a 32-bit value from the specified 
 * offset in the PCIe configuration space. If the IOCTL call fails, an exception 
 * of type PCIE_IF_Error is thrown.
 * 
 * @param offset The offset within the PCIe configuration space to read from.
 * @return uint32_t The 32-bit value read from the specified offset.
 * @throws PCIE_IF_Error if the IOCTL call fails.
 */
uint32_t PCIE_IF::readConfig32(uint32_t offset)
{
    struct rw_ioctl rw;
    uint32_t val;
    rw.reg = offset;
    rw.value = 0;
    if (ioctl(hDev, IOCTL_PCIE_CFG_REG_READ_32Bit, &rw) != 0)
    {
        throw(PCIE_IF_Error("PCIE_IF: readConfig32 failed! \n"));
    }
    
    val = (uint32_t)rw.value;

    return(val);
}
    
/**
 * @brief Writes a 32-bit value to a specified offset in the PCIe configuration space.
 * 
 * This function performs an IOCTL call to write a 32-bit value to the specified 
 * offset in the PCIe configuration space. If the IOCTL call fails, an exception 
 * of type PCIE_IF_Error is thrown.
 * 
 * @param offset The offset within the PCIe configuration space to write to.
 * @param val The 32-bit value to write to the specified offset.
 * @return void
 * @throws PCIE_IF_Error if the IOCTL call fails.
 */
void PCIE_IF::writeConfig32(uint32_t offset, uint32_t val)
{
    struct rw_ioctl rw;
    
    rw.reg = offset;
    rw.value = val;

    if (ioctl(hDev, IOCTL_PCIE_CFG_REG_WRITE_32Bit, &rw) != 0)
    {
        throw(PCIE_IF_Error("PCIE_IF: writeConfig32 failed! \n"));
    }

}



