/* SPDX-License-Identifier: MIT */
/*
 * Lattice Semiconductor PCIe DMA Driver - Internal Core Header
 *
 * Main internal header for the driver implementation. Kernel consumers that
 * build this driver code together with their own module can include this
 * header for the core PCIe APIs and device state.
 *
 * Copyright (c) 2026 by Lattice Semiconductor Corporation
 * ALL RIGHTS RESERVED
 */

#ifndef __LSC_PCIE_CORE_H__
#define __LSC_PCIE_CORE_H__

#include <linux/atomic.h>
#include <linux/cdev.h>
#include <linux/dma-mapping.h>
#include <linux/idr.h>
#include <linux/interrupt.h>
#include <linux/kernel.h>
#include <linux/io.h>
#include <linux/ioport.h>
#include <linux/mm.h>
#include <linux/pci.h>
#include <linux/scatterlist.h>
#include <linux/sizes.h>
#include <linux/spinlock.h>
#include <linux/version.h>
#include <linux/wait.h>

#include "lsc_pcie_regs.h"
#include "../include/lsc_pcie.h"

#define DRV_MODULE_NAME PCIE_DRIVER_NAME

/*
 * Prefix dev_* messages with __func__. Requires <linux/pci.h>.
 */
#undef dev_info
#define dev_info(dev, fmt, ...) \
	_dev_info((dev), "%s: " fmt, __func__, ##__VA_ARGS__)
#undef dev_err
#define dev_err(dev, fmt, ...) \
	_dev_err((dev), "%s: " fmt, __func__, ##__VA_ARGS__)
#undef dev_warn
#define dev_warn(dev, fmt, ...) \
	_dev_warn((dev), "%s: " fmt, __func__, ##__VA_ARGS__)
#undef dev_notice
#define dev_notice(dev, fmt, ...) \
	_dev_notice((dev), "%s: " fmt, __func__, ##__VA_ARGS__)
#undef dev_err_ratelimited
#define dev_err_ratelimited(dev, fmt, ...) \
	dev_err((dev), fmt, ##__VA_ARGS__)
#undef dev_warn_ratelimited
#define dev_warn_ratelimited(dev, fmt, ...) \
	dev_warn((dev), fmt, ##__VA_ARGS__)

#define NUM_BARS MAX_PCI_BARS
#define MAX_MINORS 256         /* upper bound for dynamic minor allocation */

#define BAR0 0
#define BAR1 1

#define NUM_DMA_CHANNELS 1    /* max channels per direction (H2F or F2H) */

#define LSC_DMA_MAX_SEG_SIZE	SZ_16M
#define MAX_NUM_FRAME_BUF 1

#define LSC_USER_VEC_COUNT_DEFAULT 1 /* example design exposes 1 user interrupt */

#define LSC_PCIE_MSIX_MAX_VEC 64
#define LSC_PCIE_MSI_MAX_VEC  16
#define LSC_PCIE_MAX_IRQ_VEC  LSC_PCIE_MSIX_MAX_VEC

/*
 * MSI / MSI-X message indices for this driver: the same values are programmed
 * into the FPGA and used as Linux's message index for pci_irq_vector().
 */
enum lsc_msi_vec_idx {
	F2H_MSI_VEC = 0,
	H2F_MSI_VEC,
	AXI_BRIDGE_ERR_MSI_VEC,
};

enum lsc_pcie_irq_mode {
	LSC_MSI_MSIX_NONE = 0,
	LSC_MSI_ENABLED,
	LSC_MSIX_ENABLED,
};

/* Hardware DMA descriptor layout shared with the FPGA DMA engine. */
struct dma_desc_hw {
	u32 desc_ctrl;
	u32 dma_len;
	u32 next_desc_addr_lo;
	u32 next_desc_addr_hi;
	u32 src_addr_lo;
	u32 src_addr_hi;
	u32 dest_addr_lo;
	u32 dest_addr_hi;
} __packed;

/* User buffer page mapping information for DMA setup. */
struct ubuf_info {
	size_t size;
	struct page **pages;
	int offset;
	int nr_pages;
};

struct dma_irq_ops;

/* State for one DMA transfer, including user buffers, descriptors, and completion. */
struct lsc_dma_transfer {
	struct ubuf_info *ubuf_info[MAX_NUM_FRAME_BUF];
	struct sg_table *ubuf_sg_table[MAX_NUM_FRAME_BUF];
	int mapped_nents[MAX_NUM_FRAME_BUF];
	struct dma_desc_hw *dma_desc[MAX_NUM_FRAME_BUF];
	dma_addr_t dma_desc_handle[MAX_NUM_FRAME_BUF];
	u32 total_descriptors;
	u16 ubuf_cnt;
	u8 desc_mode;
	bool circ_buffer_on;

	u32 comp_desc_cnt;
	u32 dma_status_reg;
	bool dma_done;
};

/* Per-direction DMA engine state. */
struct lsc_dma_engine {
	struct lsc_pcie *pBrd;
	void __iomem *regs;
	char name[16];
	enum dma_direction dir;
	int channel;

	struct lsc_dma_transfer xfer;

	/* protects xfer completion state (dma_done, status, desc counts) */
	spinlock_t lock;
	/* protects dma_ops and dma_ops_priv */
	spinlock_t irq_ops_lock;

	const struct dma_irq_ops *dma_ops;
	void *dma_ops_priv;
};

/* DMA register bases and per-direction engines for one PCIe device. */
struct lsc_dma_dev {
	void __iomem *dma_reg_base;
	void __iomem *ctrl_reg_base;
	struct lsc_dma_engine engine_h2f[NUM_DMA_CHANNELS];
	struct lsc_dma_engine engine_f2h[NUM_DMA_CHANNELS];
	wait_queue_head_t wq;
};

/* BAR resource information captured from PCI core resource APIs. */
struct PCI_Dev_BAR {
	void *pci_addr;
	void *kvm_addr;
	u64 len;
	u64 pci_start;
	u64 pci_end;
	u64 pci_flags;
	int bar;
};

/* Character-device state associated with a PCIe device instance. */
struct lsc_cdev {
	struct cdev cdev;
	dev_t cdevno;
	struct device *sys_device;
	atomic_t open_token;
};

/* Cached PCIe capability and link information for reporting. */
struct lsc_pcie_hw_info {
	u32 max_payload_size;
	u32 max_read_req_size;
	u32 rcb_size;
	u32 link_width;
	u32 pcie_gen;
};

/* Top-level per-device driver state. */
struct lsc_pcie {
	struct lsc_dma_dev dma;
	struct pci_dev *pdev;
	struct lsc_cdev chrdev;
	void *ctrlBARaddr[NUM_BARS];
	struct PCI_Dev_BAR Dev_BARs[NUM_BARS];
	struct lsc_pcie_hw_info hw_info;
	deviceMode_t dev_mode;
	u32 ID;
	u32 irq_vec[LSC_PCIE_MAX_IRQ_VEC];
	u32 num_irqs;
	int nr_dma_vecs;
	int nr_user_vecs;
	u32 IRQ;
	u8 num_bars;
	bool msi;
	bool msix;
};

/* Return the DMA engine for a direction/channel pair. */
static inline struct lsc_dma_engine *
__lsc_dma_engine_get(struct lsc_pcie *pBrd, enum dma_direction dir, int chan)
{
	return (dir == DMA_DIR_H2F) ? &pBrd->dma.engine_h2f[chan]
				    : &pBrd->dma.engine_f2h[chan];
}

#define lsc_dma_engine_get(pBrd, dir) __lsc_dma_engine_get((pBrd), (dir), 0)

/* ---- PCIe device lifecycle ---- */

struct lsc_pcie *lsc_pcie_device_open(const char *mod_name,
				      struct pci_dev *pdev);
void lsc_pcie_device_close(struct pci_dev *pdev, struct lsc_pcie *pBrd);
/* Return a mapped BAR address for other in-kernel users. */
void __iomem *lsc_pcie_get_bar_va(struct pci_dev *pdev, u8 bar,
				  resource_size_t *bar_len);

/* ---- BAR register I/O ---- */

u8 lsc_pcie_read_reg8(struct lsc_pcie *pBrd, u8 bar_num, u32 offset);
u16 lsc_pcie_read_reg16(struct lsc_pcie *pBrd, u8 bar_num, u32 offset);
u32 lsc_pcie_read_reg32(struct lsc_pcie *pBrd, u8 bar_num, u32 offset);
u64 lsc_pcie_read_reg64(struct lsc_pcie *pBrd, u8 bar_num, u32 offset);

void lsc_pcie_write_reg8(struct lsc_pcie *pBrd, u8 bar_num, u32 offset, u8 val);
void lsc_pcie_write_reg16(struct lsc_pcie *pBrd, u8 bar_num, u32 offset, u16 val);
void lsc_pcie_write_reg32(struct lsc_pcie *pBrd, u8 bar_num, u32 offset, u32 val);
void lsc_pcie_write_reg64(struct lsc_pcie *pBrd, u8 bar_num, u32 offset, u64 val);

/* ---- PCI configuration space access ---- */

int lsc_pcie_read_config_byte(struct lsc_pcie *pBrd, u32 offset, u8 *val);
int lsc_pcie_write_config_byte(struct lsc_pcie *pBrd, u32 offset, u8 val);
int lsc_pcie_read_config_word(struct lsc_pcie *pBrd, u32 offset, u16 *val);
int lsc_pcie_write_config_word(struct lsc_pcie *pBrd, u32 offset, u16 val);
int lsc_pcie_read_config_dword(struct lsc_pcie *pBrd, u32 offset, u32 *val);
int lsc_pcie_write_config_dword(struct lsc_pcie *pBrd, u32 offset, u32 val);

/* ---- User interrupt vector configuration ---- */

/**
 * lsc_set_user_msi_vector_reg - Write a single user-interrupt MSI vector.
 * @pBrd:     Board context.
 * @user_idx: User interrupt index (0..15).
 * @msi_vec:  MSI vector number to assign.
 */
void lsc_set_user_msi_vector_reg(struct lsc_pcie *pBrd, int user_idx,
				 int msi_vec);

/**
 * lsc_program_user_msi_vector - Program all user-interrupt MSI vector mappings.
 * @pBrd: Board context (nr_dma_vecs and nr_user_vecs must be set; MSI only).
 */
void lsc_program_user_msi_vector(struct lsc_pcie *pBrd);

#endif /* __LSC_PCIE_CORE_H__ */
