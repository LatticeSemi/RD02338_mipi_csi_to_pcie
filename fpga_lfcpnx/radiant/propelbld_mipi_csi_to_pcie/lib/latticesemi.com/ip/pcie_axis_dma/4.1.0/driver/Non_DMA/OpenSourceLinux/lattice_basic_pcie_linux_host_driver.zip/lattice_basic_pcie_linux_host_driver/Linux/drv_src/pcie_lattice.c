// SPDX-License-Identifier: MIT
/*
 * ==================================================================
 *
 * >>>>>>>>>>>>>>>>>>>>> COPYRIGHT NOTICE <<<<<<<<<<<<<<<<<<<<<<<<<
 * ------------------------------------------------------------------
 * Copyright (c) 2025 by Lattice Semiconductor Corporation
 * ALL RIGHTS RESERVED
 * ------------------------------------------------------------------
 *
 * DISCLAIMER:
 *
 * LATTICE MAKES NO WARRANTIES ON THIS FILE OR ITS CONTENTS,
 * WHETHER EXPRESSED, IMPLIED, STATUTORY,
 * OR IN ANY PROVISION OF THE LATTICE PROPEL LICENSE AGREEMENT OR
 * COMMUNICATION WITH LICENSEE,
 * AND LATTICE SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
 * MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
 * LATTICE DOES NOT WARRANT THAT THE FUNCTIONS CONTAINED HEREIN WILL MEET
 * LICENSEE 'S REQUIREMENTS, OR THAT LICENSEE' S OPERATION OF ANY DEVICE,
 * SOFTWARE OR SYSTEM USING THIS FILE OR ITS CONTENTS WILL BE
 * UNINTERRUPTED OR ERROR FREE,
 * OR THAT DEFECTS HEREIN WILL BE CORRECTED.
 * LICENSEE ASSUMES RESPONSIBILITY FOR SELECTION OF MATERIALS TO ACHIEVE
 * ITS INTENDED RESULTS, AND FOR THE PROPER INSTALLATION, USE,
 * AND RESULTS OBTAINED THEREFROM.
 * LICENSEE ASSUMES THE ENTIRE RISK OF THE FILE AND ITS CONTENTS PROVING
 * DEFECTIVE OR FAILING TO PERFORM PROPERLY AND IN SUCH EVENT,
 * LICENSEE SHALL ASSUME THE ENTIRE COST AND RISK OF ANY REPAIR, SERVICE,
 * CORRECTION,
 * OR ANY OTHER LIABILITIES OR DAMAGES CAUSED BY OR ASSOCIATED WITH THE
 * SOFTWARE.IN NO EVENT SHALL LATTICE BE LIABLE TO ANY PARTY FOR DIRECT,
 * INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES,
 * INCLUDING LOST PROFITS,
 * ARISING OUT OF THE USE OF THIS FILE OR ITS CONTENTS,
 * EVEN IF LATTICE HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * LATTICE 'S SOLE LIABILITY, AND LICENSEE' S SOLE REMEDY,
 * IS SET FORTH ABOVE.
 * LATTICE DOES NOT WARRANT OR REPRESENT THAT THIS FILE,
 * ITS CONTENTS OR USE THEREOF DOES NOT INFRINGE ON THIRD PARTIES'
 * INTELLECTUAL PROPERTY RIGHTS, INCLUDING ANY PATENT. IT IS THE USER' S
 * RESPONSIBILITY TO VERIFY THE USER SOFTWARE DESIGN FOR CONSISTENCY AND
 * FUNCTIONALITY THROUGH THE USE OF FORMAL SOFTWARE VALIDATION METHODS.
 * ------------------------------------------------------------------
 *
 * ==================================================================
 */
#include <linux/init.h>
#include <linux/module.h>
#include <linux/pci.h>
#include <linux/interrupt.h>
#include <linux/fs.h>
#include <linux/uaccess.h>   /* copy_to_user */
#include "pcie_regs.h"
#include "pcie.h"
#include "../include/pcie_common.h"

 #ifdef pr_fmt
 #undef pr_fmt
#define pr_fmt(fmt)     KBUILD_MODNAME " %s: " fmt, __func__
 #endif

static int debug = 1;
module_param(debug, int, 0);
MODULE_PARM_DESC(debug, "enable debugging (0-1)");

static const char * const ch_msi_name[] = {
	"pcieMSI00", "pcieMSI01", "pcieMSI02", "pcieMSI03",
	"pcieMSI04", "pcieMSI05", "pcieMSI06", "pcieMSI07",
	"pcieMSI08", "pcieMSI09", "pcieMSI10", "pcieMSI11",
	"pcieMSI12", "pcieMSI13", "pcieMSI14", "pcieMSI15",
};

static const char * const ch_msix_name[] = {
	"pcieMSIX00", "pcieMSIX01", "pcieMSIX02", "pcieMSIX03",
	"pcieMSIX04", "pcieMSIX05", "pcieMSIX06", "pcieMSIX07",
	"pcieMSIX08", "pcieMSIX09", "pcieMSIX10", "pcieMSIX11",
	"pcieMSIX12", "pcieMSIX13", "pcieMSIX14", "pcieMSIX15",
};

static struct PCIE global_pcie;
static struct pci_device_id lattice_pci_id_tbl[] = {
		{0x1204, 0x9c25, 0x19AA, 0xE004,},
		{0x1204, 0x9c1d, 0x19AA, 0xE004,},
		{}                     /* Terminating entry */
};

MODULE_DEVICE_TABLE(pci, lattice_pci_id_tbl);

/*Info structure which use to store the driver info*/
struct PCIE_Board pBrd;

char gDrvrName[] = PCIE_DRIVER_NAME;

/**
 * Reads an 8-bit value from a specified BAR at a given offset.
 *
 * @param pBrd pointer to the Board to get hardware BAR address
 * @param bar_num BAR number to access
 * @param offset within the BAR to read from
 * @return 8 bit value read from the specified BAR and offset
 */
static uint8_t rdReg8(struct PCIE_Board *pBrd, uint8_t bar_num, uint32_t offset)
{
	return readb(pBrd->ctrlBARaddr[bar_num]  + offset);
}

/**
 * Reads a 16-bit value from a specified BAR at a given offset.
 *
 * @param pBrd pointer to the Board to get hardware BAR address
 * @param bar_num BAR number to access
 * @param offset within the BAR to read from
 * @return 16 bit value read from the specified BAR and offset
 */
static uint16_t rdReg16(struct PCIE_Board *pBrd, uint8_t bar_num, uint32_t offset)
{
	return readw(pBrd->ctrlBARaddr[bar_num]  + offset);
}

/**
 * Reads a 32-bit value from a specified BAR at a given offset.
 *
 * @param pBrd pointer to the Board to get hardware BAR address
 * @param bar_num BAR number to access
 * @param offset within the BAR to read from
 * @return 32 bit value read from the specified BAR and offset
 */
static uint32_t rdReg32(struct PCIE_Board *pBrd, uint8_t bar_num, uint32_t offset)
{
	return readl(pBrd->ctrlBARaddr[bar_num]  + offset);
}

/**
 * Reads a 64-bit value from a specified BAR at a given offset.
 *
 * @param pBrd pointer to the Board to get hardware BAR address
 * @param bar_num BAR number to access
 * @param offset within the BAR to read from
 * @return 64 bit value read from the specified BAR and offset
 */
static uint64_t rdReg64(struct PCIE_Board *pBrd, uint8_t bar_num, uint32_t offset)
{
	return readq(pBrd->ctrlBARaddr[bar_num]  + offset);
}

/**
 * Writes an 8-bit value to a specified BAR at a given offset
 *
 * @param pBrd pointer to Board to get hardware BAR address
 * @param bar_num BAR number to access
 * @param offset within the BAR to write to
 * @param val the 8 bit value to write
 */
static void wrReg8(struct PCIE_Board *pBrd, uint8_t bar_num, uint32_t offset, uint8_t val)
{
	writeb(val, pBrd->ctrlBARaddr[bar_num]  + offset);
	/*Make sure the writes go through before next operation*/
	wmb();
}

/**
 * Writes an 16-bit value to a specified BAR at a given offset
 *
 * @param pBrd pointer to Board to get hardware BAR address
 * @param bar_num BAR number to access
 * @param offset within the BAR to write to
 * @param val the 16 bit value to write
 */
static void wrReg16(struct PCIE_Board *pBrd, uint8_t bar_num, uint32_t offset, uint16_t val)
{
	writew(val, pBrd->ctrlBARaddr[bar_num]  + offset);
	/*Make sure the writes go through before next operation*/
	wmb();
}

/**
 * Writes a 32-bit value to a specified BAR at a given offset.
 *
 * @param pBrd pointer to Board to get hardware BAR address
 * @param bar_num BAR number to access
 * @param offset within the BAR to write to
 * @param val the 32 bit value to write
 */
static void wrReg32(struct PCIE_Board *pBrd, uint8_t bar_num, uint32_t offset, uint32_t val)
{
	writel(val, pBrd->ctrlBARaddr[bar_num] + offset);
	/*Make sure the writes go through before next operation*/
	wmb();
}

/**
 * Writes a 64-bit value to a specified BAR at a given offset.
 *
 * @param pBrd pointer to Board to get hardware BAR address
 * @param bar_num BAR number to access
 * @param offset within the BAR to write to
 * @param val the 64 bit value to write
 */
static void wrReg64(struct PCIE_Board *pBrd, uint8_t bar_num, uint32_t offset, uint64_t val)
{
	writeq(val, pBrd->ctrlBARaddr[bar_num] + offset);
	/*Make sure the writes go through before next operation*/
	wmb();
}

/**
 * rdPciCfgByte - Read an 8-bit value from the PCI configuration register at the specified offset.
 *
 * @param pBrd: Pointer to the struct PCIE_Board structure representing the PCIe board.
 * @param offset: Offset from the beginning of the PCI configuration space to read from.
 * @param val: Pointer to store the read value.
 *
 * This function reads the value from the PCI configuration register at the given offset.
 * If the read operation fails, an error code is returned.
 *
 * @return 0 on success, negative error code on failure.
 */
static int rdPciCfgByte(struct PCIE_Board *pBrd, uint32_t offset, uint8_t *val)
{
	int ret;

	ret = pci_read_config_byte(pBrd->pdev, offset, val);
	if (ret < 0)
		pr_info("Device Configuration Space Byte Read failed (ret=%d).", ret);

	return ret;
}

/**
 * wrPciCfgByte - Write an 8-bit value to the PCI configuration register at the specified offset.
 *
 * @param pBrd: Pointer to the struct PCIE_Board structure representing the PCIe board.
 * @param offset: Offset from the beginning of the PCI configuration space to write to.
 * @param val: Value to write to the register.
 *
 * This function writes the specified 8-bit value to the PCI configuration register
 * at the given offset. If the write operation fails, an error code is returned.
 *
 * @return 0 on success, negative error code on failure.
 */
static int wrPciCfgByte(struct PCIE_Board *pBrd, uint32_t offset, uint8_t val)
{
	int ret;

	ret = pci_write_config_byte(pBrd->pdev, offset, val);
	if (ret < 0)
		pr_info("Device Configuration Space Byte Write failed (ret=%d).", ret);

	return ret;
}

/**
 * rdPciCfgWord - Read a 16-bit value from the PCI configuration register at the specified offset.
 *
 * @param pBrd: Pointer to the struct PCIE_Board structure representing the PCIe board.
 * @param offset: Offset from the beginning of the PCI configuration space to read from.
 * @param val: Pointer to store the read value.
 *
 * This function reads the value from the PCI configuration register at the given offset.
 * If the read operation fails, an error code is returned.
 *
 * @return 0 on success, negative error code on failure.
 */
static int rdPciCfgWord(struct PCIE_Board *pBrd, uint32_t offset, uint16_t *val)
{
	int ret;

	ret = pci_read_config_word(pBrd->pdev, offset, val);
	if (ret < 0)
		pr_info("Device Configuration Space Word Read failed (ret=%d).", ret);

	return ret;
}

/**
 * wrPciCfgWord - Write a 16-bit value to the PCI configuration register at the specified offset.
 *
 * @param pBrd: Pointer to the struct PCIE_Board structure representing the PCIe board.
 * @param offset: Offset from the beginning of the PCI configuration space to write to.
 * @param val: Value to write to the register.
 *
 * This function writes the specified 16-bit value to the PCI configuration register
 * at the given offset. If the write operation fails, an error code is returned.
 *
 * @return 0 on success, negative error code on failure.
 */
static int wrPciCfgWord(struct PCIE_Board *pBrd, uint32_t offset, uint16_t val)
{
	int ret;

	ret = pci_write_config_word(pBrd->pdev, offset, val);
	if (ret < 0)
		pr_info("Device Configuration Space Word Write failed (ret=%d).", ret);

	return ret;
}

/**
 * rdPciCfg - Read a 32-bit value from the PCI configuration register at the specified offset.
 *
 * @param pBrd: Pointer to the struct PCIE_Board structure representing the PCIe board.
 * @param offset: Offset from the beginning of the PCI configuration space to read from.
 * @param val: Pointer to store the read value.
 *
 * This function reads the value from the PCI configuration register at the given offset.
 * If the read operation fails, an error code is returned.
 *
 * @return 0 on success, negative error code on failure.
 */
static int rdPciCfg(struct PCIE_Board *pBrd, uint32_t offset, uint32_t *val)
{
	int ret;

	ret = pci_read_config_dword(pBrd->pdev, offset, val);
	if (ret < 0)
		pr_info("Device Configuration Space Dword Read failed (ret=%d).", ret);

	return ret;
}

/**
 * wrPciCfg - Write a 32-bit value to the PCI configuration register.
 *
 * @param pBrd: Pointer to the struct PCIE_Board structure representing the PCIe board.
 * @param offset: Offset from the beginning of the PCI configuration space to write to.
 * @param val: Value to write to the register.
 *
 * This function writes the specified 32-bit value to the PCI configuration register
 * at the given offset. If the write operation fails, an error code is returned.
 *
 * @return 0 on success, negative error code on failure.
 */
static int wrPciCfg(struct PCIE_Board *pBrd, uint32_t offset, uint32_t val)
{
	int ret;

	ret = pci_write_config_dword(pBrd->pdev, offset, val);
	if (ret < 0)
		pr_info("Device Configuration Space Dword Write failed (ret=%d).", ret);

	return ret;
}

/**
 * @brief IRQ handler for PCIe operations.
 *
 * This function handles the interrupts generated by the MSI/MSIX/INTx.
 *
 * @param irq The interrupt request number.
 * @param arg A pointer to the PCIe board structure.
 * @return IRQ_HANDLED indicating the interrupt was handled.
 *
 * The function performs the following steps:
 * - Prints debug information if debug is enabled.
 * - Checks if the interrupt vector matches the expected value.
 */
static irqreturn_t PcieIrqHandler(int irq, void *arg)
{
	struct PCIE_Board *pBrd = (struct PCIE_Board *)arg;

	if (debug) {
		if (pBrd->irq_vec[0] == irq)
			pr_info("MSI/MSIX VECTOR 0 DETECTED, irq vec:%d\n", irq);
		else if (pBrd->irq_vec[1] == irq)
			pr_info("MSI/MSIX VECTOR 1 DETECTED, irq vec:%d\n", irq);
		else if (pBrd->irq_vec[2] == irq)
			pr_info("MSI/MSIX VECTOR 2 DETECTED, irq vec:%d\n", irq);
		else if (pBrd->irq_vec[3] == irq)
			pr_info("MSI/MSIX VECTOR 3 DETECTED, irq vec:%d\n", irq);
	}

	return IRQ_HANDLED;
}

/**
 * @brief Determine the device mode based on DMA support and interrupt configuration.
 *
 * This function checks the device's DMA support capability and interrupt configuration
 * (MSI/MSI-X) to determine the appropriate device mode.
 *
 * @param pBrd: Pointer to the PCIE_Board structure representing the PCIe board.
 *
 * @return deviceMode_t: The device mode:
 *         - DMA: DMA mode (when DMA is supported)
 *         - BRIDGE_MSI: Non-DMA mode with MSI interrupts
 *         - BRIDGE_MSIX: Non-DMA mode with MSI-X interrupts
 *         - TLP: TLP mode (Non-DMA + Non-MSI)
 */
static deviceMode_t PcieGetDeviceMode(struct PCIE_Board *pBrd)
{
	uint32_t dma_sup = 0;
	uint8_t bar_num = BAR0;

	if (pBrd->msi || pBrd->msix) {
		dma_sup = rdReg32(pBrd, bar_num, GEN_STS_REG);
		if ((dma_sup & GEN_STS_DMA_SUPPORT_MASK) == GEN_STS_DMA_NO_SUP) {
			if (pBrd->msi)
				return BRIDGE_MSI; // Non-DMA + MSI
			else
				return BRIDGE_MSIX; // Non-DMA + MSI-X
		} else {
			return DMA; // DMA mode
		}
	} else {
		return TLP; // Non-DMA + Non-MSI, TLP Mode
	}
}

/**
 * @brief Parse PCIe Link Capabilities from the PCI configuration space.
 *
 * This function traverses the PCI capability list to find the PCI Express capability
 * structure and extracts link-related information including:
 * - Maximum payload size
 * - Maximum read request size
 * - Read completion boundary (RCB) size
 * - Link width
 *
 * @param pBrd: Pointer to the PCIE_Board structure representing the PCIe board.
 *
 * @return 0 on success (PCIe capability found and parsed), -1 on failure
 *         (capability not found or error reading configuration space).
 */
static int ParsePCIeLinkCap(struct PCIE_Board *pBrd)
{
	uint32_t pci_cap_list_sup = 0;
	uint32_t pci_cap_ptr = 0;
	uint32_t pci_cap_id = 0;
	uint32_t pci_cap_data = 0;
	uint32_t pci_cap_read_data = 0;
	bool found = false;
	int ret;

	ret = rdPciCfgWord(pBrd, PCI_STATUS, (uint16_t *)&pci_cap_list_sup);
	if (ret < 0)
		return ret;
	if ((pci_cap_list_sup & PCI_STATUS_CAP_LIST) == 0) {
		pr_err("PCIe Capabilities Structure not supported!\n");
		return -1;
	}
	ret = rdPciCfgByte(pBrd, PCI_CAPABILITY_LIST, (uint8_t *)&pci_cap_ptr);
	if (ret < 0)
		return ret;
	while (pci_cap_ptr != 0) {
		ret = rdPciCfgByte(pBrd, pci_cap_ptr, (uint8_t *)&pci_cap_id);
		if (ret < 0)
			return ret;
		switch (pci_cap_id) {
		case PCI_CAP_ID_PM:
			pr_info("Power Management Capability Structure @ %x\n", pci_cap_ptr);
			// Handle Power Management Capability
			break;
		case PCI_CAP_ID_AGP:
			pr_info("AGP Capability Structure @ %x\n", pci_cap_ptr);
			// Handle AGP Capability
			break;
		case PCI_CAP_ID_VPD:
			pr_info("VPD Capability Structure @ %x\n", pci_cap_ptr);
			// Handle VPD Capability
			break;
		case PCI_CAP_ID_SLOTID:
			pr_info("Slot ID Capability Structure @ %x\n", pci_cap_ptr);
			// Handle Slot ID Capability
			break;
		case PCI_CAP_ID_MSI:
			pr_info("MSI Capability Structure @ %x\n", pci_cap_ptr);
			// Handle MSI Capability
			break;
		case PCI_CAP_ID_CHSWP:
			pr_info("CompactPCI Hot Swap Capability Structure @ %x\n", pci_cap_ptr);
			// Handle CompactPCI Hot Swap Capability
			break;
		case PCI_CAP_ID_PCIX:
			pr_info("PCI-X Capability Structure @ %x\n", pci_cap_ptr);
			// Handle PCI-X Capability
			break;
		case PCI_CAP_ID_HT:
			pr_info("HyperTransport Capability Structure @ %x\n", pci_cap_ptr);
			// Handle HyperTransport Capability
			break;
		case PCI_CAP_ID_VNDR:
			pr_info("Vendor Specific Capability Structure @ %x\n", pci_cap_ptr);
			// Handle Vendor Specific Capability
			break;
		case PCI_CAP_ID_DBG:
			pr_info("Debug Port Capability Structure @ %x\n", pci_cap_ptr);
			// Handle Debug Port Capability
			break;
		case PCI_CAP_ID_CCRC:
			pr_info("CompactPCI Central Resource Control Capability Structure @ %x\n",
				pci_cap_ptr);
			// Handle CompactPCI Central Resource Control Capability
			break;
		case PCI_CAP_ID_SHPC:
			pr_info("Bridge subsystem vendor/device ID Capability Structure @ %x\n", pci_cap_ptr);
			// Handle Bridge subsystem vendor/device ID
			break;
		case PCI_CAP_ID_SSVID:
			pr_info("PCI Hot Plug Capability Structure @ %x\n", pci_cap_ptr);
			// Handle PCI Hot Plug Capability
			break;
		case PCI_CAP_ID_AGP3:
			pr_info("AGP Target PCI-PCI Bridge Capability Structure @ %x\n", pci_cap_ptr);
			// Handle AGP Target PCI-PCI Bridge Capability
			break;
		case PCI_CAP_ID_EXP:
			pr_info("PCI Express Capability Structure @ %x\n", pci_cap_ptr);
			ret = rdPciCfgWord(pBrd, pci_cap_ptr + PCI_EXP_DEVCTL, (uint16_t *)&pci_cap_data);
			if (ret < 0)
				return ret;
			pci_cap_read_data = (pci_cap_data & PCI_EXP_DEVCTL_PAYLOAD);
			switch (pci_cap_read_data) {
				case PCI_EXP_DEVCTL_PAYLOAD_128B:
					pBrd->PCIeMaxPayloadSize = 128;
					break;
				case PCI_EXP_DEVCTL_PAYLOAD_256B:
					pBrd->PCIeMaxPayloadSize = 256;
					break;
				case PCI_EXP_DEVCTL_PAYLOAD_512B:
					pBrd->PCIeMaxPayloadSize = 512;
					break;
				case PCI_EXP_DEVCTL_PAYLOAD_1024B:
					pBrd->PCIeMaxPayloadSize = 1024;
					break;
				case PCI_EXP_DEVCTL_PAYLOAD_2048B:
					pBrd->PCIeMaxPayloadSize = 2048;
					break;
				case PCI_EXP_DEVCTL_PAYLOAD_4096B:
					pBrd->PCIeMaxPayloadSize = 4096;
					break;
				default:
					pBrd->PCIeMaxPayloadSize = 128;
			}
			pci_cap_read_data = (pci_cap_data & PCI_EXP_DEVCTL_READRQ);
			switch (pci_cap_read_data) {
				case PCI_EXP_DEVCTL_READRQ_128B:
					pBrd->PCIeMaxReadReqSize = 128;
					break;
				case PCI_EXP_DEVCTL_READRQ_256B:
					pBrd->PCIeMaxReadReqSize = 256;
					break;
				case PCI_EXP_DEVCTL_READRQ_512B:
					pBrd->PCIeMaxReadReqSize = 512;
					break;
				case PCI_EXP_DEVCTL_READRQ_1024B:
					pBrd->PCIeMaxReadReqSize = 1024;
					break;
				case PCI_EXP_DEVCTL_READRQ_2048B:
					pBrd->PCIeMaxReadReqSize = 2048;
					break;
				case PCI_EXP_DEVCTL_READRQ_4096B:
					pBrd->PCIeMaxReadReqSize = 4096;
					break;
				default:
					pBrd->PCIeMaxReadReqSize = 128;
			}
			ret = rdPciCfgWord(pBrd, pci_cap_ptr + PCI_EXP_LNKCTL, (uint16_t *)&pci_cap_data);
			if (ret < 0)
				return ret;
			if (pci_cap_data & PCI_EXP_LNKCTL_RCB)
				pBrd->PCIeRCBSize = 128;
			else
				pBrd->PCIeRCBSize = 64;

			ret = rdPciCfgWord(pBrd, pci_cap_ptr + PCI_EXP_LNKSTA, (uint16_t *)&pci_cap_data);
			if (ret < 0)
				return ret;
			pBrd->PCIeLinkWidth = (pci_cap_data & PCI_EXP_LNKSTA_NLW) >> PCI_EXP_LNKSTA_NLW_SHIFT;

			pr_info("MaxPayloadSize = %dB\n", pBrd->PCIeMaxPayloadSize);
			pr_info("MaxReadReqSize = %dB\n", pBrd->PCIeMaxReadReqSize);
			pr_info("RCBSize = %dB\n", pBrd->PCIeRCBSize);
			pr_info("LinkWidth = x%d\n", pBrd->PCIeLinkWidth);
			found = true;
			// Slot Registers and Root Registers not implemented by our EndPoint core
			break;
		default:
			return(-1);
		}
		ret = rdPciCfgByte(pBrd, (pci_cap_ptr + 1), (uint8_t *)&pci_cap_ptr);
		if (ret < 0)
			return ret;
	}
	if (found)
		return 0;
	else
		return -1;
}

/**
 * @brief Allocate a user interrupt vector to a specific interrupt number.
 *
 * This function configures the user interrupt vector mapping by writing the vector
 * value to the appropriate register based on the user interrupt number (0-15).
 * The function handles the register offset selection and bit field manipulation
 * to update the vector value without affecting other interrupt vectors.
 *
 * @param pBrd: Pointer to the PCIE_Board structure representing the PCIe board.
 * @param usr_int: User interrupt number (0-15). Values outside this range will
 *                 result in an error message.
 * @param vec_val: The interrupt vector value to assign to the specified user interrupt.
 *
 * The function maps user interrupts to register offsets as follows:
 * - Interrupts 0-3:   USR_INT_VEC_P1 register
 * - Interrupts 4-7:   USR_INT_VEC_P2 register
 * - Interrupts 8-11:  USR_INT_VEC_P3 register
 * - Interrupts 12-15: USR_INT_VEC_P4 register
 */
static void PcieUsrVectorAlloc(struct PCIE_Board *pBrd, int usr_int, int vec_val)
{
	uint8_t bar_num = BAR0;
	int shift_val = 0;
	uint32_t reg_val = 0; // used to store the original register value

	if ((usr_int >= 0) && (usr_int < 16)) {
		uint32_t reg_offset;

		if (usr_int >= 0 && usr_int <= 3) {
			reg_offset = USR_INT_VEC_P1_REG;
		} else if (usr_int >= 4 && usr_int <= 7) {
			reg_offset = USR_INT_VEC_P2_REG;
		} else if (usr_int >= 8 && usr_int <= 11) {
			reg_offset = USR_INT_VEC_P3_REG;
		} else { // usr_int >= 12 && usr_int <= 15
			reg_offset = USR_INT_VEC_P4_REG;
		}
		reg_val = rdReg32(pBrd, bar_num, reg_offset);
		shift_val = (usr_int % 4) * 8;
		reg_val = reg_val & ~(USRx_INT_VEC << shift_val); // Clear the relevant 8 bits
		vec_val = reg_val | (vec_val << shift_val);
		wrReg32(pBrd, bar_num, reg_offset, vec_val);
	} else {
		pr_err("User Interrupt Vector Number %d is out of range!\n", usr_int);
	}
}

/**
 * @brief Configure MSI or MSI-X interrupts for the PCIe device.
 *
 * This function allocates and configures Message Signaled Interrupts (MSI) or
 * Extended Message Signaled Interrupts (MSI-X) for the PCIe device. It allocates
 * interrupt vectors, retrieves the assigned IRQ numbers, and registers interrupt
 * handlers for each vector.
 *
 * @param pBrd: Pointer to the PCIE_Board structure representing the PCIe board.
 * @param use_msix: Boolean flag indicating whether to use MSI-X (true) or MSI (false).
 *
 * @return 0 on success, negative error code on failure:
 *         - -ENODEV: Failed to allocate interrupt vectors
 *         - Other errors from request_irq() if interrupt registration fails
 *
 * On success, the function:
 * - Allocates interrupt vectors (up to MAX_NUM_MSI_VEC)
 * - Stores the IRQ numbers in pBrd->irq_vec[]
 * - Registers interrupt handlers for each vector
 * - Sets pBrd->msi or pBrd->msix flag accordingly
 */
static int PcieConfigureMsi(struct PCIE_Board *pBrd, bool use_msix)
{
	int vec_cnt;
	int i, ret;
	const char *type_str = use_msix ? "MSI-X" : "MSI";
	int flags = use_msix ? PCI_IRQ_MSIX : PCI_IRQ_MSI;
	const char * const *names = use_msix ? ch_msix_name : ch_msi_name;

	vec_cnt = pci_alloc_irq_vectors(pBrd->pdev, 1, MAX_NUM_MSI_VEC, flags);
	if (vec_cnt < 0) {
		pr_err("Failed to get %s interrupts.\n", type_str);
		pBrd->num_irqs = 0;
		return -ENODEV;
	}

	pr_info("%s vector count = %d\n", type_str, vec_cnt);

	pBrd->num_irqs = vec_cnt;

	for (i = 0; i < pBrd->num_irqs; i++)
		pBrd->irq_vec[i] = pci_irq_vector(pBrd->pdev, i);

	if (debug)
		pr_info("Attach %s interrupt\n", type_str);

	for (i = 0; i < pBrd->num_irqs; i++) {
		ret = request_irq(pBrd->irq_vec[i], /* the IRQ assigned to us */
				  PcieIrqHandler,           /* the ISR routine to invoke */
				  0,                        /* flags - none needed for MSI/MSIX */
				  names[i],                 /* a name to show in /proc/interrupts */
				  pBrd);                    /* arg to pass to our ISR,
							     * must pass exact same value to free_irq()
							     */
		if (ret) {
			pr_err("Can't request %s IRQ %d, name: %s\n",
			       type_str, pBrd->irq_vec[i], names[i]);
		} else {
			if (use_msix)
				pBrd->msix = true;
			else
				pBrd->msi = true;
			if (debug)
				pr_info("%s IRQ = %d, name = %s\n",
					type_str, pBrd->irq_vec[i], names[i]);
		}
	}

	return 0;
}

/**
 * initBoard - Initialize a PCIe board structure.
 *
 * @param PCI_Dev_Cfg: Pointer to the PCI device configuration structure.
 * @param devID: Pointer to the device ID.
 * This is called when probe() has found a matching PCI device (via the PCI subsystem
 * probing for boards on behalf of the driver)
 * This function initializes a PCIe board structure. It populates the board information,
 * sets up memory mappings, and retrieves PCIe link characteristics. If successful, it
 * returns a pointer to the initialized board structure; otherwise, it returns NULL.
 *
 * @return Pointer to the initialized struct PCIE_Board structure, or NULL on failure.
 */
static struct PCIE_Board *initBoard(struct pci_dev *PCI_Dev_Cfg, void *devID)
{
	int i, ret;
	uint8_t irq, intPin = 0;
	uint16_t SubSystem, VendorID, DeviceID, CommandReg;
	struct PCIE_Board *pBrd;
	struct PCI_Dev_BAR *pBAR, *p;

	if (debug)
		pr_info("enter %s\n", __func__);

	if (global_pcie.numBoards >= NUM_BOARDS) {
		pr_err("Too many boards! Increase NUM_BOARDS!\n");
		return NULL;
	}
	pBrd = &global_pcie.Board[global_pcie.numBoards];
	memset(pBrd, 0, sizeof(struct PCIE_Board));
	if (pci_read_config_word(PCI_Dev_Cfg, PCI_VENDOR_ID, &VendorID)) {
		pr_err("Board CFG access failed!\n");
		return NULL;
	}
	if (VendorID != 0x1204) {
		pr_err("Vendor ID (0x%x) of the board not Lattice!\n", VendorID);
		return NULL;
	}
	if (pci_read_config_word(PCI_Dev_Cfg, PCI_DEVICE_ID, &DeviceID)) {
		pr_err("Board CFG access failed!\n");
		return NULL;
	}
	if (pci_read_config_word(PCI_Dev_Cfg, PCI_SUBSYSTEM_ID, &SubSystem)) {
		pr_err("Board CFG access failed!\n");
		return NULL;
	}
	pr_info("DeviceID= 0x%x, SubSystemID= 0x%x\n", DeviceID, SubSystem);

	if (pci_read_config_word(PCI_Dev_Cfg, PCI_COMMAND, &CommandReg)) {
		pr_err("Board CFG access failed!\n");
		return NULL;
	}
	/* Safety check: Ensure Memory Space is enabled.
	 * Note: pci_enable_device() should have already set this,
	 * but we verify and set it as a safety measure.
	 */
	if ((CommandReg & PCI_COMMAND_MEMORY) == 0) {
		pr_info("Memory Space Enable not set. Setting now");
		pci_write_config_word(PCI_Dev_Cfg, PCI_COMMAND,
				      CommandReg | PCI_COMMAND_MEMORY);
	}

	pBrd->ID = DeviceID;
	pBrd->pdev = PCI_Dev_Cfg;
	pBrd->majorNum = MAJOR(global_pcie.drvrDevNum);
	pBrd->minorNum = MINOR(global_pcie.drvrDevNum) + global_pcie.numBoards;
	atomic_set(&(pBrd->OpenToken), 1);                 // initialize "open" token to available
	pBrd->msi = false;
	pBrd->msix = false;
	pBrd->ctrlBAR = 0;

	// BAR will be mmap'ed into user space for the driver interface to access.
	pBrd->mmapBAR = pBrd->ctrlBAR;

	// Legacy Interrupt
	// Read PCI_INTERRUPT_PIN to check if device has interrupt capability
	if (pci_read_config_byte(PCI_Dev_Cfg, PCI_INTERRUPT_PIN, &intPin) == 0) {
		if (debug)
			pr_info("PCI_INTERRUPT_PIN = %d\n", intPin);

		// Only read PCI_INTERRUPT_LINE if interrupt pin is assigned (non-zero)
		if (intPin != 0) {
			// Read PCI_INTERRUPT_LINE (IRQ number assigned by BIOS/OS)
			if (pci_read_config_byte(PCI_Dev_Cfg, PCI_INTERRUPT_LINE, &irq))
				pBrd->IRQ = -1;  // read failed
			else
				pBrd->IRQ = irq;
		} else {
			// No interrupt pin assigned, no need to read interrupt line
			pBrd->IRQ = -1;
			if (debug)
				pr_info("No interrupt pin assigned, skipping IRQ read\n");
		}
	} else {
		// Failed to read PCI_INTERRUPT_PIN
		if (debug)
			pr_info("Failed to read PCI_INTERRUPT_PIN\n");
		pBrd->IRQ = -1;  // no interrupt
	}

	if (debug)
		pr_info("Board[] =%d, Legacy IRQ = %d\n", global_pcie.numBoards, pBrd->IRQ);

	// Check for MSI or MSI-X capability
	if (pci_find_capability(pBrd->pdev, PCI_CAP_ID_MSIX)) {
		pr_info("MSI-X capability detected.");
		if (PcieConfigureMsi(pBrd, true))
			return NULL;  /* error */
	} else if (pci_find_capability(pBrd->pdev, PCI_CAP_ID_MSI)) {
		pr_info("MSI capability detected.");
		if (PcieConfigureMsi(pBrd, false))
			return NULL;  /* error */
	}

	if (!pBrd->msi && !pBrd->msix) {
		// Use INTx legacy interrupts
		if (pBrd->IRQ != -1) {
			if (debug)
				pr_info("MSI/MSI-X not supported, falling back to INTx.\nAttach INTx interrupt\n");
			ret = request_irq(pBrd->pdev->irq, PcieIrqHandler, IRQF_SHARED, "pcieINTx", pBrd);
			if (ret) {
				if (debug)
					pr_err("can't get INTx IRQ %d\n", pBrd->IRQ);
				pBrd->IRQ = -1;
			} else {
				pBrd->IRQ = pBrd->pdev->irq;
				if (debug)
					pr_info("INTx IRQ=%d\n", pBrd->IRQ);
			}
		} else {
			if (debug)
				pr_info("Legacy interrupt not enabled.\n");
		}
	}

	/* Get info on all the PCI BAR registers */
	pBrd->numBars = 0;  // initialize
	for (i = 0; i < NUM_BARS; i++) {
		p = &(pBrd->Dev_BARs[i]);
		p->pci_start = pci_resource_start(PCI_Dev_Cfg, i);
		p->pci_end   = pci_resource_end(PCI_Dev_Cfg, i);
		p->len       = pci_resource_len(PCI_Dev_Cfg, i);
		p->pci_flags = pci_resource_flags(PCI_Dev_Cfg, i);

		if ((p->pci_start > 0) && (p->pci_end > 0)) {
			++(pBrd->numBars);
			p->bar = i;
			p->pci_addr = (void *)p->pci_start;
			p->memType = p->pci_flags;
			if (debug) {
				pr_info("BAR=%d\n", i);
				pr_info("start=%llx\n", p->pci_start);
				pr_info("end=%llx\n", p->pci_end);
				pr_info("len=0x%llx\n", p->len);
				pr_info("flags=0x%llx\n", p->pci_flags);
			}
		}
	}
	// Map the BAR into kernel space so the driver can access registers.
	for (i = 0; i < pBrd->numBars; i++) {
		pBAR = &(pBrd->Dev_BARs[i]);
		if (pBAR->pci_start) {
			//pci_start:PCI bus start address, len:BAR size
			pBrd->ctrlBARaddr[i] = ioremap(pBAR->pci_start, pBAR->len);
			pBAR->kvm_addr = pBrd->ctrlBARaddr[i];
			if (pBrd->ctrlBARaddr[i]) {
				pr_info("Mapped BAR %d into kernel space success with ioremap\n", i);
			} else {
				pr_err("error with ioremap for BAR %d\n", i);
				return NULL;
			}
		} else {
			pr_err("error ctrlBAR %d not avail!\n", i);
			return NULL;
		}
	}
	// Get information about the PCIe link characteristics
	ParsePCIeLinkCap(pBrd);

	++global_pcie.numBoards;
	pr_info("InitBoard: Done!\n");
	return pBrd;
}

/**
 * Open the PCIe device and provide direct access to board resources.
 *
 * This function is responsible for opening the PCIe device. It extracts the board
 * number and function number from the minor number, checks if the board is configured
 * correctly, and manages the open token to prevent multiple simultaneous accesses.
 * The private_data field of the file structure is set to point to the board structure
 * for subsequent operations.
 *
 * @param inode: Pointer to the inode structure.
 * @param filp: Pointer to the file structure.
 * @return 0 on success, negative error code on failure
 */
static int PcieOpen(struct inode *inode, struct file *filp)
{
	uint32_t brdNum;
	uint32_t funcNum;
	struct PCIE_Board *pBrd;

	/* Extract the board number from the minor number */
	brdNum = MINOR_TO_BOARD(iminor(inode));
	funcNum = MINOR_TO_FUNCTION(iminor(inode));
	if (debug)
		pr_info("board#=%d  func#=%d\n", brdNum, funcNum);
	if (brdNum >= global_pcie.numBoards) {
		pr_err("brd# %d No such board!\n", brdNum);
		return(-ENODEV);
	}
	/* This is what the user wants to access */
	pBrd = &global_pcie.Board[brdNum];
	if (pBrd->ID == 0) {
		pr_err("brd# %d not configured correctly!\n", brdNum);
		return(-ENODEV);  // Board[] entry not configured correctly
	}
	if (!atomic_dec_and_test(&pBrd->OpenToken)) {
		pr_err("brd# %d already open!\n", brdNum);
		atomic_inc(&pBrd->OpenToken); // restore to prev value
		return(-EBUSY);
	}
	/* Provide direct access to the board's resources in future system calls */
	filp->private_data = pBrd;
	pBrd->function = funcNum;

	return 0;
}

/**
 * Release resources associated with a PCIe board.
 *
 * @param inode: Pointer to the inode structure.
 * @param filp: Pointer to the file structure.
 *
 * This function is called when a file associated with a PCIe board is closed.
 * It releases allocated resources, including the open token.
 * The board becomes available for other processes to open.
 *
 * @return 0 on success.
 */
static int PcieRelease(struct inode *inode, struct file *filp)
{
	struct PCIE_Board *pBrd = filp->private_data;
	uint32_t mnr = iminor(inode);

	if (debug)
		pr_info("closing board=%d  function=%x\n", MINOR_TO_BOARD(mnr), MINOR_TO_FUNCTION(mnr));

	// Give back the token and let someone else open the board
	atomic_inc(&(pBrd->OpenToken));

	return 0;
}

/**
 * Custom IOCTL handler for PCIe operations
 *
 * @param filp: Pointer to the file structure
 * @param cmd: IOCTL command
 * @param arg: Argument passed from user space
 *
 * This function handles various IOCTL commands related to PCIe.
 * It interacts with the struct PCIE_Board structure and performs operations
 * such as getting version information, retrieving resources, reading/writing
 * data, and more.
 *
 * @return 0 on success, negative error code on failure
 */
static long PcieIoctl(struct file *filp, unsigned int cmd, unsigned long arg)
{
	struct PCIE_Board *pBrd;
	// PCIResourceInfo_t *pInfo;
	struct PCIResourceInfo *pInfo;

	// rw_ioctl_t rw;
	struct rw_ioctl rw;
	// usr_vec_data_t usr_vec;
	struct usr_vec_data usr_vec;
	int i;
	int ret;

	uint32_t deviceMode = 0;

	pBrd = filp->private_data;
	switch (cmd) {
		case IOCTL_PCIE_GET_DEVICE_MODE:
			deviceMode = (int)PcieGetDeviceMode(pBrd);
			if (copy_to_user((void *)arg, &deviceMode, sizeof(deviceMode)) != 0)
				return -EFAULT;
			break;

		case IOCTL_PCIE_GET_RESOURCES:
			pInfo = kzalloc(sizeof(struct PCIResourceInfo), GFP_KERNEL);
			if (pInfo == NULL)
				return -EFAULT;

			if (pBrd->IRQ > 0)
				pInfo->hasInterrupt = true;
			else
				pInfo->hasInterrupt = false;

			pInfo->intrVector = pBrd->IRQ;
			pInfo->numBARs = pBrd->numBars;

			/* Populate bus, device, and function numbers */
			pInfo->bus = pBrd->pdev->bus->number;
			pInfo->device = PCI_SLOT(pBrd->pdev->devfn);
			pInfo->function = PCI_FUNC(pBrd->pdev->devfn);

			for (i = 0; i < MAX_PCI_BARS; i++) {
				pInfo->BAR[i].nBAR = pBrd->Dev_BARs[i].bar;
				pInfo->BAR[i].physStartAddr = (uint64_t)pBrd->Dev_BARs[i].pci_addr;
				pInfo->BAR[i].size = pBrd->Dev_BARs[i].len;
				pInfo->BAR[i].memMapped = (pBrd->Dev_BARs[i].kvm_addr) ? 1 : 0;
				pInfo->BAR[i].flags = (uint16_t)(pBrd->Dev_BARs[i].pci_flags);
				pInfo->BAR[i].type = (uint8_t)((pBrd->Dev_BARs[i].memType) >> 8);
			}
			for (i = 0; i < 0x100; ++i)
				pci_read_config_byte(pBrd->pdev, i, &(pInfo->PCICfgReg[i]));
			if (copy_to_user((void *)arg, (void *)pInfo, sizeof(struct PCIResourceInfo)) != 0)
				return -EFAULT;

			kfree(pInfo);
			break;

		case IOCTL_PCIE_READ_8BIT:
			if (copy_from_user(&rw, (struct rw_ioctl *)arg, sizeof(struct rw_ioctl)))
				return -EACCES;

			rw.value = rdReg8(pBrd, rw.bar_num, rw.reg);
			if (copy_to_user((void *)arg, &rw, sizeof(struct rw_ioctl))) {
				pr_err("copy_to_user failed.\n");
				return -EACCES;
			}
			break;

		case IOCTL_PCIE_READ_16BIT:
			if (copy_from_user(&rw, (struct rw_ioctl *)arg, sizeof(struct rw_ioctl)))
				return -EACCES;

			rw.value = rdReg16(pBrd, rw.bar_num, rw.reg);
			if (copy_to_user((void *)arg, &rw, sizeof(struct rw_ioctl))) {
				pr_err("copy_to_user failed.\n");
				return -EACCES;
			}
			break;

		case IOCTL_PCIE_READ_32BIT:
			if (copy_from_user(&rw, (struct rw_ioctl *)arg, sizeof(struct rw_ioctl)))
				return -EACCES;

			rw.value = rdReg32(pBrd, rw.bar_num, rw.reg);
			if (copy_to_user((void *)arg, &rw, sizeof(struct rw_ioctl))) {
				pr_err("copy_to_user failed.\n");
				return -EACCES;
			}
			break;

		case IOCTL_PCIE_READ_64BIT:
			if (copy_from_user(&rw, (struct rw_ioctl *)arg, sizeof(struct rw_ioctl)))
				return -EACCES;

			rw.value = rdReg64(pBrd, rw.bar_num, rw.reg);
			if (copy_to_user((void *)arg, &rw, sizeof(struct rw_ioctl))) {
				pr_err("copy_to_user failed.\n");
				return -EACCES;
			}
			break;

		case IOCTL_PCIE_WRITE_8BIT:
			if (copy_from_user(&rw, (struct rw_ioctl *)arg, sizeof(struct rw_ioctl))) {
				pr_err("w8 copy_from_user failed.\n");
				return -EACCES;
			}
			wrReg8(pBrd, rw.bar_num, rw.reg, rw.value);
			break;

		case IOCTL_PCIE_WRITE_16BIT:
			if (copy_from_user(&rw, (struct rw_ioctl *)arg, sizeof(struct rw_ioctl))) {
				pr_err("w16 copy_from_user failed.\n");
				return -EACCES;
			}
			wrReg16(pBrd, rw.bar_num, rw.reg, rw.value);
			break;

		case IOCTL_PCIE_WRITE_32BIT:
			if (copy_from_user(&rw, (struct rw_ioctl *)arg, sizeof(struct rw_ioctl))) {
				pr_err("w32 copy_from_user failed.\n");
				return -EACCES;
			}
			wrReg32(pBrd, rw.bar_num, rw.reg, rw.value);
			break;

		case IOCTL_PCIE_WRITE_64BIT:
			if (copy_from_user(&rw, (struct rw_ioctl *)arg, sizeof(struct rw_ioctl))) {
				pr_err("w64 copy_from_user failed.\n");
				return -EACCES;
			}
			wrReg64(pBrd, rw.bar_num, rw.reg, rw.value);
			break;

	case IOCTL_PCIE_CFG_REG_READ_8Bit:
		if (copy_from_user(&rw, (struct rw_ioctl *)arg, sizeof(struct rw_ioctl))) {
			pr_info("unable to access user buffer\n");
			return -EACCES;
		}
		ret = rdPciCfgByte(pBrd, rw.reg, (uint8_t *)&rw.value);
		if (ret < 0)
			return ret;
		if (copy_to_user((void *)arg, &rw, sizeof(struct rw_ioctl))) {
			pr_info("unable to update buffer to user\n");
			return -EACCES;
		}
		break;

	case IOCTL_PCIE_CFG_REG_WRITE_8Bit:
		if (copy_from_user(&rw, (struct rw_ioctl *)arg, sizeof(struct rw_ioctl))) {
			pr_info("unable to access user buffer\n");
			return -EACCES;
		}
		ret = wrPciCfgByte(pBrd, rw.reg, rw.value);
		if (ret < 0)
			return ret;
		break;

	case IOCTL_PCIE_CFG_REG_READ_16Bit:
		if (copy_from_user(&rw, (struct rw_ioctl *)arg, sizeof(struct rw_ioctl))) {
			pr_info("unable to access user buffer\n");
			return -EACCES;
		}
		ret = rdPciCfgWord(pBrd, rw.reg, (uint16_t *)&rw.value);
		if (ret < 0)
			return ret;
		if (copy_to_user((void *)arg, &rw, sizeof(struct rw_ioctl))) {
			pr_info("unable to update buffer to user\n");
			return -EACCES;
		}
		break;

	case IOCTL_PCIE_CFG_REG_WRITE_16Bit:
		if (copy_from_user(&rw, (struct rw_ioctl *)arg, sizeof(struct rw_ioctl))) {
			pr_info("unable to access user buffer\n");
			return -EACCES;
		}
		ret = wrPciCfgWord(pBrd, rw.reg, rw.value);
		if (ret < 0)
			return ret;
		break;

	case IOCTL_PCIE_CFG_REG_READ_32Bit:
		if (copy_from_user(&rw, (struct rw_ioctl *)arg, sizeof(struct rw_ioctl))) {
			pr_info("unable to access user buffer\n");
			return -EACCES;
		}
		ret = rdPciCfg(pBrd, rw.reg, (uint32_t *)&rw.value);
		if (ret < 0)
			return ret;
		if (copy_to_user((void *)arg, &rw, sizeof(struct rw_ioctl))) {
			pr_info("unable to update buffer to user\n");
			return -EACCES;
		}
		break;

	case IOCTL_PCIE_CFG_REG_WRITE_32Bit:
		if (copy_from_user(&rw, (struct rw_ioctl *)arg, sizeof(struct rw_ioctl))) {
			pr_info("unable to access user buffer\n");
			return -EACCES;
		}
		ret = wrPciCfg(pBrd, rw.reg, rw.value);
		if (ret < 0)
			return ret;
		break;

		case IOCTL_PCIE_USR_VEC_ALLOC:
			if (copy_from_user(&usr_vec, (struct usr_vec_data *)arg,
					   sizeof(struct usr_vec_data)))
				return -EFAULT;

			PcieUsrVectorAlloc(pBrd, usr_vec.usr_int, usr_vec.vec_val);
			break;
		default:
			return -EINVAL;
	}

	return 0;
}

/**
 * mmap.
 * This is the most important driver method.  This maps the device's PCI
 * address space (based on the select mmap BAR number) into the user's
 * address space, allowing direct memory access with standard pointers.
 *
 * @param filp Pointer to the file structure
 * @param vma Pointer to the virtual memory area structure
 * @return 0 on success, negative error code on failure
 */
static int PcieMmap(struct file *filp, struct vm_area_struct *vma)
{
	return 0;
}

/**
 * @brief Handles read operations for the PCIe device.
 *
 * This function is called when a user-space process attempts to read from the
 * PCIe device. Currently, it does not perform any specific operations and
 * always returns 0.
 *
 * @param filp Pointer to the file structure.
 * @param userBuf Pointer to the user-space buffer where data will be read into.
 * @param len Length of the data to be read.
 * @param offp Pointer to the file offset.
 * @return Number of bytes read on success, or a negative error code on failure.
 */
static ssize_t PcieRead(struct file *filp, char __user *userBuf, size_t len, loff_t *offp)
{
	struct PCIE_Board *pBrd = filp->private_data;

	(void)pBrd; // Suppress unused variable warning
	return 0;
}

/**
 * @brief Handles write operations for the PCIe device.
 *
 * This function is called when a user-space process attempts to write to the
 * PCIe device. Currently, it does not perform any specific operations and
 * always returns 0.
 *
 * @param filp Pointer to the file structure.
 * @param userBuf Pointer to the user-space buffer containing the data to be transferred.
 * @param len Length of the data to be transferred.
 * @param offp Pointer to the file offset.
 * @return Number of bytes written on success, or a negative error code on failure.
 */
static ssize_t PcieWrite(struct file *filp, const char __user *userBuf, size_t len, loff_t *offp)
{
	struct PCIE_Board *pBrd = filp->private_data;

	(void)pBrd; // Suppress unused variable warning
	return 0;
}

/**
 * @brief File operations structure for PCIe.
 *
 * This structure defines the file operations for the PCIe device, including
 * open, release, ioctl, mmap, read, and write operations.
 */
struct file_operations PCIeFileOpt = {
owner:      THIS_MODULE,
open : PcieOpen,
release : PcieRelease,
unlocked_ioctl : PcieIoctl,
mmap : PcieMmap,
read : PcieRead,
write : PcieWrite,
};

/**
 * PcieProbe - Probe function for PCI Express device
 *
 * @param pdev: Pointer to the PCI device structure
 * @param ent: Pointer to the PCI device ID structure
 *
 * This function is called during PCI device probing. It initializes the PCI
 * Express device, requests regions, enables the device, and performs
 * board-specific initialization. A new device is added to the
 * /sys/class/pcie_lattice/ tree with the driver name.
 * @return 0 on success or an error code otherwise.
 */
static int PcieProbe(struct pci_dev *pdev, const struct pci_device_id *ent)
{
	struct PCIE_Board *pBrd;
	int err;

	if (debug)
		pr_info("pci probe for: %s  pdev=%p  ent=%p\n", gDrvrName, pdev, ent);

	err = pci_request_regions(pdev, gDrvrName);
	if (err)
		return err;

	pci_set_master(pdev);

	err = pci_enable_device(pdev);
	if (err)
		return err;

	/**
	 * Call to perform board specific initialization and figure out
	 * which BARs are active, interrupt vectors, register ISR, what board
	 * it is and what instance number
	 * Returns pointer to the Board structure after all info filled in.
	 */
	pBrd = initBoard(pdev, (void *)ent);
	if (pBrd == NULL) {
		pr_err("error initializing board\n");

		// Clean up any resources we acquired along the way
		pci_release_regions(pdev);
		pci_disable_device(pdev);
		return(-1);
	}

	// Initialize the CharDev entry for this new found hw board device
	pBrd->cdev.owner = THIS_MODULE;
	kobject_set_name(&(pBrd->cdev.kobj), gDrvrName);
	cdev_init(&(pBrd->cdev), &PCIeFileOpt);

	if (cdev_add(&(pBrd->cdev), MKDEV(pBrd->majorNum, pBrd->minorNum), MINORS_PER_BOARD)) {
		pr_err("error adding char device\n");
		kobject_put(&(pBrd->cdev.kobj));
		return(-1);
	}

	device_create(global_pcie.sysfs, NULL, MKDEV(pBrd->majorNum, pBrd->minorNum), &(pdev->dev),
					"%s", gDrvrName);
	pr_info("added device: %s\n", gDrvrName);
	pci_set_drvdata(pdev, pBrd);
	return 0;
}

/**
 * Cleanup function for PCI Express device removal
 *
 * @param pdev: Pointer to the PCI device structure
 *
 * This function is called during PCI device removal. It performs cleanup tasks
 * such as freeing IRQs, unmapping memory regions, releasing device regions,
 * unbinding minor numbers, and removing the device entry from the sysfs tree.
 */
static void PcieRemove(struct pci_dev *pdev)
{
	int i;
	struct PCIE_Board *pBrd = pci_get_drvdata(pdev);

	if (debug)
		pr_info("pci remove for device: pdev=%p board=%p\n", pdev, pBrd);

	// Disable PCIe error reporting
	//pci_disable_pcie_error_reporting(pdev);

	if (pBrd->msi || pBrd->msix) {
		pr_info("msi/msi-x enabled, freeing IRQs\n");

		for (i = 0; i < pBrd->num_irqs; i++)
			free_irq(pBrd->irq_vec[i], pBrd);

		if (pBrd->msi || pBrd->msix)
			pci_free_irq_vectors(pBrd->pdev);

		pBrd->msi = false;
		pBrd->msix = false;
		pBrd->num_irqs = 0;
	}

	// Free legacy INTx IRQ if used
	if (!pBrd->msi && !pBrd->msix) {
		if (pBrd->IRQ != -1) {
			if (debug)
				pr_info(" close - free_irq %d\n", pBrd->IRQ);
			free_irq(pBrd->IRQ, pBrd);
		}
		pBrd->IRQ = -1;
	}

	// Free our internal access to the control BAR address space
	for (i = 0; i < pBrd->numBars; i++) {
		if (pBrd->ctrlBARaddr[i])
			iounmap(pBrd->ctrlBARaddr[i]);
	}
	// No more access after this call
	pci_release_regions(pdev);

	// Unbind the minor numbers of this device
	cdev_del(&(pBrd->cdev));
	unregister_chrdev_region(MKDEV(pBrd->majorNum, pBrd->minorNum), MINORS_PER_BOARD);

	// Remove the device entry in the /sys/class/pcie_lattice/ tree
	device_destroy(global_pcie.sysfs, MKDEV(pBrd->majorNum, pBrd->minorNum));
}

/**
 * Placeholder function for handling device suspension during system sleep.
 *
 * @param pdev: Pointer to the PCI device structure
 * @param state: Power management message indicating the sleep state (e.g., suspend, hibernate)
 *
 * This function is called when the system enters a sleep state. It logs a message indicating
 * that the device is being suspended. The return value of 0 indicates success (no error).
 */
static int PcieSuspend(struct pci_dev *pdev, pm_message_t state)
{
	pr_info("suspend\n");
	return 0;
}

/**
 * Placeholder function for handling device resume after system sleep.
 *
 * @param pdev: Pointer to the PCI device structure
 *
 * This function is called when the system resumes from a sleep state. It logs a message
 * indicating that the device is being resumed.
 * @return value of 0 indicates success (no error).
 */
static int PcieResume(struct pci_dev *pdev)
{
	pr_info("resume\n");
	return 0;
}

/**
 * Placeholder function for handling device shutdown.
 *
 * @param pdev: Pointer to the PCI device structure
 *
 * This function is called during system shutdown or device removal. It logs a message
 * indicating that the device is being shut down.
 */
static void PcieShutdown(struct pci_dev *pdev)
{
	pr_info("shutdown\n");
}

/**
 * Error handling function for PCI Express device.
 *
 * @param pdev: Pointer to the PCI device structure
 * @param state: PCI channel state indicating the error condition
 *
 * This function is called when an error is detected on the PCI channel. It handles
 * different error states and returns the appropriate result for error recovery.
 *
 * @return pci_ers_result_t: Result indicating the recommended action (e.g., recover, reset, disconnect)
 */
static pci_ers_result_t PcieErrorDetected(struct pci_dev *pdev, pci_channel_state_t state)
{
	pci_channel_state_t s;

	s = state;
	switch (s) {
	case pci_channel_io_normal:
		return PCI_ERS_RESULT_CAN_RECOVER;

	case pci_channel_io_frozen:
		pr_warn(" dev 0x%p, frozen state error, reset controller\n", pdev);
		pci_disable_device(pdev);
		return PCI_ERS_RESULT_NEED_RESET;

	case pci_channel_io_perm_failure:
		pr_warn("dev 0x%p, failure state error, request disconnect\n", pdev);
		return PCI_ERS_RESULT_DISCONNECT;
	}

	return PCI_ERS_RESULT_NEED_RESET;
}

/**
 * Slot reset handler for PCI Express device.
 *
 * @param pdev: Pointer to the PCI device structure
 *
 * This function is called when a slot reset occurs for the PCI device. It attempts
 * to re-enable the device, restore its state, and save the state.
 *
 * @return pci_ers_result_t: PCI_ERS_RESULT_RECOVERED on success; otherwise,
 *                           it returns PCI_ERS_RESULT_DISCONNECT.
 */
static pci_ers_result_t PcieSlotReset(struct pci_dev *pdev)
{
	pr_info("0x%p restart after slot reset\n", pdev);
	if (pci_enable_device_mem(pdev)) {
		pr_err(" failed to reenable after slot reset\n");
		return PCI_ERS_RESULT_DISCONNECT;
	}
	pci_set_master(pdev);
	pci_restore_state(pdev);
	pci_save_state(pdev);

	return PCI_ERS_RESULT_RECOVERED;
}

/**
 * PCI error handlers for PCI Express device.
 *
 * This structure defines the error handling functions associated with the PCI device.
 * - `error_detected`: Called when an error is detected on the PCI channel.
 * - `slot_reset`: Called when a slot reset occurs for the PCI device.
 * - `resume`: Placeholder function for handling device resume after system sleep.
 * - `reset_prepare`: Placeholder function for preparing for a device reset.
 * - `reset_done`: Placeholder function for handling device reset completion.
 */
static const struct pci_error_handlers PcieErrHandler = {
	.error_detected = PcieErrorDetected,
	.slot_reset = PcieSlotReset,
	//.resume,
	//.reset_prepare,
	//.reset_done,
};

/**
 * Main structure required for registering a driver with the PCI core.
 * name must be unique across all registered PCI drivers, and shows up in
 * /sys/bus/pci/drivers/
 * id_table points to the table of Vendor,Device,SubSystem matches
 * probe is the function to call when enumerating PCI buses to match driver to device
 * remove is the function called when PCI is shutting down and devices/drivers are
 * being removed.
 */
static struct pci_driver PcieDriver = {
	.name = gDrvrName,
	.id_table = lattice_pci_id_tbl,
	.probe = PcieProbe,
	.remove = PcieRemove,
	.suspend = PcieSuspend,
	.resume = PcieResume,
	.shutdown = PcieShutdown,
	.err_handler = &PcieErrHandler,
};

/**
 * Initialization function for the PCI Express driver.
 *
 * This function performs the following tasks during driver initialization:
 * 1. Allocates a dynamic major number for the character device.
 * 2. Creates a sysfs class entry to hold the tree of detected PCIe board devices.
 * 3. Registers the PCI driver components and functions with the Kernel PCI core.
 *
 * @return 0 on success or an error code otherwise.
 */
static int __init PcieInit(void)
{
	int n, i;
	int result;
	int err;

	pr_info("debug=%d\n", debug);
	// pr_info("%s\n", version);

	/* Initialize the driver database to nothing found, no BARs, no devices */
	memset(&global_pcie, 0, sizeof(global_pcie));
	for (n = 0; n < NUM_BOARDS; n++)
		for (i = 0; i < NUM_BARS; i++)
			global_pcie.Board[n].Dev_BARs[i].bar = -1;

	/* Register device driver as a character device and get a dynamic Major number */
	result = alloc_chrdev_region(&global_pcie.drvrDevNum,      // return allocated Device Num here
					  0,	              // first minor number
					  MAX_MINORS, gDrvrName);
	if (result < 0) {
		pr_err("can't get major/minor numbers!\n");
		return result;
	}

	if (debug)
		pr_info("Major=%d  num boards=%d\n", MAJOR(global_pcie.drvrDevNum), global_pcie.numBoards);

	if (debug)
		pr_info("cdev_init()\n");

	/* Create the new sysfs Class entry that will hold the tree of detected PCIe board devices. */
#if (KERNEL_VERSION(6, 4, 0) <= LINUX_VERSION_CODE)
	global_pcie.sysfs = class_create(gDrvrName);
#else
	global_pcie.sysfs = class_create(THIS_MODULE, gDrvrName);
 #endif
	if (IS_ERR(global_pcie.sysfs)) {
		pr_err("Error creating simple class interface\n");
		return(-1);
	}
	if (debug)
		pr_info("registering driver with PCI\n");

	/* Register our PCI components and functions with the Kernel PCI core.*/
	err = pci_register_driver(&PcieDriver);
	if (debug)
		pr_info("pci_register_driver()=%d\n", err);
	if (err < 0)
		return(err);

	return 0;
}

module_init(PcieInit);

/**
 * Cleanup function for the PCI Express driver during module exit.
 *
 * This function performs the following tasks during driver cleanup:
 * 1. Unregisters the PCI driver.
 * 2. Cleans up each active board (if any).
 * 3. Destroys the sysfs class entry.
 * 4. Frees the allocated major and minor numbers.
 */
static void __exit PcieExit(void)
{
	uint8_t i;

	pci_unregister_driver(&PcieDriver);
	for (i = 0; i < NUM_BOARDS; i++) {
		if (global_pcie.Board[i].ID != 0) {
			/* Do the cleanup for each active board */
			pr_info("Cleaning up board: %d\n", i);

			// Disable and release IRQ if still active
		}
	}
	class_destroy(global_pcie.sysfs);

	// Free every minor number and major number we reserved in init
	unregister_chrdev_region(global_pcie.drvrDevNum, MAX_MINORS);
}

module_exit(PcieExit);

MODULE_AUTHOR("Lattice Semiconductor");
MODULE_DESCRIPTION("LSC PCIe Device Driver");
MODULE_VERSION(DRV_MODULE_VERSION);

/* License this so no annoying messages when loading module */
MODULE_LICENSE("Dual BSD/GPL");
