/* SPDX-License-Identifier: MIT */
/*
 * ==================================================================
 *
 * >>>>>>>>>>>>>>>>>>>>> COPYRIGHT NOTICE <<<<<<<<<<<<<<<<<<<<<<<<<
 * ------------------------------------------------------------------
 * Copyright (c) 2026 by Lattice Semiconductor Corporation
 * ALL RIGHTS RESERVED
 * ------------------------------------------------------------------
 *
 * DISCLAIMER:
 *
 * LATTICE MAKES NO WARRANTIES ON THIS FILE OR ITS CONTENTS,
 * WHETHER EXPRESSED, IMPLIED, STATUTORY,
 * OR IN ANY PROVISION OF THE LATTICE PROPEL LICENSE AGREEMENT OR
 * COMMUNICATION WITH LICENSEE,
 * AND LATTICE SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
 * MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
 * LATTICE DOES NOT WARRANT THAT THE FUNCTIONS CONTAINED HEREIN WILL MEET
 * LICENSEE 'S REQUIREMENTS, OR THAT LICENSEE' S OPERATION OF ANY DEVICE,
 * SOFTWARE OR SYSTEM USING THIS FILE OR ITS CONTENTS WILL BE
 * UNINTERRUPTED OR ERROR FREE,
 * OR THAT DEFECTS HEREIN WILL BE CORRECTED.
 * LICENSEE ASSUMES RESPONSIBILITY FOR SELECTION OF MATERIALS TO ACHIEVE
 * ITS INTENDED RESULTS, AND FOR THE PROPER INSTALLATION, USE,
 * AND RESULTS OBTAINED THEREFROM.
 * LICENSEE ASSUMES THE ENTIRE RISK OF THE FILE AND ITS CONTENTS PROVING
 * DEFECTIVE OR FAILING TO PERFORM PROPERLY AND IN SUCH EVENT,
 * LICENSEE SHALL ASSUME THE ENTIRE COST AND RISK OF ANY REPAIR, SERVICE,
 * CORRECTION,
 * OR ANY OTHER LIABILITIES OR DAMAGES CAUSED BY OR ASSOCIATED WITH THE
 * SOFTWARE.IN NO EVENT SHALL LATTICE BE LIABLE TO ANY PARTY FOR DIRECT,
 * INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES,
 * INCLUDING LOST PROFITS,
 * ARISING OUT OF THE USE OF THIS FILE OR ITS CONTENTS,
 * EVEN IF LATTICE HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * LATTICE 'S SOLE LIABILITY, AND LICENSEE' S SOLE REMEDY,
 * IS SET FORTH ABOVE.
 * LATTICE DOES NOT WARRANT OR REPRESENT THAT THIS FILE,
 * ITS CONTENTS OR USE THEREOF DOES NOT INFRINGE ON THIRD PARTIES'
 * INTELLECTUAL PROPERTY RIGHTS, INCLUDING ANY PATENT. IT IS THE USER' S
 * RESPONSIBILITY TO VERIFY THE USER SOFTWARE DESIGN FOR CONSISTENCY AND
 * FUNCTIONALITY THROUGH THE USE OF FORMAL SOFTWARE VALIDATION METHODS.
 * ------------------------------------------------------------------
 *
 * ==================================================================
 */

#ifndef __LSC_PCIE_REGS_H__
#define __LSC_PCIE_REGS_H__
/*Register Offsets*/
/* Register name, address and offset */
#define H2F_DMA_CTRL_REG                     0x0000
#define H2F_DMA_STS_REG                      0x000C
#define H2F_DMA_INT_MASK_REG                 0x0010
#define H2F_CPLT_DESC_COUNT_REG              0x0018
#define F2H_DMA_CTRL_REG                     0x0100
#define F2H_DMA_CTRL_2_REG                   0x0104
#define F2H_DMA_STS_REG                      0x010C
#define F2H_DMA_INT_MASK_REG                 0x0110
#define F2H_CPLT_DESC_COUNT_REG              0x0118

/*H2F Descriptor Fetching Registers*/
#define H2F_DESC_ADDR_LO_REG                 0x0200
#define H2F_DESC_ADDR_HI_REG                 0x0204
#define H2F_CONT_REMAIN_REG                  0x0208
/*F2H Descriptor Fetching Registers*/
#define F2H_DESC_ADDR_LO_REG                 0x0300
#define F2H_DESC_ADDR_HI_REG                 0x0304
#define F2H_CONT_REMAIN_REG                  0x0308

#define INT_MODE_REG				         0x0400
#define H2F_INT_VEC_REG                      0x0404
#define F2H_INT_VEC_REG                      0x0408
#define USR_INT_VEC_P1_REG                   0x040C
#define USR_INT_VEC_P2_REG                   0x0410
#define USR_INT_VEC_P3_REG                   0x0414
#define USR_INT_VEC_P4_REG                   0x0418
#define AXI_BRIDGE_MSI_VEC_REG               0x041C

#define GEN_STS_REG                          0x0500
#define AXI_BRIDGE_STS_REG                   0x0600

/* H2F DMA Status Register Bit Definitions */
#define H2F_RSVD_1                  GENMASK(31, 12)
#define H2F_DMA_LEN_ERR             BIT(11)
#define H2F_DEST_ADDR_ERR           BIT(10)
#define H2F_SRC_ADDR_ERR            BIT(9)
#define H2F_DESC_ADDR_ERR           BIT(8)
#define H2F_AXI_WRITE_ERR           BIT(7)
#define H2F_CPLTO_ERR               BIT(6)
#define H2F_CPL_ERR                 BIT(5)
#define H2F_DESC_CPLTO_ERR          BIT(4)
#define H2F_DESC_CPL_ERR            BIT(3)
#define H2F_INT_DONE                BIT(2)
#define H2F_EOP_DONE                BIT(1)
#define H2F_BUSY                    BIT(0)

/* F2H DMA Status Register Bit Definitions */
#define F2H_RSVD_1                  GENMASK(31, 14)
#define F2H_AXI_ST_DATA_L_ERR       BIT(13)
#define F2H_AXI_ST_DATA_S_ERR       BIT(12)
#define F2H_DMA_LEN_ERR             BIT(11)
#define F2H_DEST_ADDR_ERR           BIT(10)
#define F2H_SRC_ADDR_ERR            BIT(9)
#define F2H_DESC_ADDR_ERR           BIT(8)
#define F2H_AXI_READ_ERR            BIT(7)
#define F2H_RSVD_2                  GENMASK(6, 5)
#define F2H_DESC_CPLTO_ERR          BIT(4)
#define F2H_DESC_CPL_ERR            BIT(3)
#define F2H_INT_DONE                BIT(2)
#define F2H_EOP_DONE                BIT(1)
#define F2H_BUSY                    BIT(0)

/* H2F/F2H DMA status: shared completion bits at the same bit positions */
#define DMA_EOP_DONE_BIT            BIT(1)  /* end-of-packet done */
#define DMA_INT_DONE_BIT            BIT(2)  /* descriptor interrupt done */

/* General Status Register fields */
#define GEN_STS_MODE                 GENMASK(5, 3)   /* bits [5:3]: device mode */
#define GEN_STS_DMA_TYPE             GENMASK(2, 0)   /* bits [2:0]: DMA engine type */

/* GEN_STS_MODE field values (already shifted down to bit 0) */
#define GEN_STS_MODE_DMA_H2F_F2H    0x0  /* bidirectional DMA */
#define GEN_STS_MODE_DMA_F2H        0x1  /* F2H-only DMA */
#define GEN_STS_MODE_DMA_H2F        0x2  /* H2F-only DMA */
#define GEN_STS_MODE_HALF_BRIDGE    0x3  /* half-bridge (non-DMA) */
#define GEN_STS_MODE_AXI_BRIDGE     0x4  /* AXI bridge */

/* GEN_STS_DMA_TYPE field values (already shifted down to bit 0) */
#define GEN_STS_DMA_TYPE_AXI_MM     0x0  /* AXI memory-mapped */
#define GEN_STS_DMA_TYPE_AXI_S      0x1  /* AXI streaming */

/*Registers mask for DMA related registers*/
#define START_DMA_MASK              0x1
#define STOP_DMA_MASK               0x1
#define DMA_STS_BUSY_MASK           0x1

/* F2H DMA_INT_MASK: suppress AXI-S streaming data length/size errors */
#define F2H_AXI_S_DMA_INT_MASK      (F2H_AXI_ST_DATA_L_ERR | F2H_AXI_ST_DATA_S_ERR)

/*Registers values*/
#define START_DMA                   0x1
#define STOP_DMA                    0x1

/*User interrupt vector mask*/
#define USR_INT_VEC_MASK            0x1F

#endif   // #ifndef __LSC_PCIE_REGS_H__
