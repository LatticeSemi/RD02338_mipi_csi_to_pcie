#!/bin/bash
cd ..
sudo rmmod drv_src/pcie_lattice.ko

