#!/bin/bash
cd ..
sudo rmmod lscpcie_dma

