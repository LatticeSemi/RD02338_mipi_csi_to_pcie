// SPDX-License-Identifier: MIT
/*   ==================================================================
 
     >>>>>>>>>>>>>>>>>>>>>>> COPYRIGHT NOTICE <<<<<<<<<<<<<<<<<<<<<<<<<
     ------------------------------------------------------------------
     Copyright (c) 2025 by Lattice Semiconductor Corporation
     ALL RIGHTS RESERVED
     ------------------------------------------------------------------
 
     DISCLAIMER:
 
    LATTICE MAKES NO WARRANTIES ON THIS FILE OR ITS CONTENTS,
    WHETHER EXPRESSED, IMPLIED, STATUTORY,
    OR IN ANY PROVISION OF THE LATTICE PROPEL LICENSE AGREEMENT OR
    COMMUNICATION WITH LICENSEE,
    AND LATTICE SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
    MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
    LATTICE DOES NOT WARRANT THAT THE FUNCTIONS CONTAINED HEREIN WILL MEET
    LICENSEE 'S REQUIREMENTS, OR THAT LICENSEE' S OPERATION OF ANY DEVICE,
    SOFTWARE OR SYSTEM USING THIS FILE OR ITS CONTENTS WILL BE
    UNINTERRUPTED OR ERROR FREE,
    OR THAT DEFECTS HEREIN WILL BE CORRECTED.
    LICENSEE ASSUMES RESPONSIBILITY FOR SELECTION OF MATERIALS TO ACHIEVE
    ITS INTENDED RESULTS, AND FOR THE PROPER INSTALLATION, USE,
    AND RESULTS OBTAINED THEREFROM.
    LICENSEE ASSUMES THE ENTIRE RISK OF THE FILE AND ITS CONTENTS PROVING
    DEFECTIVE OR FAILING TO PERFORM PROPERLY AND IN SUCH EVENT,
    LICENSEE SHALL ASSUME THE ENTIRE COST AND RISK OF ANY REPAIR, SERVICE,
    CORRECTION,
    OR ANY OTHER LIABILITIES OR DAMAGES CAUSED BY OR ASSOCIATED WITH THE
    SOFTWARE.IN NO EVENT SHALL LATTICE BE LIABLE TO ANY PARTY FOR DIRECT,
    INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES,
    INCLUDING LOST PROFITS,
    ARISING OUT OF THE USE OF THIS FILE OR ITS CONTENTS,
    EVEN IF LATTICE HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
    LATTICE 'S SOLE LIABILITY, AND LICENSEE' S SOLE REMEDY,
    IS SET FORTH ABOVE.
    LATTICE DOES NOT WARRANT OR REPRESENT THAT THIS FILE,
    ITS CONTENTS OR USE THEREOF DOES NOT INFRINGE ON THIRD PARTIES'
    INTELLECTUAL PROPERTY RIGHTS, INCLUDING ANY PATENT. IT IS THE USER' S
    RESPONSIBILITY TO VERIFY THE USER SOFTWARE DESIGN FOR CONSISTENCY AND
    FUNCTIONALITY THROUGH THE USE OF FORMAL SOFTWARE VALIDATION METHODS.
     ------------------------------------------------------------------
 
     ================================================================== */
 
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <cstdint>
#include <linux/pci.h>
#include <linux/pci_regs.h>
#include <iostream>
#include <vector>
#include <iomanip>
#include "PCIE_IF.h"
#include "cap_check.h"

void pci_pm_flag_print(uint32_t pci_cap_ptr, bool detailed)
{
    uint32_t pci_cap_data = 0;
    uint16_t pci_cap_read_data = 0;
    pci_cap_data = pDrvr->readConfig16(pci_cap_ptr + PCI_PM_PMC);
    if (detailed){
        if (pci_cap_data & PCI_PM_CAP_VER_MASK) {
            printf("\t\tPCI PM Cap Ver: %d\n", (pci_cap_data & PCI_PM_CAP_VER_MASK));
        }
        else {
            printf("\t\tInvalid PCI PM Cap Ver\n");
        }

        if (pci_cap_data & PCI_PM_CAP_PME_CLOCK) {
            printf("\t\tPME Clock: 0\n");
        }
        else {
            printf("\t\tPME Clock: 0\n");
        }

        if (pci_cap_data & PCI_PM_CAP_DSI) {
            printf("\t\tDSI: Required\n");
        }
        else {
            printf("\t\tDSI: Not Required\n");
        }

        if (pci_cap_data & PCI_PM_CAP_AUX_POWER) {
            pci_cap_read_data = (pci_cap_data & PCI_PM_CAP_AUX_POWER);
            switch (pci_cap_read_data) {
                case PCI_PM_CAP_AUX_POWER_0:
                    printf("\t\tAux Power Supported: 0mA\n");
                    break;
                case PCI_PM_CAP_AUX_POWER_1:
                    printf("\t\tAux Power Supported: 55mA\n");
                    break;
                case PCI_PM_CAP_AUX_POWER_2:
                    printf("\t\tAux Power Supported: 100mA\n");
                    break;
                case PCI_PM_CAP_AUX_POWER_3:
                    printf("\t\tAux Power Supported: 160mA\n");
                    break;
                case PCI_PM_CAP_AUX_POWER_4:
                    printf("\t\tAux Power Supported: 220mA\n");
                    break;
                case PCI_PM_CAP_AUX_POWER_5:
                    printf("\t\tAux Power Supported: 270mA\n");
                    break;
                case PCI_PM_CAP_AUX_POWER_6:
                    printf("\t\tAux Power Supported: 320mA\n");
                    break;
                case PCI_PM_CAP_AUX_POWER_7:
                    printf("\t\tAux Power Supported: 375mA\n");
                    break;
                default:
                    printf("\t\tAux Power Supported: 0mA\n");
            }
        }
        else {
            printf("\t\tAux Power Supported: 0mA\n");
        }

        if (pci_cap_data & PCI_PM_CAP_D1) {
            printf("\t\tD1 Power State: Supported\n");
        }
        else {
            printf("\t\tD1 Power State: Not Supported\n");
        }

        if (pci_cap_data & PCI_PM_CAP_D2) {
            printf("\t\tD2 Power State: Supported\n");
        }
        else {
            printf("\t\tD2 Power State: Not Supported\n");
        }

        if (pci_cap_data & PCI_PM_CAP_PME_MASK) {
            pci_cap_read_data = (pci_cap_data & PCI_PM_CAP_PME_MASK);
            switch(pci_cap_read_data) {
                case PCI_PM_CAP_PME_D0:
                    printf("\t\tPME Gen: Support from D0\n");
                    break;
                case PCI_PM_CAP_PME_D1:
                    printf("\t\tPME Gen: Support from D1\n");
                    break;
                case PCI_PM_CAP_PME_D2:
                    printf("\t\tPME Gen: Support from D2\n");
                    break;
                case PCI_PM_CAP_PME_D3hot:
                    printf("\t\tPME Gen: Support from D3 (hot)\n");
                    break;
                case PCI_PM_CAP_PME_D3cold:
                    printf("\t\tPME Gen: Support from D3 (cold)\n");
                    break;
                default:
                    printf("\t\tPME Gen: Not Supported\n");
            }
        }
        else {
            printf("\t\tPME Gen: Not Supported\n");
        }
    }

}

void pci_pm_ctl_print(uint32_t pci_cap_ptr, bool detailed)
{
    uint32_t pci_cap_data = 0;
    uint16_t pci_cap_read_data = 0;
    pci_cap_data = pDrvr->readConfig16(pci_cap_ptr + PCI_PM_CTRL);
    if (detailed) {
        if (pci_cap_data & PCI_PM_CTRL_STATE_MASK) {
            pci_cap_read_data = (pci_cap_data & PCI_PM_CTRL_STATE_MASK);
            switch (pci_cap_read_data) {
                case PCI_PM_CTRL_STATE_D0:
                    printf("\t\tCurrent Power State: D0\n");
                    break;
                case PCI_PM_CTRL_STATE_D1:
                    printf("\t\tCurrent Power State: D1\n");
                    break;
                case PCI_PM_CTRL_STATE_D2:
                    printf("\t\tCurrent Power State: D2\n");
                    break;
                case PCI_PM_CTRL_STATE_D3hot:
                    printf("\t\tCurrent Power State: D3 (hot)\n");
                    break;
                default:
                    printf("\t\tCurrent Power State: D0\n");
            }
        }
        else {
            printf("\t\tCurrent Power State: D0\n");
        }

        if (pci_cap_data & PCI_PM_CTRL_NO_SOFT_RESET) {
            printf("\t\tNo Soft Reset: Enabled\n");
        }
        else {
            printf("\t\tNo Soft Reset: Not Enabled\n");
        }

        if (pci_cap_data & PCI_PM_CTRL_PME_ENABLE) {
            printf("\t\tPME Gen: Enabled\n");
        }
        else {
            printf("\t\tPME Gen: Not Enabled\n");
        }

        if (pci_cap_data & PCI_PM_CTRL_DATA_SEL_MASK) {
            printf("\t\tData Select: %d\n", (pci_cap_data & PCI_PM_CTRL_DATA_SEL_MASK) >> 9);
        }
        
        if (pci_cap_data & PCI_PM_CTRL_DATA_SCALE_MASK) {
            printf("\t\tData Scale: %d\n", (pci_cap_data & PCI_PM_CTRL_DATA_SCALE_MASK) >> 13);
        }
    }
}


void pci_exp_flag_print(uint32_t pci_cap_ptr, bool detailed)
{
    uint32_t pci_cap_data = 0;
    uint16_t pci_cap_read_data = 0;
    pci_cap_data = pDrvr->readConfig16(pci_cap_ptr + PCI_EXP_FLAGS);
    if (detailed) {
        if (pci_cap_data & PCI_EXP_FLAGS_VERS) {
            printf("\t\tPCI Express Version: %d\n", (pci_cap_data & PCI_EXP_FLAGS_VERS));
        }
        else {
            printf("\t\tInvalid PCI Express Version\n");
        }
    }
    if (pci_cap_data & PCI_EXP_FLAGS_TYPE) {
        pci_cap_read_data = (pci_cap_data & PCI_EXP_FLAGS_TYPE) >> 4;
        switch (pci_cap_read_data) {
            case PCI_EXP_TYPE_ENDPOINT:
                printf("\t\tDevice Type: PCIe Endpoint\n");
                break;
            case PCI_EXP_TYPE_LEG_END:
                printf("\t\tDevice Type: Legacy PCIe Endpoint\n");
                break;
            case PCI_EXP_TYPE_ROOT_PORT:
                printf("\t\tDevice Type: PCIe Root Port\n");
                break;
            case PCI_EXP_TYPE_UPSTREAM:
                printf("\t\tDevice Type: PCIe Upstream Port\n");
                break;
            case PCI_EXP_TYPE_DOWNSTREAM:
                printf("\t\tDevice Type: PCIe Downstream Port\n");
                break;
            case PCI_EXP_TYPE_PCI_BRIDGE:
                printf("\t\tDevice Type: PCIe to PCI/PCI-X Bridge\n");
                break;
            case PCI_EXP_TYPE_PCIE_BRIDGE:
                printf("\t\tDevice Type: PCIe/PCI-X to PCIe Bridge\n");
                break;
            case PCI_EXP_TYPE_RC_END:
                printf("\t\tDevice Type: PCIe Root Complex Integrated Endpoint\n");
                break;
            case PCI_EXP_TYPE_RC_EC:
                printf("\t\tDevice Type: PCIe Root Complex Event Collector\n");
                break;
            default:
                printf("\t\tUnknown Device/Port Type: %d\n", pci_cap_read_data);
        }
    }
    else {
        printf("\t\tDevice Type: PCIe Endpoint\n");
    }

    if (detailed) {
        if (pci_cap_data & PCI_EXP_FLAGS_SLOT) {
            printf("\t\tSlot Implemented\n");
        }
        else {
            printf("\t\tSlot Not Implemented\n");
        }
    }

    if (pci_cap_data & PCI_EXP_FLAGS_IRQ) {
        printf("\t\tInterrupt Message Number: %d\n", (pci_cap_data & PCI_EXP_FLAGS_IRQ) >> 9);
    }
    else {
        printf("\t\tInterrupt Message Number: 0\n");
    }
}

void pci_dev_cap_print(uint32_t pci_cap_ptr, bool detailed)
{
    uint32_t pci_cap_data = 0;
    uint16_t pci_cap_read_data = 0;    
    pci_cap_data = pDrvr->readConfig32(pci_cap_ptr + PCI_EXP_DEVCAP);
    if (detailed) {
        if (pci_cap_data & PCI_EXP_DEVCAP_PAYLOAD) {
            pci_cap_read_data = (pci_cap_data & PCI_EXP_DEVCAP_PAYLOAD) << 5; //shift left by 5 here to reuse the defines from DEVCTL
            switch(pci_cap_read_data) {
                case PCI_EXP_DEVCTL_PAYLOAD_128B: //Reuse the defines from DEVCTL here
                    printf("\t\tMPS Support: 128 Bytes\n");
                    break;
                case PCI_EXP_DEVCTL_PAYLOAD_256B:
                    printf("\t\tMPS Support: 256 Bytes\n");
                    break;
                case PCI_EXP_DEVCTL_PAYLOAD_512B:
                    printf("\t\tMPS Support: 512 Bytes\n");
                    break;
                case PCI_EXP_DEVCTL_PAYLOAD_1024B:
                    printf("\t\tMPS Support: 1024 Bytes\n");
                    break;
                case PCI_EXP_DEVCTL_PAYLOAD_2048B:
                    printf("\t\tMPS Support: 2048 Bytes\n");
                    break;
                case PCI_EXP_DEVCTL_PAYLOAD_4096B:
                    printf("\t\tMPS Support: 4096 Bytes\n");
                    break;
                default:
                    printf("\t\tUnknown MPS Support: %d\n", (pci_cap_data & PCI_EXP_DEVCAP_PAYLOAD));
            }
        }
        else {
            printf("\t\tMPS Support: RSVD\n");
        }

        if (pci_cap_data & PCI_EXP_DEVCAP_PHANTOM) {
            printf("\t\tPhantom Functions: %d\n", (pci_cap_data & PCI_EXP_DEVCAP_PHANTOM));
        }
        else {
            printf("\t\tPhantom Functions: 0\n");
        }

        if (pci_cap_data & PCI_EXP_DEVCAP_EXT_TAG) {
            printf("\t\tExtended Tags: 8-Bit\n");
        }
        else {
            printf("\t\tExtended Tags: 5-Bit\n");
        }

        if (pci_cap_data & PCI_EXP_DEVCAP_L0S) {
            pci_cap_read_data = (pci_cap_data & PCI_EXP_DEVCAP_L0S);
            switch(pci_cap_read_data) {
                case PCI_EXP_DEVCAP_L0s_LATENCY_64n:
                    printf("\t\tL0s Latency: 64ns\n");
                    break;
                case PCI_EXP_DEVCAP_L0s_LATENCY_128n:
                    printf("\t\tL0s Latency: 128ns\n");
                    break;
                case PCI_EXP_DEVCAP_L0s_LATENCY_256n:
                    printf("\t\tL0s Latency: 256ns\n");
                    break;
                case PCI_EXP_DEVCAP_L0s_LATENCY_512n:
                    printf("\t\tL0s Latency: 512ns\n");
                    break;
                case PCI_EXP_DEVCAP_L0s_LATENCY_1u:
                    printf("\t\tL0s Latency: 1us\n");
                    break;
                case PCI_EXP_DEVCAP_L0s_LATENCY_2u:
                    printf("\t\tL0s Latency: 2us\n");
                    break;
                case PCI_EXP_DEVCAP_L0s_LATENCY_4u:
                    printf("\t\tL0s Latency: 4us\n");
                    break;
                case PCI_EXP_DEVCAP_L0s_LATENCY_NO_LIMIT:
                    printf("\t\tL0s Latency: No Limit\n");
                    break;
                default:
                    printf("\t\tL0s Latency: 64ns\n");
                    break;
            }
        }
        else {
            printf("\t\tL0s Latency: 64ns\n");
        }

        if (pci_cap_data & PCI_EXP_DEVCAP_L1) {
            pci_cap_read_data = (pci_cap_data & PCI_EXP_DEVCAP_L1);
            switch(pci_cap_read_data) {
                case PCI_EXP_DEVCAP_L1_LATENCY_1u:
                    printf("\t\tL1 Latency: 1us\n");
                    break;
                case PCI_EXP_DEVCAP_L1_LATENCY_2u:
                    printf("\t\tL1 Latency: 2us\n");
                    break;
                case PCI_EXP_DEVCAP_L1_LATENCY_4u:
                    printf("\t\tL1 Latency: 4us\n");
                    break;
                case PCI_EXP_DEVCAP_L1_LATENCY_8u:
                    printf("\t\tL1 Latency: 8us\n");
                    break;
                case PCI_EXP_DEVCAP_L1_LATENCY_16u:
                    printf("\t\tL1 Latency: 16us\n");
                    break;
                case PCI_EXP_DEVCAP_L1_LATENCY_32u:
                    printf("\t\tL1 Latency: 32us\n");
                    break;
                case PCI_EXP_DEVCAP_L1_LATENCY_64u:
                    printf("\t\tL1 Latency: 64us\n");
                    break;
                case PCI_EXP_DEVCAP_L1_LATENCY_NO_LIMIT:
                    printf("\t\tL1 Latency: No Limit\n");
                    break;
                default:
                    printf("\t\tL1 Latency: 1us\n");
                    break;
            }
        }
        else {
            printf("\t\tL1 Latency: 1us\n");
        }
        if (pci_cap_data & PCI_EXP_DEVCAP_RBER) {
            printf("\t\tRole-Based ER: Supported\n");
        }
        else {
            printf("\t\tRole-Based ER: Not Supported\n");
        }

        if (pci_cap_data & PCI_EXP_DEVCAP_PWR_VAL) {
            printf("\t\tSlot Power Limit: %dW\n", (pci_cap_data & PCI_EXP_DEVCAP_PWR_VAL) >> 18);
        }
        else {
            printf("\t\tSlot Power Limit: 0W\n");
        }

        if (pci_cap_data & PCI_EXP_DEVCAP_PWR_SCL) {
            printf("\t\tSlot Power Limit Scale: %d\n", (pci_cap_data & PCI_EXP_DEVCAP_PWR_SCL) >> 26);
        }
        else {
            printf("\t\tSlot Power Limit Scale: 0\n");
        }

        if (pci_cap_data & PCI_EXP_DEVCAP_FLR) {
            printf("\t\tFLR: Supported\n");
        }
        else {
            printf("\t\tFLR: Not Supported\n");
        }   
    } 
}

void pci_dev_ctl_print(uint32_t pci_cap_ptr, bool detailed)
{
    uint32_t pci_cap_data = 0;
    uint16_t pci_cap_read_data = 0; 
    pci_cap_data = pDrvr->readConfig16(pci_cap_ptr + PCI_EXP_DEVCTL);
    if (detailed) {
        if (pci_cap_data & PCI_EXP_DEVCTL_CERE) {
            printf("\t\tCorrectable Error: Enabled\n");
        }
        else {
            printf("\t\tCorrectable Error: Not Enabled\n");
        }

        if (pci_cap_data & PCI_EXP_DEVCTL_NFERE) {
            printf("\t\tNon-Fatal Error: Enabled\n");
        }
        else {
            printf("\t\tNon-Fatal Error: Not Enabled\n");
        }

        if (pci_cap_data & PCI_EXP_DEVCTL_FERE) {
            printf("\t\tFatal Error: Enabled\n");
        }
        else {
            printf("\t\tFatal Error: Not Enabled\n");
        }

        if (pci_cap_data & PCI_EXP_DEVCTL_URRE) {
            printf("\t\tUnsupported Request: Enabled\n");
        }
        else {
            printf("\t\tUnsupported Request: Not Enabled\n");
        }

        if (pci_cap_data & PCI_EXP_DEVCTL_RELAX_EN) {
            printf("\t\tRelaxed Ordering: Enabled\n");
        }
        else {
            printf("\t\tRelaxed Ordering: Not Enabled\n");
        }
    }
    if (pci_cap_data & PCI_EXP_DEVCTL_PAYLOAD) {
        pci_cap_read_data = (pci_cap_data & PCI_EXP_DEVCTL_PAYLOAD);
        switch (pci_cap_read_data) {
            case PCI_EXP_DEVCTL_PAYLOAD_128B:
                printf("\t\tMPS: 128 Bytes\n");
                break;
            case PCI_EXP_DEVCTL_PAYLOAD_256B:
                printf("\t\tMPS: 256 Bytes\n");
                break;
            case PCI_EXP_DEVCTL_PAYLOAD_512B:
                printf("\t\tMPS: 512 Bytes\n");
                break;
            case PCI_EXP_DEVCTL_PAYLOAD_1024B:
                printf("\t\tMPS: 1024 Bytes\n");
                break;
            case PCI_EXP_DEVCTL_PAYLOAD_2048B:
                printf("\t\tMPS: 2048 Bytes\n");
                break;
            case PCI_EXP_DEVCTL_PAYLOAD_4096B:
                printf("\t\tMPS: 4096 Bytes\n");
                break;
            default:
                printf("\t\tUnknown MPS: %d\n", pci_cap_read_data);
        }
    }
    else {
        printf("\t\tMPS: 128 Bytes\n");
    }
    if (detailed) {
        if (pci_cap_data & PCI_EXP_DEVCTL_EXT_TAG) {
            printf("\t\tExtended Tag Field: Enabled\n");
        }
        else {
            printf("\t\tExtended Tag Field: Not Enabled\n");
        }

        if (pci_cap_data & PCI_EXP_DEVCTL_PHANTOM) {
            printf("\t\tPhantom Functions: Enabled\n");
        }
        else {
            printf("\t\tPhantom Functions: Not Enabled\n");
        }

        if (pci_cap_data & PCI_EXP_DEVCTL_AUX_PME) {
            printf("\t\tAuxiliary Power PM: Enabled\n");
        }
        else {
            printf("\t\tAuxiliary Power PM: Not Enabled\n");
        }

        if (pci_cap_data & PCI_EXP_DEVCTL_NOSNOOP_EN) {
            printf("\t\tNo Snoop: Enabled\n");
        }
        else {
            printf("\t\tNo Snoop: Not Enabled\n");
        }
    }
    if (pci_cap_data & PCI_EXP_DEVCTL_READRQ) {
        pci_cap_read_data = (pci_cap_data & PCI_EXP_DEVCTL_READRQ);
        switch (pci_cap_read_data) {
            case PCI_EXP_DEVCTL_READRQ_128B:
                printf("\t\tMRRS: 128 Bytes\n");
                break;
            case PCI_EXP_DEVCTL_READRQ_256B:
                printf("\t\tMRRS: 256 Bytes\n");
                break;
            case PCI_EXP_DEVCTL_READRQ_512B:
                printf("\t\tMRRS: 512 Bytes\n");
                break;
            case PCI_EXP_DEVCTL_READRQ_1024B:
                printf("\t\tMRRS: 1024 Bytes\n");
                break;
            case PCI_EXP_DEVCTL_READRQ_2048B:
                printf("\t\tMRRS: 2048 Bytes\n");
                break;
            case PCI_EXP_DEVCTL_READRQ_4096B:
                printf("\t\tMRRS: 4096 Bytes\n");
                break;
            default:
                printf("\t\tUnknown MRRS: %d\n", (pci_cap_data & PCI_EXP_DEVCTL_READRQ));
        }
    }
    else {
        printf("\t\tMRRS: 128 Bytes\n");
    }
}

void pci_dev_sts_print(uint32_t pci_cap_ptr, bool detailed)
{
    uint32_t pci_cap_data = 0;
    pci_cap_data = pDrvr->readConfig16(pci_cap_ptr + PCI_EXP_DEVSTA);
    if (detailed) {
        if (pci_cap_data & PCI_EXP_DEVSTA_CED) {
            printf("\t\tCorrectable Error: Detected\n");
        }
        else {
            printf("\t\tCorrectable Error: Not Detected\n");
        }

        if (pci_cap_data & PCI_EXP_DEVSTA_NFED) {
            printf("\t\tNon-Fatal Error: Detected\n");
        }
        else {
            printf("\t\tNon-Fatal Error: Not Detected\n");
        }

        if (pci_cap_data & PCI_EXP_DEVSTA_FED) {
            printf("\t\tFatal Error: Detected\n");
        }
        else {
            printf("\t\tFatal Error: Not Detected\n");
        }

        if (pci_cap_data & PCI_EXP_DEVSTA_URD) {
            printf("\t\tUnsupported Request: Detected\n");
        }
        else {
            printf("\t\tUnsupported Request: Not Detected\n");
        }

        if (pci_cap_data & PCI_EXP_DEVSTA_AUXPD) {
            printf("\t\tAuxiliary Power: Detected\n");
        }
        else {
            printf("\t\tAuxiliary Power: Not Detected\n");
        }

        if (pci_cap_data & PCI_EXP_DEVSTA_TRPND) {
            printf("\t\tTransactions Pending\n");
        }
        else {
            printf("\t\tNo Transactions Pending\n");
        }
    }
}

void pci_dev_link_cap_print(uint32_t pci_cap_ptr, bool detailed)
{
    uint32_t pci_cap_data = 0;
    uint32_t pci_cap_read_data = 0; 
    pci_cap_data = pDrvr->readConfig32(pci_cap_ptr + PCI_EXP_LNKCAP);
    if (detailed) {
        if (pci_cap_data & PCI_EXP_LNKCAP_SLS) {
            pci_cap_read_data = (pci_cap_data & PCI_EXP_LNKCAP_SLS);
            switch(pci_cap_read_data) {
                case PCI_EXP_LNKCAP_SLS_2_5GB:
                    printf("\t\tMax Link Speed: 2.5 GT/s - G1\n");
                    break;
                case PCI_EXP_LNKCAP_SLS_5_0GB:
                    printf("\t\tMax Link Speed: 5.0 GT/s - G2\n");
                    break;
                case PCI_EXP_LNKCAP_SLS_8_0GB:
                    printf("\t\tMax Link Speed: 8.0 GT/s - G3\n");
                    break;
                case PCI_EXP_LNKCAP_SLS_16_0GB:
                    printf("\t\tMax Link Speed: 16.0 GT/s - G4\n");
                    break;
                case PCI_EXP_LNKCAP_SLS_32_0GB:
                    printf("\t\tMax Link Speed: 32.0 GT/s - G5\n");
                    break;
                case PCI_EXP_LNKCAP_SLS_64_0GB:
                    printf("\t\tMax Link Speed: 64.0 GT/s - G6\n");
                    break;
                default:
                    printf("\t\tMax Link Speed: 2.5 GT/s - G1\n");
            }
        }
        else {
            printf("\t\tInvalid Max Link Speed\n");
        }

        if (pci_cap_data & PCI_EXP_LNKCAP_MLW) {
            printf("\t\tMax Link Width: x%d\n", (pci_cap_data & PCI_EXP_LNKCAP_MLW) >> 4);
        }
        else {
            printf("\t\tInvalid Max Link Width\n");
        }
        if (pci_cap_data & PCI_EXP_LNKCAP_ASPMS) {
            pci_cap_read_data = (pci_cap_data & PCI_EXP_LNKCAP_ASPMS);
            switch (pci_cap_read_data) {
                case PCI_EXP_LNKCAP_ASPM_L0S:
                    printf("\t\tASPM Support: L0s\n");
                    break;
                case PCI_EXP_LNKCAP_ASPM_L1:
                    printf("\t\tASPM Support: L1\n");
                    break;
                case PCI_EXP_LNKCAP_ASPMS:
                    printf("\t\tASPM Support: L0s, L1\n");
                    break;
                default:
                    printf("\t\tNo ASPM Support\n");
            }
        }
        else {
            printf("\t\tNo ASPM Support\n");
        }

        if (pci_cap_data & PCI_EXP_LNKCAP_L0SEL) {
            pci_cap_read_data = (pci_cap_data & PCI_EXP_LNKCAP_L0SEL);
            switch(pci_cap_read_data) {
                case PCI_EXP_LNKCAP_L0s_LATENCY_64n:
                    printf("\t\tL0s Exit Latency: < 64ns\n");
                    break;
                case PCI_EXP_LNKCAP_L0s_LATENCY_128n:
                    printf("\t\tL0s Exit Latency: 64ns - 128ns\n");
                    break;
                case PCI_EXP_LNKCAP_L0s_LATENCY_256n:
                    printf("\t\tL0s Exit Latency: 128ns - 256ns\n");
                    break;
                case PCI_EXP_LNKCAP_L0s_LATENCY_512n:
                    printf("\t\tL0s Exit Latency: 256ns - 512ns\n");
                    break;
                case PCI_EXP_LNKCAP_L0s_LATENCY_1u:
                    printf("\t\tL0s Exit Latency: 512ns - 1us\n");
                    break;
                case PCI_EXP_LNKCAP_L0s_LATENCY_2u:
                    printf("\t\tL0s Exit Latency: 1us - 2us\n");
                    break;
                case PCI_EXP_LNKCAP_L0s_LATENCY_4u:
                    printf("\t\tL0s Exit Latency: 2us - 4us\n");
                    break;
                case PCI_EXP_LNKCAP_L0s_LATENCY_NO_LIMIT:
                    printf("\t\tL0s Exit Latency: > 4us\n");
                    break;
                default:
                    printf("\t\tL0s Exit Latency: < 64ns\n");
                    break;
            }
        }
        else {
            printf("\t\tASPM L0s Exit Latency: < 64ns\n");
        }

        if (pci_cap_data & PCI_EXP_LNKCAP_L1EL) {
            pci_cap_read_data = (pci_cap_data & PCI_EXP_LNKCAP_L1EL);
            switch(pci_cap_read_data) {
                case PCI_EXP_LNKCAP_L1_LATENCY_1u:
                    printf("\t\tL1 Exit Latency: < 1us\n");
                    break;
                case PCI_EXP_LNKCAP_L1_LATENCY_2u:
                    printf("\t\tL1 Exit Latency: 1us - 2us\n");
                    break;
                case PCI_EXP_LNKCAP_L1_LATENCY_4u:
                    printf("\t\tL1 Exit Latency: 2us - 4us\n");
                    break;
                case PCI_EXP_LNKCAP_L1_LATENCY_8u:
                    printf("\t\tL1 Exit Latency: 4us - 8us\n");
                    break;
                case PCI_EXP_LNKCAP_L1_LATENCY_16u:
                    printf("\t\tL1 Exit Latency: 8us - 16us\n");
                    break;
                case PCI_EXP_LNKCAP_L1_LATENCY_32u:
                    printf("\t\tL1 Exit Latency: 16us - 32us\n");
                    break;
                case PCI_EXP_LNKCAP_L1_LATENCY_64u:
                    printf("\t\tL1 Exit Latency: 32us - 64us\n");
                    break;
                case PCI_EXP_LNKCAP_L1_LATENCY_NO_LIMIT:
                    printf("\t\tL1 Exit Latency: > 64us\n");
                    break;
                default:
                    printf("\t\tL1 Exit Latency: < 1us\n");
                    break;
            }
        }
        else {
            printf("\t\tASPM L1 Exit Latency: < 1us\n");
        }

        if (pci_cap_data & PCI_EXP_LNKCAP_CLKPM) {
            printf("\t\tClock Power Management: %d\n", (pci_cap_data & PCI_EXP_LNKCAP_CLKPM) >> 18);
        }
        else {
            printf("\t\tClock Power Management: 0\n");
        }

        if (pci_cap_data & PCI_EXP_LNKCAP_SDERC) {
            printf("\t\tSDER: Capable\n");
        }
        else {
            printf("\t\tSDER: Not Capable\n");
        }

        if (pci_cap_data & PCI_EXP_LNKCAP_DLLLARC) {
            printf("\t\tDLLAR: Capable\n");
        }
        else {
            printf("\t\tDLLAR: Not Capable\n");
        }

        if (pci_cap_data & PCI_EXP_LNKCAP_LBNC) {
            printf("\t\tLBN: Capable\n");
        }
        else {
            printf("\t\tLBN: Not Capable\n");
        }

        if (pci_cap_data & PCI_EXP_LNK_CAP_ASPMOC) {
            printf("\t\tASPM Optionality: Compliant\n");
        }
        else {
            printf("\t\tASPM Optionality: Not Compliant\n");
        }

        if (pci_cap_data & PCI_EXP_LNKCAP_PN) {
            printf("\t\tPort Number: %d\n", (pci_cap_data & PCI_EXP_LNKCAP_PN) >> 24);
        }
        else {
            printf("\t\tPort Number: 0\n");
        }
    }
}

void pci_dev_link_ctl_print(uint32_t pci_cap_ptr, bool detailed) 
{
    uint32_t pci_cap_data = 0;
    uint16_t pci_cap_read_data = 0; 
    pci_cap_data = pDrvr->readConfig16(pci_cap_ptr + PCI_EXP_LNKCTL);
    if (detailed) {
        if (pci_cap_data & PCI_EXP_LNKCTL_ASPMC) {
            pci_cap_read_data = (pci_cap_data & PCI_EXP_LNKCTL_ASPMC);
            switch (pci_cap_read_data) {
                case PCI_EXP_LNKCTL_ASPM_L0S:
                    printf("\t\tASPM Control: L0s\n");
                    break;
                case PCI_EXP_LNKCTL_ASPM_L1:
                    printf("\t\tASPM Control: L1\n");
                    break;
                case PCI_EXP_LNKCTL_ASPMC:
                    printf("\t\tASPM Control: L0s, L1\n");
                    break;
                default:
                    printf("\t\tASPM Disabled\n");
            }
        }
        else {
            printf("\t\tASPM Disabled\n");
        }

        if (pci_cap_data & PCI_EXP_LNKCTL_RCB) {
            printf("\t\tRCB: 128 Bytes\n");
        }
        else {
            printf("\t\tRCB: 64 Bytes\n");
        }

        if (pci_cap_data & PCI_EXP_LNKCTL_LD) {
            printf("\t\tLink Disabled\n");
        }
        else {
            printf("\t\tLink Enabled\n");
        }

        if (pci_cap_data & PCI_EXP_LNKCTL_RL) {
            printf("\t\tLink Retrain: 1 (BAD)\n");
        }
        else {
            printf("\t\tLink Retrain: 0\n");
        }

        if (pci_cap_data & PCI_EXP_LNKCTL_CCC) {
            printf("\t\tCommon Clock Configuration\n");
        }
        else {
            printf("\t\tAsync Ref Clock Configuration\n");
        }

        if (pci_cap_data & PCI_EXP_LNKCTL_ES) {
            printf("\t\tExtended Synch: Enabled\n");
        }
        else {
            printf("\t\tExtended Synch: Disabled\n");
        }

        if (pci_cap_data & PCI_EXP_LNKCTL_CLKREQ_EN) {
            printf("\t\tClock Request: Enabled\n");
        }
        else {
            printf("\t\tClock Request: Disabled\n");
        }

        if (pci_cap_data & PCI_EXP_LNKCTL_HAWD) {
            printf("\t\tHW Auto Width: Disabled\n");
        }
        else {
            printf("\t\tHW Auto Width: Enabled\n");
        }

        if (pci_cap_data & PCI_EXP_LNKCTL_LBMIE) {
            printf("\t\tLBMI: Enabled\n");
        }
        else {
            printf("\t\tLBMI: Disabled\n");
        }

        if (pci_cap_data & PCI_EXP_LNKCTL_LABIE) {
            printf("\t\tLABI: Enabled\n");
        }
        else {
            printf("\t\tLABI: Disabled\n");
        }
    }
}

void pci_dev_link_sts_print(uint32_t pci_cap_ptr, bool detailed)
{
    uint32_t pci_cap_data = 0;
    uint16_t pci_cap_read_data = 0; 
    pci_cap_data = pDrvr->readConfig16(pci_cap_ptr + PCI_EXP_LNKSTA);
    if (pci_cap_data & PCI_EXP_LNKSTA_CLS) {
        pci_cap_read_data = (pci_cap_data & PCI_EXP_LNKSTA_CLS);
        switch(pci_cap_read_data) {
            case PCI_EXP_LNKSTA_CLS_2_5GB:
                printf("\t\tCurr Link Speed: 2.5 GT/s - G1\n");
                break;
            case PCI_EXP_LNKSTA_CLS_5_0GB:
                printf("\t\tCurr Link Speed: 5.0 GT/s - G2\n");
                break;
            case PCI_EXP_LNKSTA_CLS_8_0GB:
                printf("\t\tCurr Link Speed: 8.0 GT/s - G3\n");
                break;
            case PCI_EXP_LNKSTA_CLS_16_0GB:
                printf("\t\tCurr Link Speed: 16.0 GT/s - G4\n");
                break;
            case PCI_EXP_LNKSTA_CLS_32_0GB:
                printf("\t\tCurr Link Speed: 32.0 GT/s - G5\n");
                break;
            case PCI_EXP_LNKSTA_CLS_64_0GB:
                printf("\t\tCurr Link Speed: 64.0 GT/s - G6\n");
                break;
            default:
                printf("\t\tUnknown Current Link Speed\n");
        }
    }
    else {
        printf("\t\tInvalid Current Link Speed\n");
    }

    if (pci_cap_data & PCI_EXP_LNKSTA_NLW) {
        printf("\t\tNegotiated Link Width: x%d\n", (pci_cap_data & PCI_EXP_LNKSTA_NLW) >> PCI_EXP_LNKSTA_NLW_SHIFT);
    }
    else {
        printf("\t\tNegotiated Link Width: 0\n");
    }
    if (detailed) {
        if (pci_cap_data & PCI_EXP_LNKSTA_LT) {
            printf("\t\tLink Training In Progress\n");
        }
        else {
            printf("\t\tLink Training Done\n");
        }

        if (pci_cap_data & PCI_EXP_LNKSTA_SLC) {
            printf("\t\tSlot Clock Conf: Same Clock\n");
        }
        else {
            printf("\t\tSlot Clock Conf: Indp Clock\n");
        }

        if (pci_cap_data & PCI_EXP_LNKSTA_DLLLA) {
            printf("\t\tData Link Layer: Active\n");
        }
        else {
            printf("\t\tData Link Layer: Inactive\n");
        }

        if (pci_cap_data & PCI_EXP_LNKSTA_LBMS) {
            printf("\t\tLBM: Change Detected\n");
        }
        else {
            printf("\t\tLBM: No Change\n");
        }

        if (pci_cap_data & PCI_EXP_LNKSTA_LABS) {
            printf("\t\tLAB: Change Detected\n");
        }
        else {
            printf("\t\tLAB: No Change\n");
        }
    }

}

void pci_dev_slot_cap_print(uint32_t pci_cap_ptr, bool detailed)
{
    uint32_t pci_cap_data = 0;
    pci_cap_data = pDrvr->readConfig32(pci_cap_ptr + PCI_EXP_SLTCAP);
    if (detailed) {
        if (pci_cap_data & PCI_EXP_SLTCAP_ABP) {
            printf("\t\tAttention Button: Present\n");
        }
        else {
            printf("\t\tAttention Button: Not Present\n");
        }

        if (pci_cap_data & PCI_EXP_SLTCAP_PCP) {
            printf("\t\tPower Controller: Present\n");
        }
        else {
            printf("\t\tPower Controller: Not Present\n");
        }

        if (pci_cap_data & PCI_EXP_SLTCAP_MRLSP) {
            printf("\t\tMRL Sensor: Present\n");
        }
        else {
            printf("\t\tMRL Sensor: Not Present\n");
        }

        if (pci_cap_data & PCI_EXP_SLTCAP_AIP) {
            printf("\t\tAttention Indicator: Present\n");
        }
        else {
            printf("\t\tAttention Indicator: Not Present\n");
        }
        
        if (pci_cap_data & PCI_EXP_SLTCAP_PIP) {
            printf("\t\tPower Indicator: Present\n");
        }
        else {
            printf("\t\tPower Indicator: Not Present\n");
        }

        if (pci_cap_data & PCI_EXP_SLTCAP_HPS) {
            printf("\t\tHot Plug Surprise: Enabled\n");
        }
        else {
            printf("\t\tHot Plug Surprise: Not Enabled\n");
        }

        if (pci_cap_data & PCI_EXP_SLTCAP_HPC) {
            printf("\t\tHot Plug: Capable\n");
        }
        else {
            printf("\t\tHot Plug: Not Supported\n");
        }

        if (pci_cap_data & PCI_EXP_SLTCAP_SPLV) {
            printf("\t\tSlot Power Limit Value: %d\n", (pci_cap_data & PCI_EXP_SLTCAP_SPLV) >> 7);
        }
        else {
            printf("\t\tSlot Power Limit Value: 0\n");
        }

        if (pci_cap_data & PCI_EXP_SLTCAP_SPLS) {
            printf("\t\tSlot Power Limit Scale: %d\n", (pci_cap_data & PCI_EXP_SLTCAP_SPLS) >> 15);
        }
        else {
            printf("\t\tSlot Power Limit Scale: 0\n");
        }

        if (pci_cap_data & PCI_EXP_SLTCAP_EIP) {
            printf("\t\tElectromechanical Interlock: Present\n");
        }
        else {
            printf("\t\tElectromechanical Interlock: Not Present\n");
        }

        if (pci_cap_data & PCI_EXP_SLTCAP_NCCS) {
            printf("\t\tNo Command Completed: Supported\n");
        }
        else {
            printf("\t\tNo Command Completed: Not Supported\n");
        }

        if (pci_cap_data & PCI_EXP_SLTCAP_PSN) {
            printf("\t\tPhysical Slot Number: %d\n", ((pci_cap_data & PCI_EXP_SLTCAP_PSN) >> 24));
        }
        else {
            printf("\t\tPhysical Slot Number: 0\n");
        }
    }
}

void pci_dev_slot_ctl_print(uint32_t pci_cap_ptr, bool detailed)
{
    uint32_t pci_cap_data = 0;
    uint16_t pci_cap_read_data = 0; 
    pci_cap_data = pDrvr->readConfig16(pci_cap_ptr + PCI_EXP_SLTCTL);
    if (detailed) {
        if (pci_cap_data & PCI_EXP_SLTCTL_ABPE) {
            printf("\t\tAttention Button Pressed: Enabled\n");
        }
        else {
            printf("\t\tAttention Button Pressed: Not Enabled\n");
        }

        if (pci_cap_data & PCI_EXP_SLTCTL_PFDE) {
            printf("\t\tPower Fault Detected: Enabled\n");
        }
        else {
            printf("\t\tPower Fault Detected: Not Enabled\n");
        }

        if (pci_cap_data & PCI_EXP_SLTCTL_MRLSCE) {
            printf("\t\tMRL Sensor Changed: Enabled:\n");
        }
        else {
            printf("\t\tMRL Sensor Changed: Not Enabled\n");
        }

        if (pci_cap_data & PCI_EXP_SLTCTL_PDCE) {
            printf("\t\tPresence Detect Changed: Enabled\n");
        }
        else {
            printf("\t\tPresence Detect Changed: Not Enabled\n");
        }

        if (pci_cap_data & PCI_EXP_SLTCTL_CCIE) {
            printf("\t\tCommand Completed Interrupt: Enabled\n");
        }
        else {
            printf("\t\tCommand Completed Interrupt: Not Enabled\n");
        }

        if (pci_cap_data & PCI_EXP_SLTCTL_HPIE) {
            printf("\t\tHot Plug Interrupt: Enabled\n");
        }
        else {
            printf("\t\tHot Plug Interrupt Not Enabled\n");
        }

        if (pci_cap_data & PCI_EXP_SLTCTL_AIC) {
            pci_cap_read_data = (pci_cap_data & PCI_EXP_SLTCTL_AIC);
            switch(pci_cap_read_data) {
                case PCI_EXP_SLTCTL_ATTN_IND_ON:
                    printf("\t\tAttention Indicator Control: On\n");
                    break;
                case PCI_EXP_SLTCTL_ATTN_IND_BLINK:
                    printf("\t\tAttention Indicator Control: Blinking\n");
                    break;
                case PCI_EXP_SLTCTL_PWR_IND_OFF:
                    printf("\t\tAttention Indicator Control: Off\n");
                    break;
                default:
                    printf("\t\tAttention Indicator Control: RSVD\n");
            }
        }
        else {
            printf("\t\tAttention Indicator Control: RSVD\n");
        }

        if (pci_cap_data & PCI_EXP_SLTCTL_PIC) {
            pci_cap_read_data = (pci_cap_data & PCI_EXP_SLTCTL_PIC);
            switch(pci_cap_read_data) {
                case PCI_EXP_SLTCTL_PWR_IND_ON:
                    printf("\t\tPower Indicator Control: On\n");
                    break;
                case PCI_EXP_SLTCTL_PWR_IND_BLINK:
                    printf("\t\tPower Indicator Control: Blinking\n");
                    break;
                case PCI_EXP_SLTCTL_PWR_IND_OFF:
                    printf("\t\tPower Indicator Control: Off\n");
                    break;
                default:
                    printf("\t\tPower Indicator Control: RSVD\n");
            }
        }
        else {
            printf("\t\tPower Indicator Control: RSVD\n");
        }

        if (pci_cap_data & PCI_EXP_SLTCTL_PCC) {
            pci_cap_read_data = (pci_cap_data & PCI_EXP_SLTCTL_PCC);
            switch(pci_cap_read_data) {
                case PCI_EXP_SLTCTL_PWR_ON:
                    printf("\t\tPower Controller Control: On\n");
                    break;
                case PCI_EXP_SLTCTL_PWR_OFF:
                    printf("\t\tPower Controller Control: Off\n");
                    break;
                default:
                    printf("\t\tPower Controller Control: RSVD\n");
            }
        }
        else {
            printf("\t\tPower Controller Control: RSVD\n");
        }

        if (pci_cap_data & PCI_EXP_SLTCTL_EIC) {
            printf("\t\tElectromechanical Interlock Control Should Always Return 0\n");
        }
        else {
            printf("\t\tElectromechanical Interlock Control: 0\n");
        }

        if (pci_cap_data & PCI_EXP_SLTCTL_DLLSCE) {
            printf("\t\tData Link Layer State Changed: Enabled\n");
        }
        else {
            printf("\t\tData Link Layer State Changed: Not Enabled\n");
        }

        if (pci_cap_data & PCI_EXP_SLTCTL_ASPL_DISABLE) {
            printf("\t\tAuto Slot Power Limit: Disabled\n");
        }
        else {
            printf("\t\tAuto Slot Power Limit: Not Disabled\n");
        }
    }
}

void pci_dev_slot_sts_print(uint32_t pci_cap_ptr, bool detailed)
{
    uint32_t pci_cap_data = 0;
    pci_cap_data = pDrvr->readConfig16(pci_cap_ptr + PCI_EXP_SLTSTA);
    if (detailed) {
        if (pci_cap_data & PCI_EXP_SLTSTA_ABP) {
            printf("\t\tAttention Button: Pressed\n");
        }
        else {
            printf("\t\tAttention Button: Not Pressed\n");
        }

        if (pci_cap_data & PCI_EXP_SLTSTA_PFD) {
            printf("\t\tPower Fault: Detected:\n");
        }
        else {
            printf("\t\tPower Fault: Not Detected\n");
        }

        if (pci_cap_data & PCI_EXP_SLTSTA_MRLSC) {
            printf("\t\tMRL Sensor: Changed\n");
        }
        else {
            printf("\t\tMRL Sensor: Not Changed\n");
        }

        if (pci_cap_data & PCI_EXP_SLTSTA_PDC) {
            printf("\t\tPresence Detect: Changed\n");
        }
        else {
            printf("\t\tPresence Detect: Not Changed\n");
        }

        if (pci_cap_data & PCI_EXP_SLTSTA_CC) {
            printf("\t\tHot-Plug Command: Completed\n");
        }
        else {
            printf("\t\tHot-Plug Command: Not Completed\n");
        }

        if (pci_cap_data & PCI_EXP_SLTSTA_MRLSS) {
            printf("\t\tMRL Sensor State: MRL Open\n");
        }
        else {
            printf("\t\tMRL Sensor State: MRL Closed\n");
        }

        if (pci_cap_data & PCI_EXP_SLTSTA_PDS) {
            printf("\t\tPresence Detect State: Adapter Present\n");
        }
        else {
            printf("\t\tPresence Detect State: Slot Empty\n");
        }
        
        if (pci_cap_data & PCI_EXP_SLTSTA_EIS) {
            printf("\t\tElectromechanical Interlock: Engaged\n");
        }
        else {
            printf("\t\tElectromechanical Interlock: Disengaged\n");
        }

        if (pci_cap_data & PCI_EXP_SLTSTA_DLLSC) {
            printf("\t\tData Link Layer State: Changed\n");
        }
        else {
            printf("\t\tData Link Layer State: Not Changed\n");
        }
    }
}

void pci_dev_root_ctl_print(uint32_t pci_cap_ptr, bool detailed)
{
    uint32_t pci_cap_data = 0;
    pci_cap_data = pDrvr->readConfig16(pci_cap_ptr + PCI_EXP_RTCTL);
    if (detailed) {
        if (pci_cap_data & PCI_EXP_RTCTL_SECEE) {
            printf("\t\tSystem Error on Correctable Error: Enabled\n");
        }
        else {
            printf("\t\tSystem Error on Correctable Error: Not Enabled\n");
        }

        if (pci_cap_data & PCI_EXP_RTCTL_SENFEE) {
            printf("\t\tSystem Error on Non-Fatal Error: Enabled\n");
        }
        else {
            printf("\t\tSystem Error on Non-Fatal Error: Not Enabled\n");
        }

        if (pci_cap_data & PCI_EXP_RTCTL_SEFEE) {
            printf("\t\tSystem Error on Fatal Error: Enabled\n");
        }
        else {
            printf("\t\tSystem Error on Fatal Error: Not Enabled\n");
        }

        if (pci_cap_data & PCI_EXP_RTCTL_PMEIE) {
            printf("\t\tPME Interrupt: Enabled\n");
        }
        else {
            printf("\t\tPME Interrupt: Not Enabled\n");
        }

        if (pci_cap_data & PCI_EXP_RTCTL_CRSSVE) {
            printf("\t\tCRS Software Visibility: Enabled\n");
        }
        else {
            printf("\t\tCRS Software Visibility: Not Enabled\n");
        }
    }
}

void pci_dev_root_cap_print(uint32_t pci_cap_ptr, bool detailed)
{
    uint32_t pci_cap_data = 0;
    pci_cap_data = pDrvr->readConfig16(pci_cap_ptr + PCI_EXP_RTCAP);
    if (detailed) {
        if (pci_cap_data & PCI_EXP_RTCAP_CRSVIS) {
            printf("\t\tCRS Software Visibility: Capable\n");
        }
        else {
            printf("\t\tCRS Software Visibility: Not Capable\n");
        }
    }
}

void pci_dev_root_sts_print(uint32_t pci_cap_ptr, bool detailed)
{
    uint32_t pci_cap_data = 0;
    pci_cap_data = pDrvr->readConfig32(pci_cap_ptr + PCI_EXP_RTSTA);
    if (detailed) {
        if (pci_cap_data & PCI_EXP_RTSTA_PME_RQ_ID) {
            printf("\t\tPME Request ID: %d\n", (pci_cap_data & PCI_EXP_RTSTA_PME_RQ_ID));
        }
        else {
            printf("\t\tPME Request ID: 0\n");
        }

        if (pci_cap_data & PCI_EXP_RTSTA_PME) {
            printf("\t\tPME Status: 1\n");
        }
        else {
            printf("\t\tPME Status: 0\n");
        }

        if (pci_cap_data & PCI_EXP_RTSTA_PENDING) {
            printf("\t\tPME Pending: 1\n");
        }
        else {
            printf("\t\tPME Pending: 0\n");
        }
    }
}

void pci_dev_cap_2_print(uint32_t pci_cap_ptr, bool detailed)
{
    uint32_t pci_cap_data = 0;
    uint32_t pci_cap_read_data = 0; 
    pci_cap_data = pDrvr->readConfig32(pci_cap_ptr + PCI_EXP_DEVCAP2);
    if (detailed) {
        if (pci_cap_data & PCI_EXP_DEVCAP2_COMP_TMOUT_RANGE) {
            printf("\t\tComp TO Ranges:: %d\n", (pci_cap_data & PCI_EXP_DEVCAP2_COMP_TMOUT_RANGE));
        }
        else {
            printf("\t\tComp TO Ranges: Not Supported\n");
        }

        if (pci_cap_data & PCI_EXP_DEVCAP2_COMP_TMOUT_DIS) {
            printf("\t\tComp TO Dis: Supported\n");
        }
        else {
            printf("\t\tComp TO Dis: Not Supported\n");
        }

        if (pci_cap_data & PCI_EXP_DEVCAP2_ARI) {
            printf("\t\tARI Forwarding: Supported\n");
        }
        else {
            printf("\t\tARI Forwarding: Not Supported\n");
        }

        if (pci_cap_data & PCI_EXP_DEVCAP2_ATOMIC_ROUTE) {
            printf("\t\tAtomicOp Routing: Supported\n");
        }
        else {
            printf("\t\tAtomicOp Routing: Not Supported\n");
        }

        if (pci_cap_data & PCI_EXP_DEVCAP2_ATOMIC_COMP32) {
            printf("\t\t32-Bit Atomic: Supported\n");
        }
        else {
            printf("\t\t32-Bit Atomic: Not Supported\n");
        }

        if (pci_cap_data & PCI_EXP_DEVCAP2_ATOMIC_COMP64) {
            printf("\t\t64-Bit Atomic: Supported\n");
        }
        else {
            printf("\t\t64-Bit Atomic: Not Supported\n");
        }

        if (pci_cap_data & PCI_EXP_DEVCAP2_ATOMIC_COMP128) {
            printf("\t\t128-Bit Atomic: Supported\n");
        }
        else {
            printf("\t\t128-Bit Atomic: Not Supported\n");
        }

        if (pci_cap_data & PCI_EXP_DEVCAP2_NROPRPRP) {
            printf("\t\tNo RO Pr Pr: Supported\n");
        }
        else {
            printf("\t\tNo RO Pr Pr: Not Supported\n");
        }

        if (pci_cap_data & PCI_EXP_DEVCAP2_LTR) {
            printf("\t\tLTR Mechanism: Supported\n");
        }
        else {
            printf("\t\tLTR Mechanism: Not Supported\n");
        }

        if (pci_cap_data & PCI_EXP_DEVCAP2_TPH) {
            pci_cap_read_data = (pci_cap_data & PCI_EXP_DEVCAP2_TPH);
            switch(pci_cap_read_data) {
                case PCI_EXP_DEVCAP2_TPH_SUP:
                    printf("\t\tTPH: Supported\n");
                    printf("\t\tExtended TPH: Not Supported\n");
                    break;
                case PCI_EXP_DEVCAP2_TPH_RSVD:
                    printf("\t\tRSVD\n");
                    break;
                case PCI_EXP_DEVCAP2_TPH_TPHEXT:
                    printf("\t\tTPH: Supported\n");
                    printf("\t\tExtended TPH: Supported\n");
                    break;
                default:
                    printf("\t\tTPH: Not Supported\n");
                    printf("\t\tExtended TPH: Supported\n");
            }
        }
        else {
            printf("\t\tTPH: Not Supported\n");
            printf("\t\tExtended TPH: Not Supported\n");
        }

        if (pci_cap_data & PCI_EXP_DEVCAP2_10B_TAG_COMP) {
            printf("\t\t10-Bit Tag Comp: Supported\n");
        }
        else {
            printf("\t\t10-Bit Tag Comp: Not Supported\n");
        }

        if (pci_cap_data & PCI_EXP_DEVCAP2_10B_TAG_REQ) {
            printf("\t\t10-Bit Tag Req: Supported\n");
        }
        else {
            printf("\t\t10-Bit Tag Req: Not Supported\n");
        }

        if (pci_cap_data & PCI_EXP_DEVCAP2_OBFF_MASK) {
            pci_cap_read_data = (pci_cap_data & PCI_EXP_DEVCAP2_OBFF_MASK);
            switch(pci_cap_read_data) {
                case PCI_EXP_DEVCAP2_OBFF_MSG:
                    printf("\t\tOBFF Support: Message\n");
                    break;
                case PCI_EXP_DEVCAP2_OBFF_WAKE:
                    printf("\t\tOBFF Support: WAKE#\n");
                    break;
                case PCI_EXP_DEVCAP2_OBFF_MASK:
                    printf("\t\tOBFF Support: WAKE# & Message\n");
                    break;
                default:
                    printf("\t\tOBFF: Not Supported\n");
            }
        }
        else {
            printf("\t\tOBFF: Not Supported\n");
        }

        if (pci_cap_data & PCI_EXP_DEVCAP2_EXT_FMT_FIELD) {
            printf("\t\tExt FMT Field: Supported\n");
        }
        else {
            printf("\t\tExt FMT Field: Not Supported\n");
        }

        if (pci_cap_data & PCI_EXP_DEVCAP2_EE_PREFIX) {
            printf("\t\tE2E TLP PreF: Supported\n");
        }
        else {
            printf("\t\tE2E TLP PreF: Not Supported\n");
        }

        if (pci_cap_data & PCI_EXP_DEVCAP2_MAX_EE_PREFIX) {
            pci_cap_read_data = (pci_cap_data & PCI_EXP_DEVCAP2_OBFF_MASK);
            switch(pci_cap_read_data) {
                case PCI_EXP_DEVCAP2_MAX_1_EE_PREFIX:
                    printf("\t\tMax E2E TLP PreF: 1\n");
                    break;
                case PCI_EXP_DEVCAP2_MAX_2_EE_PREFIX:
                    printf("\t\tMax E2E TLP PreF: 2\n");
                    break;
                case PCI_EXP_DEVCAP2_MAX_3_EE_PREFIX:
                    printf("\t\tMax E2E TLP PreF: 3\n");
                    break;
                default:
                    printf("\t\tMax E2E TLP PreF: 4\n");
            }
        }
        else {
            printf("\t\tMax E2E TLP PreF: 4\n");
        }

        if (pci_cap_data & PCI_EXP_DEVCAP2_EPRS) {
            printf("\t\tEPR: Supported\n");
        }
        else {
            printf("\t\tEPR: Not Supported\n");
        }

        if (pci_cap_data & PCI_EXP_DEVCAP2_EPRIR) {
            printf("\t\tEPR Init Required\n");
        }
        else {
            printf("\t\tEPR Init Not Required\n");
        }

        if (pci_cap_data & PCI_EXP_DEVCAP2_FRS) {
            printf("\t\tFRS: Supported\n");
        }
        else {
            printf("\t\tFRS: Not Supported\n");
        }
    }
}

void pci_dev_ctl_2_print(uint32_t pci_cap_ptr, bool detailed)
{
    uint32_t pci_cap_data = 0;
    uint16_t pci_cap_read_data = 0; 
    pci_cap_data = pDrvr->readConfig16(pci_cap_ptr + PCI_EXP_DEVCTL2);
    if (detailed) {
        if (pci_cap_data & PCI_EXP_DEVCTL2_COMP_TIMEOUT) {
            pci_cap_read_data = (pci_cap_data & PCI_EXP_DEVCTL2_COMP_TIMEOUT);
            switch(pci_cap_read_data) {
                case PCI_EXP_DEVCTL2_COMP_TIMEOUT_2:
                    printf("\t\tComp TO: 50us - 100us\n");
                    break;
                case PCI_EXP_DEVCTL2_COMP_TIMEOUT_3:
                    printf("\t\tComp TO: 1ms - 10ms\n");
                    break;
                case PCI_EXP_DEVCTL2_COMP_TIMEOUT_4:
                    printf("\t\tComp TO: 16ms - 55ms\n");
                    break;
                case PCI_EXP_DEVCTL2_COMP_TIMEOUT_5:
                    printf("\t\tComp TO: 65ms - 210ms\n");
                    break;
                case PCI_EXP_DEVCTL2_COMP_TIMEOUT_6:
                    printf("\t\tComp TO: 260ms - 900ms\n");
                    break;
                case PCI_EXP_DEVCTL2_COMP_TIMEOUT_7:
                    printf("\t\tComp TO: 1s - 3.5s\n");
                    break;
                case PCI_EXP_DEVCTL2_COMP_TIMEOUT_8:
                    printf("\t\tComp TO: 4s - 13s\n");
                    break;
                case PCI_EXP_DEVCTL2_COMP_TIMEOUT_9:
                    printf("\t\tComp TO: 17s - 64s\n");
                    break;
                default:
                    printf("\t\tComp TO: 50us - 50ms\n");
            }
        }
        else {
            printf("\t\tComp TO: 50us - 50ms\n");
        }

        if (pci_cap_data & PCI_EXP_DEVCTL2_COMP_TMOUT_DIS) {
            printf("\t\tCompletion Timeout: Disabled\n");
        }
        else {
            printf("\t\tCompletion Timeout: Enabled\n");
        }

        if (pci_cap_data & PCI_EXP_DEVCTL2_ARI) {
            printf("\t\tARI Forwarding: Enabled\n");
        }
        else {
            printf("\t\tARI Forwarding: Not Enabled\n");
        }

        if (pci_cap_data & PCI_EXP_DEVCTL2_ATOMIC_REQ) {
            printf("\t\tAtomicOp Req: Enabled\n");
        }
        else {
            printf("\t\tAtomicOp Req: Not Enabled\n");
        }

        if (pci_cap_data & PCI_EXP_DEVCTL2_ATOMIC_EGRESS_BLOCK) {
            printf("\t\tAtomicOp Egr Block: Enabled\n");
        }
        else {
            printf("\t\tAtomicOp Egr Block: Not Enabled\n");
        }

        if (pci_cap_data & PCI_EXP_DEVCTL2_IDO_REQ_EN) {
            printf("\t\tIDO Req: Enabled\n");
        }
        else {
            printf("\t\tIDO Req: Not Enabled\n");
        }

        if (pci_cap_data & PCI_EXP_DEVCTL2_IDO_CMP_EN) {
            printf("\t\tIDO Comp: Enabled\n");
        }
        else {
            printf("\t\tIDO Comp: Not Enabled\n");
        }

        if (pci_cap_data & PCI_EXP_DEVCTL2_LTR_EN) {
            printf("\t\tLTR Mechanism: Enabled\n");
        }
        else {
            printf("\t\tLTR Mechanism: Not Enabled\n");
        }

        if (pci_cap_data & PCI_EXP_DEVCTL2_10B_TAG_REQ_EN) {
            printf("\t\t10-Bit Tag Req: Enabled\n");
        }
        else {
            printf("\t\t10-Bit Tag Req: Not Enabled\n");
        }

        if (pci_cap_data & PCI_EXP_DEVCTL2_OBFF_WAKE_EN) {
            pci_cap_read_data = (pci_cap_data & PCI_EXP_DEVCTL2_OBFF_WAKE_EN);
            switch(pci_cap_read_data) {
                case PCI_EXP_DEVCTL2_OBFF_MSGA_EN:
                    printf("\t\tOBFF Support: Message[A]\n");
                    break;
                case PCI_EXP_DEVCTL2_OBFF_MSGB_EN:
                    printf("\t\tOBFF Support: Message[B]\n");
                    break;
                case PCI_EXP_DEVCTL2_OBFF_WAKE_EN:
                    printf("\t\tOBFF Support: WAKE#\n");
                    break;
                default:
                    printf("\t\tOBFF: Disabled\n");
            }
        }
        else {
            printf("\t\tOBFF: Disabled\n");
        }

        if (pci_cap_data & PCI_EXP_DEVCTL2_EE_TLPP_BLOCKING) {
            printf("\t\tE2E TLP Pref Block: Enabled\n");
        }
        else {
            printf("\t\tE2E TLP Pref Block: Not Enabled\n");
        }
    }    
}

void pci_dev_link_cap_2_print(uint32_t pci_cap_ptr, bool detailed)
{
    uint32_t pci_cap_data = 0;
    uint16_t pci_cap_read_data = 0; 
    pci_cap_data = pDrvr->readConfig16(pci_cap_ptr + PCI_EXP_LNKCAP2);
    if (detailed) {
        if (pci_cap_data & PCI_EXP_LNKCAP2_SLS_2_5GB) {
            printf("\t\tSupp Link Speeds: 2.5 GT/s - G1\n");
        }
        if (pci_cap_data & PCI_EXP_LNKCAP2_SLS_5_0GB) {
            printf("\t\tSupp Link Speeds: 5.0 GT/s - G2\n");
        }
        if (pci_cap_data & PCI_EXP_LNKCAP2_SLS_8_0GB) {
            printf("\t\tSupp Link Speeds: 8.0 GT/s - G3\n");
        }
        if (pci_cap_data & PCI_EXP_LNKCAP2_SLS_16_0GB) {
            printf("\t\tSupp Link Speeds: 16.0 GT/s - G4\n");
        }
        if (pci_cap_data & PCI_EXP_LNKCAP2_SLS_32_0GB) {
            printf("\t\tSupp Link Speeds: 32.0 GT/s - G5\n");
        }
        if (pci_cap_data & PCI_EXP_LNKCAP2_SLS_64_0GB) {
            printf("\t\tSupp Link Speeds: 64.0 GT/s - G6\n");
        }

        if (pci_cap_data & PCI_EXP_LNKCAP2_CROSSLINK) {
            printf("\t\tCrosslink: Supported\n");
        }
        else {
            printf("\t\tCrosslink: Not Supported\n");
        }

        if (pci_cap_data & PCI_EXP_LNKCAP2_RETIMER_PDS) {
            printf("\t\tRetimer PD: Supported\n");
        }
        else {
            printf("\t\tRetimer PD: Not Supported\n");
        }

        if (pci_cap_data & PCI_EXP_LNKCAP2_2_RETIMER_PDS) {
            printf("\t\tTwo Retimer PD: Supported\n");
        }
        else {
            printf("\t\tTwo Retimer PD: Not Supported\n");
        }

        if (pci_cap_data & PCI_EXP_LNKCAP2_DRS) {
            printf("\t\tDRS: Supported\n");
        }
        else {
            printf("\t\tDRS: Not Supported\n");
        }
    }
}

void pci_dev_link_ctl_2_print(uint32_t pci_cap_ptr, bool detailed)
{
    uint32_t pci_cap_data = 0;
    uint16_t pci_cap_read_data = 0; 
    pci_cap_data = pDrvr->readConfig16(pci_cap_ptr + PCI_EXP_LNKCTL2);
    if (detailed) {
        if (pci_cap_data & PCI_EXP_LNKCTL2_TLS) {
            pci_cap_read_data = (pci_cap_data & PCI_EXP_LNKCTL2_TLS);
            switch(pci_cap_read_data) {
                case PCI_EXP_LNKCTL2_TLS_2_5GT:
                    printf("\t\tTgt Link Speed: 2.5 GT/s - G1\n");
                    break;
                case PCI_EXP_LNKCTL2_TLS_5_0GT:
                    printf("\t\tTgt Link Speed: 5.0 GT/s - G2\n");
                    break;
                case PCI_EXP_LNKCTL2_TLS_8_0GT:
                    printf("\t\tTgt Link Speed: 8.0 GT/s - G3\n");
                    break;
                case PCI_EXP_LNKCTL2_TLS_16_0GT:
                    printf("\t\tTgt Link Speed: 16.0 GT/s - G4\n");
                    break;
                case PCI_EXP_LNKCTL2_TLS_32_0GT:
                    printf("\t\tTgt Link Speed: 32.0 GT/s - G5\n");
                    break;
                case PCI_EXP_LNKCTL2_TLS_64_0GT:
                    printf("\t\tTgt Link Speed: 64.0 GT/s - G6\n");
                    break;
                default:
                    printf("\t\tTgt Link Speed: Not Supported\n");
            }
        }
        else {
            printf("\t\tTgt Link Speed: Not Supported\n");
        }

        if (pci_cap_data & PCI_EXP_LNKCTL2_ENTER_COMP) {
            printf("\t\tEnter Compliance: Enabled\n");
        }
        else {
            printf("\t\tEnter Compliance: Not Enabled\n");
        }   

        if (pci_cap_data & PCI_EXP_LNKCTL2_HASD) {
            printf("\t\tHAS Disable: Enabled\n");
        }
        else {
            printf("\t\tHAS Disable: Not Enabled\n");
        }

        if (pci_cap_data & PCI_EXP_LNKCTL2_SEL_DEEMPHASIS) {
            printf("\t\tSelectable De-emphasis: -3.5dB\n");
        }
        else {
            printf("\t\tSelectable De-emphasis: -6dB\n");
        }

        if (pci_cap_data & PCI_EXP_LNKCTL2_TX_MARGIN) {
            printf("\t\tTx Margin: Normal Op Range\n");
        }
        else {
            printf("\t\tTx Margin: Normal Op Range\n");
        }

        if (pci_cap_data & PCI_EXP_LNKCTL2_ENT_MOD_COMP) {
            printf("\t\tEnter Mod Compl: Enabled\n");
        }
        else {
            printf("\t\tEnter Mod Compl: Not Enabled\n");
        }

        if (pci_cap_data & PCI_EXP_LNKCTL2_COMP_SOS) {
            printf("\t\tCompliance SOS: Enabled\n");
        }
        else {
            printf("\t\tCompliance SOS: Not Enabled\n");
        }

        if (pci_cap_data & PCI_EXP_LNKCTL2_COMP_PRESET_DEEMPHASIS) {
            printf("\t\tCompliance Pres/De-emp: -3.5dB\n");
        }
        else {
            printf("\t\tCompliance Pres/De-emp: -6dB\n");
        }
    }
}

           
void pci_dev_link_sts_2_print(uint32_t pci_cap_ptr, bool detailed)               
{
    uint32_t pci_cap_data = 0;
    uint16_t pci_cap_read_data = 0; 
    pci_cap_data = pDrvr->readConfig16(pci_cap_ptr + PCI_EXP_LNKSTA2);
    if (detailed) {
        if (pci_cap_data & PCI_EXP_LNKSTS2_CURR_DEEMPHASIS) {
            printf("\t\tCurrent De-emphasis Level: -3.5dB\n");
        }
        else {
            printf("\t\tCurrent De-emphasis Level: -6dB\n");
        }
        
        if (pci_cap_data & PCI_EXP_LNKSTS2_EQ_8_COMPLETE) {
            printf("\t\tEqu 8 GT/s: Complete\n");
        }
        else {
            printf("\t\tEqu 8 GT/s: Not Complete\n");
        }

        if (pci_cap_data & PCI_EXP_LNKSTS2_EQ_8_PHASE_1) {
            printf("\t\tEqu 8 GT/s Phase 1: Complete\n");
        }
        else {
            printf("\t\tEqu 8 GT/s Phase 1: Not Complete\n");
        }

        if (pci_cap_data & PCI_EXP_LNKSTS2_EQ_8_PHASE_2) {
            printf("\t\tEqu 8 GT/s Phase 2: Complete\n");
        }
        else {
            printf("\t\tEqu 8 GT/s Phase 2: Not Complete\n");
        }

        if (pci_cap_data & PCI_EXP_LNKSTS2_EQ_8_PHASE_3) {
            printf("\t\tEqu 8 GT/s Phase 3: Complete\n");
        }
        else {
            printf("\t\tEqu 8 GT/s Phase 3: Not Complete\n");
        }

        if (pci_cap_data & PCI_EXP_LNKSTS2_LNK_EQ_REQ) {
            printf("\t\tLink Equ 8 GT/s:Requested\n");
        }
        else {
            printf("\t\tLink Equ 8 GT/s: Not Requested\n");
        }    

        if (pci_cap_data & PCI_EXP_LNKSTS2_RETIMER_PD) {
            printf("\t\tRetimer Pres: Detected\n");
        }
        else {
            printf("\t\tRetimer Pres: Not Detected\n");
        }   

        if (pci_cap_data & PCI_EXP_LNKSTS2_2_RETIMER_PD) {
            printf("\t\tTwo Retimers Pres: Detected\n");
        }
        else {
            printf("\t\tTwo Retimers Pres: Not Detected\n");
        }     

        if (pci_cap_data & PCI_EXP_LNKSTS2_CROSSLINK_RES) {
            pci_cap_read_data = (pci_cap_data & PCI_EXP_LNKSTS2_CROSSLINK_RES);
            switch(pci_cap_read_data) {
                case PCI_EXP_LNKSTS2_CROSSLINK_SUPP_UP:
                    printf("\t\tCrosslink Nego: Upstream Port\n");
                    break;
                case PCI_EXP_LNKSTS2_CROSSLINK_SUPP_DOWN:
                    printf("\t\tCrosslink Nego: Downstream Port\n");
                    break;
                case PCI_EXP_LNKSTS2_CROSSLINK_SUPP_NOTC:
                    printf("\t\tCrosslink Nego: Not Completed\n");
                    break;
                default:
                    printf("\t\tCrosslink Nego: Not Supported\n");
            }
        }
        else {
            printf("\t\tCrosslink Nego: Not Supported\n");
        }     

        if (pci_cap_data & PCI_EXP_LNKSTS2_DS_CP) {
            pci_cap_read_data = (pci_cap_data & PCI_EXP_LNKSTS2_DS_CP);
            switch(pci_cap_read_data) {
                case PCI_EXP_LNKSTS2_DS_CP_LD_PND:
                    printf("\t\tLink Down: Comp Not Pres\n");
                    break;
                case PCI_EXP_LNKSTS2_DS_CP_LD_CNP:
                    printf("\t\tLink Down: Comp Pres\n");
                    break;
                case PCI_EXP_LNKSTS2_DS_CP_LU_CP:
                    printf("\t\tLink Up: Comp Pres\n");
                    break;

                case PCI_EXP_LNKSTS2_DS_CP_LU_CP_DRS:
                    printf("\t\tLink Up: Comp Pres & DRS Rec\n");
                    break;
                default:
                    printf("\t\tLink Down: Pres Not Det\n");
            }
        }
        else {
            printf("\t\tLink Down: Pres Not Det\n");
        }  

        if (pci_cap_data & PCI_EXP_LNKSTS2_DRS_MSG_REC) {
            printf("\t\tDRS Message: Received\n");
        }
        else {
            printf("\t\tDRSs Message: Not Received\n");
        }
    }
}

void pci_msi_flag_print(uint32_t pci_cap_ptr, bool detailed)
{
    uint32_t pci_cap_data = 0;
    pci_cap_data = pDrvr->readConfig16(pci_cap_ptr + PCI_MSI_FLAGS);
    if (pci_cap_data & PCI_MSI_FLAGS_ENABLE) {
        printf("\t\tMSI: Enabled\n");
    }
    else {
        printf("\t\tMSI: Not Enabled\n");
    }
    if (detailed) {
        if (pci_cap_data & PCI_MSI_FLAGS_QMASK) {
            printf("\t\tMSI Vectors Avail: %d\n", (1 << ((pci_cap_data & PCI_MSI_FLAGS_QMASK) >> 1)));
        }
        else {
            printf("\t\tMSI Vectors Avail: 0\n");
        }

        if (pci_cap_data & PCI_MSI_FLAGS_QSIZE) {
            printf("\t\tMSI Vectors Enabled: %d\n", (1 << ((pci_cap_data & PCI_MSI_FLAGS_QSIZE) >> 4)));
        }
        else {
            printf("\t\tMSI Vectors Enabled: 0\n");
        }

        if (pci_cap_data & PCI_MSI_FLAGS_64BIT) {
            printf("\t\tMSI 64-Bit Addr: Supported\n");
        }
        else {
            printf("\t\tMSI 64-Bit Addr: Not Supported\n");
        }

        if (pci_cap_data & PCI_MSI_FLAGS_MASKBIT) {
            printf("\t\tPer-Vec MSI Mask: Supported\n");
        }
        else {
            printf("\t\tPer-Vec MSI Mask: Not Supported\n");
        }

        if (pci_cap_data & PCI_MSI_FLAGS_EXT_MSG_DATA_CAP) {
            printf("\t\tExt Msg Data: Supported\n");
        }
        else {
            printf("\t\tExt Msg Data: Not Supported\n");
        }

        if (pci_cap_data & PCI_MSI_FLAGS_EXT_MSG_DATA_EN) {
            printf("\t\tExt Msg Data: Enabled\n");
        }
        else {
            printf("\t\tExt Msg Data: Not Enabled\n");
        }
    }
}

void pci_msi_msg_addr_lo_print(uint32_t pci_cap_ptr, bool detailed)
{
    uint32_t pci_cap_data = 0;
    pci_cap_data = pDrvr->readConfig32(pci_cap_ptr + PCI_MSI_ADDRESS_LO);
    if (detailed) {
        printf("\t\tMSI Msg Addr Low: 0x%x\n", pci_cap_data);
    }
}

void pci_msi_msg_addr_hi_print(uint32_t pci_cap_ptr, bool detailed)
{
    uint32_t pci_cap_data = 0;
    pci_cap_data = pDrvr->readConfig32(pci_cap_ptr + PCI_MSI_ADDRESS_HI);
    if (detailed) {
        if (pci_cap_data == 0) {
            printf("\t\tMSI Msg Addr High: 0x%x\n", pci_cap_data);
        }
        else{
            printf("\t\tMSI Msg Addr High: 0x%x\n", pci_cap_data);
        }
    }
}

void pci_msi_msg_data_32(uint32_t pci_cap_ptr, bool detailed)
{
    uint32_t pci_cap_data = 0;
    pci_cap_data = pDrvr->readConfig32(pci_cap_ptr + PCI_MSI_DATA_32);
    if (detailed) {
        printf("\t\tMSI Msg Data: 0x%x\n", pci_cap_data);
    }
}

void pci_msi_msg_mask_32(uint32_t pci_cap_ptr, bool detailed)
{
    uint32_t pci_cap_data = 0;
    pci_cap_data = pDrvr->readConfig32(pci_cap_ptr + PCI_MSI_MASK_32);
    if (detailed) {
        printf("\t\tMSI Mask: 0x%x\n", pci_cap_data);
    }
}

void pci_msi_msg_pending_32(uint32_t pci_cap_ptr, bool detailed)
{
    uint32_t pci_cap_data = 0;
    pci_cap_data = pDrvr->readConfig32(pci_cap_ptr + PCI_MSI_PENDING_32);
    if (detailed) {
        printf("\t\tMSI Pending: 0x%x\n", pci_cap_data);
    }
}

void pci_msi_msg_data_64(uint32_t pci_cap_ptr, bool detailed)
{
    uint32_t pci_cap_data = 0;
    pci_cap_data = pDrvr->readConfig32(pci_cap_ptr + PCI_MSI_DATA_64);
    if (detailed) {
        printf("\t\tMSI Msg Data: 0x%x\n", pci_cap_data);
    }
}

void pci_msi_msg_mask_64(uint32_t pci_cap_ptr, bool detailed)
{
    uint32_t pci_cap_data = 0;
    pci_cap_data = pDrvr->readConfig32(pci_cap_ptr + PCI_MSI_MASK_64);
    if (detailed) {
        printf("\t\tMSI Mask: 0x%x\n", pci_cap_data);
    }
}

void pci_msi_msg_pending_64(uint32_t pci_cap_ptr, bool detailed)
{
    uint32_t pci_cap_data = 0;
    pci_cap_data = pDrvr->readConfig32(pci_cap_ptr + PCI_MSI_PENDING_64);
    if (detailed) {
        printf("\t\tMSI Pending: 0x%x\n", pci_cap_data);
    }
}

void pci_msix_flag_print(uint32_t pci_cap_ptr, bool detailed)
{
    uint32_t pci_cap_data = 0;
    pci_cap_data = pDrvr->readConfig16(pci_cap_ptr + PCI_MSIX_FLAGS);
    if (detailed) {
        if (pci_cap_data & PCI_MSIX_FLAGS_QSIZE) {
            printf("\t\tMSI-X Table Size: %d\n", ((pci_cap_data & PCI_MSIX_FLAGS_QSIZE) + 1));
        }
        else {
            printf("\t\tMSI-X Table Size: 0\n");
        }

        if (pci_cap_data & PCI_MSIX_FLAGS_MASKALL) {
            printf("\t\tMSI-X Mask All\n");
        }
        else {
            printf("\t\tMSI-X Unmask All\n");
        }
    }
    if (pci_cap_data & PCI_MSIX_FLAGS_ENABLE) {
        printf("\t\tMSI-X Enabled: Enabled\n");
    }
    else {
        printf("\t\tMSI-X Enabled: Disabled\n");
    }
}

void pci_msix_table_print(uint8_t bar_num, uint32_t msi_x_table_offset, bool detailed)
{
    uint32_t msix_addr_lo = 0;
    uint32_t msix_addr_hi = 0;
    uint32_t msix_data = 0;
    uint32_t msix_vector = 0;
    if (detailed) {
        // msix_addr_lo = pDrvr->readBridge32(bar_num, msi_x_table_offset + PCI_MSIX_ENTRY_LOWER_ADDR);
        // msix_addr_hi = pDrvr->readBridge32(bar_num, msi_x_table_offset + PCI_MSIX_ENTRY_UPPER_ADDR);
        // msix_data = pDrvr->readBridge32(bar_num, msi_x_table_offset + PCI_MSIX_ENTRY_DATA);
        // msix_vector = pDrvr->readBridge32(bar_num, msi_x_table_offset + PCI_MSIX_ENTRY_VECTOR_CTRL);
        msix_addr_lo = pDrvr->readReg32(msi_x_table_offset + PCI_MSIX_ENTRY_LOWER_ADDR);
        msix_addr_hi = pDrvr->readReg32(msi_x_table_offset + PCI_MSIX_ENTRY_UPPER_ADDR);
        msix_data = pDrvr->readReg32(msi_x_table_offset + PCI_MSIX_ENTRY_DATA);
        msix_vector = pDrvr->readReg32(msi_x_table_offset + PCI_MSIX_ENTRY_VECTOR_CTRL);
        printf("\t\tTable Addr High: 0x%x\n", msix_addr_hi);
        printf("\t\tTable Addr Low: 0x%x\n", msix_addr_lo);
        printf("\t\tMSI-X Message Data: 0x%x\n", msix_data);
        if (msix_vector & PCI_MSIX_ENTRY_CTRL_MASKBIT) {
            printf("\t\tMSI-X Vector: Masked\n");
        }
        else {
            printf("\t\tMSI-X Vector: Unmasked\n");
        }
    }
}

void pci_msix_pba_print(uint8_t bar_num, uint32_t msi_x_pba_offset, bool detailed)
{
    // uint64_t msix_pba = 0;
    // msix_pba = pDrvr->readBridge64(bar_num, msi_x_pba_offset);
    // if (detailed) {
    //     printf("\t\tMSI-X Pending: 0x%lx\n", msix_pba);
    // }
    uint32_t msix_pba = 0;
    uint32_t msix_pba_up = 0;
    msix_pba = pDrvr->readReg32(msi_x_pba_offset);
    msix_pba_up = pDrvr->readReg32(msi_x_pba_offset + 0x4);
    if (detailed) {
        printf("\t\tMSI-X Pending: 0x%x\n", msix_pba);
        printf("\t\tMSI-X Pending Upper: 0x%x\n", msix_pba_up);
    }
}

void pci_msix_table_off_print(uint32_t pci_cap_ptr, bool detailed)
{
    uint8_t bar_num = 0; 
    uint32_t pci_cap_data = 0;
    uint32_t pci_cap_read_data = 0;
    uint32_t msi_x_table_offset = 0;
    pci_cap_data = pDrvr->readConfig32(pci_cap_ptr + PCI_MSIX_TABLE);
    if (detailed) {
        if (pci_cap_data & PCI_MSIX_TABLE_BIR) {
            pci_cap_read_data = pci_cap_data & PCI_MSIX_TABLE_BIR;
            switch(pci_cap_read_data) {
                case PCI_MSIX_TABLE_BIR_0:
                    printf("\t\tMSI-X Table BIR: 0x10 (BAR0)\n");
                    bar_num = 0;
                    break;
                case PCI_MSIX_TABLE_BIR_1:
                    printf("\t\tMSI-X Table BIR: 0x14 (BAR1)\n");
                    bar_num = 1;
                    break;
                case PCI_MSIX_TABLE_BIR_2:
                    printf("\t\tMSI-X Table BIR: 0x18 (BAR2)\n");
                    bar_num = 2;
                    break;
                case PCI_MSIX_TABLE_BIR_3:
                    printf("\t\tMSI-X Table BIR: 0x1C (BAR3)\n");
                    bar_num = 3;
                    break;
                case PCI_MSIX_TABLE_BIR_4:
                    printf("\t\tMSI-X Table BIR: 0x20 (BAR4)\n");
                    bar_num = 4;
                    break;
                case PCI_MSIX_TABLE_BIR_5:
                    printf("\t\tMSI-X Table BIR: 0x24 (BAR5)\n");
                    bar_num = 5;
                    break;
                default:
                    printf("\t\tMSI-X Table BIR: 0x10 (BAR0)\n");
                    bar_num = 0;
            }
        }
        else {
            printf("\t\tMSI-X Table BIR: 0x10 (BAR0)\n");
            bar_num = 0;
        }

        if (pci_cap_data & PCI_MSIX_TABLE_OFFSET) {
            printf("\t\tMSI-X Table Offset: 0x%x\n", (pci_cap_data & PCI_MSIX_TABLE_OFFSET));
            msi_x_table_offset = (pci_cap_data & PCI_MSIX_TABLE_OFFSET);
        }
        else {
            printf("\t\tMSI-X Table Offset: 0x0\n");
            msi_x_table_offset = (pci_cap_data & PCI_MSIX_TABLE_OFFSET);
        }
        pci_msix_table_print(bar_num, msi_x_table_offset, detailed);
    }
}

void pci_msix_pba_off_print(uint32_t pci_cap_ptr, bool detailed)
{
    uint8_t bar_num = 0;
    uint32_t pci_cap_data = 0;
    uint32_t pci_cap_read_data = 0;
    uint32_t msi_x_pba_offset = 0;
    pci_cap_data = pDrvr->readConfig32(pci_cap_ptr + PCI_MSIX_PBA);
    if (detailed) {
        if (pci_cap_data & PCI_MSIX_PBA_BIR) {
            pci_cap_read_data = pci_cap_data & PCI_MSIX_PBA_BIR;
            switch(pci_cap_read_data) {
                case PCI_MSIX_TABLE_BIR_0: //Re-use Table BIR defines
                    printf("\t\tMSI-X PBA BIR: 0x10 (BAR0)\n");
                    bar_num = 0;
                    break;
                case PCI_MSIX_TABLE_BIR_1:
                    printf("\t\tMSI-X PBA BIR: 0x14 (BAR1)\n");
                    bar_num = 1;
                    break;
                case PCI_MSIX_TABLE_BIR_2:
                    printf("\t\tMSI-X PBA BIR: 0x18 (BAR2)\n");
                    bar_num = 2;
                    break;
                case PCI_MSIX_TABLE_BIR_3:
                    printf("\t\tMSI-X PBA BIR: 0x1C (BAR3)\n");
                    bar_num = 3;
                    break;
                case PCI_MSIX_TABLE_BIR_4:
                    printf("\t\tMSI-X PBA BIR: 0x20 (BAR4)\n");
                    bar_num = 4;
                    break;
                case PCI_MSIX_TABLE_BIR_5:
                    printf("\t\tMSI-X PBA BIR: 0x24 (BAR5)\n");
                    bar_num = 5;
                    break;
                default:
                    printf("\t\tMSI-X PBA BIR: 0x10 (BAR0)\n");
                    bar_num = 0;
            }
        }
        else {
            printf("\t\tMSI-X PBA BIR: 0x10 (BAR0)\n");
            bar_num = 0;
        }

        if (pci_cap_data & PCI_MSIX_PBA_OFFSET) {
            printf("\t\tMSI-X PBA Offset: 0x%x\n", (pci_cap_data & PCI_MSIX_PBA_OFFSET));
            msi_x_pba_offset = (pci_cap_data & PCI_MSIX_PBA_OFFSET);
        }
        else {
            printf("\t\tMSI-X PBA Offset: 0x0\n");
            msi_x_pba_offset = (pci_cap_data & PCI_MSIX_PBA_OFFSET);
        }
        pci_msix_pba_print(bar_num, msi_x_pba_offset, detailed);
    }
}

void store_pci_cap(void)
{
    uint32_t pci_cap_list_sup = 0; 
    uint32_t pci_cap_ptr = 0;
    pci_cap_list_sup = pDrvr->readConfig16(PCI_STATUS);
    if (pci_cap_list_sup & PCI_STATUS_CAP_LIST) {

    }
    else {
        printf("PCI Cap List Not Supported!\n");
        return;
    }
    pci_cap_ptr = pDrvr->readConfig8(PCI_CAPABILITY_LIST);
    pci_cap_ptrs.clear();
    while (pci_cap_ptr != 0) {
        pci_cap_ptrs.push_back(pci_cap_ptr);
        pci_cap_ptr = pDrvr->readConfig8((pci_cap_ptr + 1));
    }   
}

void print_pci_cap(bool detailed)
{
    uint32_t pci_read_val = 0;
    uint32_t pci_cap_list_sup = 0; 
    uint32_t pci_cap_ptr = 0;
    uint32_t pci_cap_id = 0;
    uint32_t pci_cap_data = 0;
    uint16_t pci_cap_read_data = 0;
    pci_cap_list_sup = pDrvr->readConfig16(PCI_STATUS);
    if (pci_cap_list_sup & PCI_STATUS_CAP_LIST) {
        printf("\nPCI Cap List Supported: Yes\n");
    }
    else {
        printf("\nPCI Cap List Not Supported!\n");
        return;
    }
    
	printf("PCI Capabilities List:\n");
	for (size_t i = 0; i < pci_cap_ptrs.size(); i++) {
        pci_cap_ptr = pci_cap_ptrs[i];
        
    // pci_cap_ptr = pDrvr->readConfig8(PCI_CAPABILITY_LIST);
    // printf("PCI Capabilities List:\n");
    // while (pci_cap_ptr != 0) {
        pci_cap_id = pDrvr->readConfig8(pci_cap_ptr);
        
        switch(pci_cap_id) {
            case PCI_CAP_ID_PM:
                if (detailed) {
                    printf("Power Management [ID: 0x%02x, offset: 0x%02x]:\n", pci_cap_id, pci_cap_ptr);
                    pci_pm_flag_print(pci_cap_ptr, detailed);
                }
                
                if (detailed) {
                    printf("    Power Management Control:\n");  
                    pci_pm_ctl_print(pci_cap_ptr, detailed);                  
                }
                break;
            case PCI_CAP_ID_AGP:
                if (detailed) {
                    printf("Accelerated Graphics Port [ID: 0x%02x, offset: 0x%02x]\n", pci_cap_id, pci_cap_ptr);
                }
                break;
            case PCI_CAP_ID_VPD:
                if (detailed) {
                    printf("Vital Product Data [ID: 0x%02x, offset: 0x%02x]\n", pci_cap_id, pci_cap_ptr);
                }
                break;
            case PCI_CAP_ID_SLOTID:
                if (detailed) {
                    printf("Slot Identification [ID: 0x%02x, offset: 0x%02x]\n", pci_cap_id, pci_cap_ptr);
                }
                break;
            case PCI_CAP_ID_MSI:
                printf("Message Signalled Interrupts [ID: 0x%02x, offset: 0x%02x]:\n", pci_cap_id, pci_cap_ptr);
                pci_msi_flag_print(pci_cap_ptr, detailed);
                if ((pDrvr->readConfig16(pci_cap_ptr + PCI_MSI_FLAGS)) & PCI_MSI_FLAGS_64BIT) {
                    pci_msi_msg_addr_lo_print(pci_cap_ptr, detailed);
                    pci_msi_msg_addr_hi_print(pci_cap_ptr, detailed);
                    pci_msi_msg_data_64(pci_cap_ptr, detailed);
                    pci_msi_msg_mask_64(pci_cap_ptr, detailed);
                    pci_msi_msg_pending_64(pci_cap_ptr, detailed);
                }
                else {
                    pci_msi_msg_addr_lo_print(pci_cap_ptr, detailed);
                    pci_msi_msg_data_32(pci_cap_ptr, detailed);
                    pci_msi_msg_mask_32(pci_cap_ptr, detailed);
                    pci_msi_msg_pending_32(pci_cap_ptr, detailed);
                }
                break;
            case PCI_CAP_ID_CHSWP:
                if (detailed) {
                    printf("CompactPCI HotSwap [ID: 0x%02x, offset: 0x%02x]\n", pci_cap_id, pci_cap_ptr);
                }
                break;
            case PCI_CAP_ID_PCIX:
                if (detailed) {
                    printf("PCI-X [ID: 0x%02x, offset: 0x%02x]\n", pci_cap_id, pci_cap_ptr);
                }
                break;
            case PCI_CAP_ID_HT:
                if (detailed) {
                    printf("HyperTransport [ID: 0x%02x, offset: 0x%02x]\n", pci_cap_id, pci_cap_ptr);
                }
                break;
            case PCI_CAP_ID_VNDR:
                if (detailed) {
                    printf("Vendor-Specific [ID: 0x%02x, offset: 0x%02x]\n", pci_cap_id, pci_cap_ptr);
                }
                break;
            case PCI_CAP_ID_DBG:
                if (detailed) {
                    printf("Debug port [ID: 0x%02x, offset: 0x%02x]\n", pci_cap_id, pci_cap_ptr);
                }
                break;
            case PCI_CAP_ID_CCRC:
                if (detailed) {
                    printf("CompactPCI Central Resource Control [ID: 0x%02x, offset: 0x%02x]\n", pci_cap_id, pci_cap_ptr);
                }
                break;
            case PCI_CAP_ID_SHPC:
                if (detailed) {
                    printf("Bridge subsystem vendor/device ID [ID: 0x%02x, offset: 0x%02x]\n", pci_cap_id, pci_cap_ptr);
                }
                break;
            case PCI_CAP_ID_SSVID:
                if (detailed) {
                    printf("PCI Standard Hot-Plug Controller [ID: 0x%02x, offset: 0x%02x]\n", pci_cap_id, pci_cap_ptr);
                }
                break;
            case PCI_CAP_ID_AGP3:
                if (detailed) {
                    printf("AGP Target PCI-PCI Bridge [ID: 0x%02x, offset: 0x%02x]\n", pci_cap_id, pci_cap_ptr);
                }
                break;
            case PCI_CAP_ID_SECDEV:
                if (detailed) {
                    printf("Secure Device [ID: 0x%02x, offset: 0x%02x]\n", pci_cap_id, pci_cap_ptr);
                }
                break;
            case PCI_CAP_ID_EXP:
                printf("PCI Express Capability [ID: 0x%02x, offset: 0x%02x]:\n", pci_cap_id, pci_cap_ptr);
                pci_exp_flag_print(pci_cap_ptr, detailed);
                
				if (detailed) {
                    printf("    PCI Express Device Capabilities:\n");
                	pci_dev_cap_print(pci_cap_ptr, detailed);
				}
                
                printf("    PCI Express Device Control:\n");
                pci_dev_ctl_print(pci_cap_ptr, detailed);
                
				if (detailed) {                
                    printf("    PCI Express Device Status:\n");
                	pci_dev_sts_print(pci_cap_ptr, detailed);
				}
                
                if (detailed) {                
                    printf("    PCI Express Link Capabilities:\n");
                	pci_dev_link_cap_print(pci_cap_ptr, detailed);
				}
                
                if (detailed) {                
                    printf("    PCI Express Link Control:\n");
                	pci_dev_link_ctl_print(pci_cap_ptr, detailed);
				}
                
                printf("    PCI Express Link Status:\n");
                pci_dev_link_sts_print(pci_cap_ptr, detailed);
                
				pci_cap_data = pDrvr->readConfig16(pci_cap_ptr + PCI_EXP_FLAGS);
                pci_cap_read_data = (pci_cap_data & PCI_EXP_FLAGS_SLOT);
                if (pci_cap_read_data) {
                    printf("    PCI Express Slot Capabilities:\n");
                    pci_dev_slot_cap_print(pci_cap_ptr, detailed);

                    printf("    PCI Express Slot Control:\n");
                    pci_dev_slot_ctl_print(pci_cap_ptr, detailed);

                    printf("    PCI Express Slot Status:\n");
                    pci_dev_slot_sts_print(pci_cap_ptr, detailed);
                }
                pci_cap_data = pDrvr->readConfig16(pci_cap_ptr + PCI_EXP_FLAGS);
                pci_cap_read_data = (pci_cap_data & PCI_EXP_FLAGS_TYPE) >> 4;
                if ((pci_cap_read_data == PCI_EXP_TYPE_ROOT_PORT) || (pci_cap_read_data == PCI_EXP_TYPE_UPSTREAM)) {
                    printf("    PCI Express Root Control:\n");
                    pci_dev_root_ctl_print(pci_cap_ptr, detailed);

                    printf("    PCI Express Root Capabilities:\n");
                    pci_dev_root_cap_print(pci_cap_ptr, detailed);

                    printf("    PCI Express Root Status:\n");
                    pci_dev_root_sts_print(pci_cap_ptr, detailed);
                }
                if (detailed) {  
                    printf("    PCI Express Device Capabilities 2:\n");
                }
                pci_dev_cap_2_print(pci_cap_ptr, detailed);
                if (detailed) {  
                    printf("    PCI Express Device Control 2:\n");
                }
                pci_dev_ctl_2_print(pci_cap_ptr, detailed);
                if (detailed) {  
                    printf("    PCI Express Link Capabilities 2:\n");
                }
                pci_dev_link_cap_2_print(pci_cap_ptr, detailed);
                if (detailed) {  
                    printf("    PCI Express Link Control 2:\n");
                }
                pci_dev_link_ctl_2_print(pci_cap_ptr, detailed);
                if (detailed) {  
                    printf("    PCI Express Link Status 2:\n");
                }
                pci_dev_link_sts_2_print(pci_cap_ptr, detailed);                

                break;

            case PCI_CAP_ID_MSIX:
                printf("Message Signalled Interrupts eXtended [ID: 0x%02x, offset: 0x%02x]:\n", pci_cap_id, pci_cap_ptr);
                pci_msix_flag_print(pci_cap_ptr, detailed);
                pci_msix_table_off_print(pci_cap_ptr, detailed);
                pci_msix_pba_off_print(pci_cap_ptr, detailed);
                break;
            case PCI_CAP_ID_SATA:
                if (detailed) {  
                    printf("SATA Data/Index Config [ID: 0x%02x, offset: 0x%02x]\n", pci_cap_id, pci_cap_ptr);
                }
                break;
            case PCI_CAP_ID_AF:
                if (detailed) {  
                    printf("PCI Advanced Features [ID: 0x%02x, offset: 0x%02x]\n", pci_cap_id, pci_cap_ptr);
                }
                break;            
            case PCI_CAP_ID_EA:
                if (detailed) {  
                    printf("PCI Enhanced Allocation [ID: 0x%02x, offset: 0x%02x]\n", pci_cap_id, pci_cap_ptr);
                }
                break;
            default:
                printf("Unknown Capability ID: 0x%x\n", pci_cap_id);
                break;
        }
        // pci_cap_ptr = pDrvr->readConfig8((pci_cap_ptr + 1));
    }
}




