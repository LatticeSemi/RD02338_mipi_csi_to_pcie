// SPDX-License-Identifier: MIT
/*   ==================================================================
 
     >>>>>>>>>>>>>>>>>>>>>>> COPYRIGHT NOTICE <<<<<<<<<<<<<<<<<<<<<<<<<
     ------------------------------------------------------------------
     Copyright (c) 2025 by Lattice Semiconductor Corporation
     ALL RIGHTS RESERVED
     ------------------------------------------------------------------
 
     DISCLAIMER:
 
    LATTICE MAKES NO WARRANTIES ON THIS FILE OR ITS CONTENTS,
    WHETHER EXPRESSED, IMPLIED, STATUTORY,
    OR IN ANY PROVISION OF THE LATTICE PROPEL LICENSE AGREEMENT OR
    COMMUNICATION WITH LICENSEE,
    AND LATTICE SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
    MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
    LATTICE DOES NOT WARRANT THAT THE FUNCTIONS CONTAINED HEREIN WILL MEET
    LICENSEE 'S REQUIREMENTS, OR THAT LICENSEE' S OPERATION OF ANY DEVICE,
    SOFTWARE OR SYSTEM USING THIS FILE OR ITS CONTENTS WILL BE
    UNINTERRUPTED OR ERROR FREE,
    OR THAT DEFECTS HEREIN WILL BE CORRECTED.
    LICENSEE ASSUMES RESPONSIBILITY FOR SELECTION OF MATERIALS TO ACHIEVE
    ITS INTENDED RESULTS, AND FOR THE PROPER INSTALLATION, USE,
    AND RESULTS OBTAINED THEREFROM.
    LICENSEE ASSUMES THE ENTIRE RISK OF THE FILE AND ITS CONTENTS PROVING
    DEFECTIVE OR FAILING TO PERFORM PROPERLY AND IN SUCH EVENT,
    LICENSEE SHALL ASSUME THE ENTIRE COST AND RISK OF ANY REPAIR, SERVICE,
    CORRECTION,
    OR ANY OTHER LIABILITIES OR DAMAGES CAUSED BY OR ASSOCIATED WITH THE
    SOFTWARE.IN NO EVENT SHALL LATTICE BE LIABLE TO ANY PARTY FOR DIRECT,
    INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES,
    INCLUDING LOST PROFITS,
    ARISING OUT OF THE USE OF THIS FILE OR ITS CONTENTS,
    EVEN IF LATTICE HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
    LATTICE 'S SOLE LIABILITY, AND LICENSEE' S SOLE REMEDY,
    IS SET FORTH ABOVE.
    LATTICE DOES NOT WARRANT OR REPRESENT THAT THIS FILE,
    ITS CONTENTS OR USE THEREOF DOES NOT INFRINGE ON THIRD PARTIES'
    INTELLECTUAL PROPERTY RIGHTS, INCLUDING ANY PATENT. IT IS THE USER' S
    RESPONSIBILITY TO VERIFY THE USER SOFTWARE DESIGN FOR CONSISTENCY AND
    FUNCTIONALITY THROUGH THE USE OF FORMAL SOFTWARE VALIDATION METHODS.
     ------------------------------------------------------------------
 
     ================================================================== */
 

#include <stdio.h>
#include <string.h>
#include <cstdint>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <vector>
#include "PCIE_IF.h"
#include "cap_check.h"
using namespace std;

std::vector<uint32_t> pci_cap_ptrs;
PCIE_IF *pDrvr;

/**
 * @brief Reads data from a specified BAR (Base Address Register) at a given offset and size.
 *
 * This function reads data from a device BAR memory using the specified BAR number, offset, 
 * and size. It supports 8-bit, 16-bit, 32-bit, and 64-bit reads. For unsupported sizes, 
 * it defaults to a 32-bit read.
 *
 * @param bar_num The BAR number to read from.
 * @param offset The offset within the BAR to read from.
 * @param size The size of the data to read (1, 2, 4, or 8 bytes).
 */
static void read_bridge(uint8_t bar_num, uint32_t offset, uint8_t size)
{
    uint64_t data = 0;
    if (size == 8) {
        data = pDrvr->read64(bar_num, offset);  
    } else if (size == 4) {
        data = pDrvr->read32(bar_num, offset); 
    } else if (size == 2) {
        data = pDrvr->read16(bar_num, offset); 
    } else if (size == 1) {
        data = pDrvr->read8(bar_num, offset); 
    } else {
        printf("Unknown data size %d. Defaulting to 32-bit read.\n", size);
        data = pDrvr->read32(bar_num, offset);    
    }
    printf("\nRead %d-bit data from BAR%d offset 0x%x: 0x%lx\n",size*8, bar_num, offset, data);
}

/**
 * @brief Writes data to a specified BAR (Base Address Register) at a given offset and size.
 *
 * This function writes data to a device BAR memory using the specified BAR number, offset, 
 * size, and data. It supports 8-bit, 16-bit, 32-bit, and 64-bit writes. For unsupported sizes, 
 * it defaults to a 32-bit write.
 *
 * @param bar_num The BAR number to write to.
 * @param offset The offset within the BAR to write to.
 * @param size The size of the data to write (1, 2, 4, or 8 bytes).
 * @param data The data to be written.
 */
static void write_bridge(uint8_t bar_num, uint32_t offset, uint8_t size, uint64_t data)
{
    if (size == 8) {
        pDrvr->write64(bar_num, offset, data); 
    } else if (size == 4) {
        pDrvr->write32(bar_num, offset, data);  
    } else if (size == 2) {
        pDrvr->write16(bar_num, offset, data);  
    } else if (size == 1) {
        pDrvr->write8(bar_num, offset, data);  
    } else {
        printf("Unknown data size %d. Defaulting to 32-bit write.\n", size);
        pDrvr->write32(bar_num, offset, data);  
    }
    printf("\nWrote %d-bit data 0x%lx to BAR%d offset 0x%x\n",size*8, data, bar_num, offset);
}

/**
 * Format a buffer of 8 bit values (bytes) into a displayable text string.
 *
 *  00000000: 55 66 77 ...
 *  00000010: a0 b0 c0 ...
 * 
 * @param ostr the caller supplied string to return the formatted bytes in
 * @param startAddr the starting address of the data, used in address field of format
 * @param len the number of bytes to format
 * @param data the array of bytes to process
 * @return true if successful, false if error encountered
 */
bool formatBlockOfBytes(std::string &ostr, uint32_t startAddr, uint32_t len, const std::vector<uint8_t> &data) {
    if (data.empty() || len == 0) {
        return false;
    }
    std::ostringstream oss;
    uint32_t addr = startAddr & 0xFFFFFFF0; // Align address to 16-byte boundary
    uint32_t offset = startAddr - addr;    // Offset within the first line
    uint32_t totalLen = len + offset;     // Adjust length to account for alignment
    if (totalLen > 0xFFFFFFF0) { // Prevent overflow
        return false;
    }
    for (uint32_t i = 0; i < totalLen; ++i) {
        if (i % 16 == 0) { // Start a new line
            if (i > 0) {
                oss << "\n";
            }
            oss << std::hex << std::noshowbase << std::setw(8) << std::setfill('0') << addr << ":";
            addr += 16;
        }
        if (i < offset || i - offset >= len || i - offset >= data.size()) {
            // Fill blank spaces for alignment
            oss << "   ";
        } else {
            // Append the byte in hex format
            oss << " " << std::hex << std::noshowbase << std::setw(2) << std::setfill('0') << static_cast<int>(data[i - offset]);
        }
    }
    oss << "\n";
    ostr = oss.str();
    printf("%s", ostr.c_str());
    return true;
}


/**
 * Format a buffer of 16 bit values (words) into a displayable text string.
 *
 *  00000000: 5566 7788 ...
 *  00000010: a0b0 c0d0 ...
 * 
 * @param ostr the caller supplied string to return the formatted shorts in
 * @param startAddr the starting address of the data, used in address field of format
 * @param len the number of shorts to format
 * @param data the array of shorts to process
 * @return true if successful, false if error encountered
 */
bool formatBlockOfWords(std::string &ostr, uint32_t startAddr, uint32_t len, const std::vector<uint16_t> &data) {
    if (data.empty() || len == 0) {
        return false;
    }
    std::ostringstream oss;
    uint32_t addr = startAddr & 0xFFFFFFF0; 
    uint32_t offset = (startAddr - addr) / sizeof(uint16_t); 
    uint32_t totalLen = len + offset; 
    if (totalLen > 0xFFFFFFF0 / sizeof(uint16_t)) { 
        return false;
    }
    for (uint32_t i = 0; i < totalLen; ++i) {
        if (i % 8 == 0) { 
            if (i > 0) {
                oss << "\n";
            }
            oss << std::hex << std::noshowbase << std::setw(8) << std::setfill('0') << addr << ":";
            addr += 16;
        }
        if (i < offset || i - offset >= len || i - offset >= data.size()) {
            oss << "     ";  // 5 spaces to match " NNNN" format (1 space + 4 hex digits)
        } else {
            oss << " " << std::hex << std::noshowbase << std::setw(4) << std::setfill('0') << data[i - offset];
        }
    }
    oss << "\n";
    ostr = oss.str();
    printf("%s", ostr.c_str());
    return true;
}


/**
 * Format a buffer of 32 bit values (dwords) into a displayable text string.
 *
 *  00000000: 55667788 ...
 *  00000010: a0b0c0d0 aabbccdd 11223344 ...
 * 
 * @param ostr the caller supplied string to return the formatted words in
 * @param startAddr the starting address of the data, used in address field of format
 * @param len the number of words to format
 * @param data the array of words to process
 * @return true if successful, false if error encountered
 */
bool formatBlockOfDWords(std::string &ostr, uint32_t startAddr, uint32_t len, const std::vector<uint32_t> &data) {
   if (data.empty() || len == 0) {
        return false;
    }
    std::ostringstream oss;
    uint32_t addr = startAddr & 0xFFFFFFF0; 
    uint32_t offset = (startAddr - addr) / sizeof(uint32_t); 
    uint32_t totalLen = len + offset;
    if (totalLen > 0xFFFFFFF0 / sizeof(uint32_t)) {
        return false;
    }
    for (uint32_t i = 0; i < totalLen; ++i) {
        if (i % 4 == 0) {
            if (i > 0) {
                oss << "\n";
            }
            oss << std::hex << std::noshowbase << std::setw(8) << std::setfill('0') << addr << ":";
            addr += 16;
        }
        if (i < offset || i - offset >= len || i - offset >= data.size()) {
            oss << "         ";
        } else {
            oss << " " << std::hex << std::noshowbase << std::setw(8) << std::setfill('0') << data[i - offset];
        }
    }
    oss << "\n";
    ostr = oss.str();
    printf("%s", ostr.c_str());
    return true;
}

/**
 * Format a buffer of 64 bit values (qwords) into a displayable text string.
 *
 *  00000000: 1122334455667788 ...
 *  00000010: a0b0c0d0aabbccdd 1122334455667788 ...
 * 
 * @param ostr the caller supplied string to return the formatted words in
 * @param startAddr the starting address of the data, used in address field of format
 * @param len the number of words to format
 * @param data the array of words to process
 * @return true if successful, false if error encountered
 */
bool formatBlockOfQWords(std::string &ostr, uint32_t startAddr, uint32_t len, const std::vector<uint64_t> &data) {
    if (data.empty() || len == 0) {
        return false;
    }
    std::ostringstream oss;
    uint32_t addr = startAddr & 0xFFFFFFF0; 
    uint32_t offset = (startAddr - addr) / sizeof(uint64_t); 
    uint32_t totalLen = len + offset; 
    if (totalLen > 0xFFFFFFF0 / sizeof(uint64_t)) {
        return false;
    }
    for (uint32_t i = 0; i < totalLen; ++i) {
        if (i % 2 == 0) {
            if (i > 0) {
                oss << "\n";
            }
            oss << std::hex << std::noshowbase << std::setw(8) << std::setfill('0') << addr << ":";
            addr += 16;
        }
        if (i < offset || i - offset >= len || i - offset >= data.size()) {
            oss << "                 ";
        } else {
            oss << " " << std::hex << std::noshowbase << std::setw(16) << std::setfill('0') << data[i - offset];
        }
    }
    oss << "\n";
    ostr = oss.str();
    printf("%s", ostr.c_str());

    return true;
}

/**
 * @brief Validates memory by writing and reading data to/from a specified BAR.
 *
 * This function performs memory validation by writing a sequence of values to a device BAR 
 * memory at a specified BAR and offset, then reading the values back and comparing them. 
 * It supports 8-bit, 16-bit, 32-bit, and 64-bit modes. For invalid modes, it exits with an 
 * error message. Returns the validation status and populates the read buffer via pointer parameter.
 *
 * @param bar_num The BAR number to validate memory on.
 * @param size The total size of the memory region to validate.
 * @param mode The access mode (1 for 8-bit, 2 for 16-bit, 4 for 32-bit, 8 for 64-bit).
 * @param readBuf Pointer to vector that will be populated with read data (only on success).
 * @return bool indicating success (true) or failure (false).
 */
static bool validate_memory(int bar_num, size_t size, int mode, std::vector<uint64_t>* readBuf) {
    
    // Size validation is done by the caller before calling this function
    size_t numInts = size / mode;
    
    bool match = true;
    std::vector<uint64_t> writeBuf(numInts);
    
    // Resize output buffer to hold read data
    if (readBuf) {
        readBuf->resize(numInts);
    }
    for (size_t i = 0; i < numInts; i++) {
        uint64_t value = 0;
        switch (mode) {
            case 1: // 8-bit
                for (int j = 0; j < 1; j++) {
                    value |= ((i * 1 + j) & 0xFF) << (j * 8);
                }
                break;
            case 2: // 16-bit
                for (int j = 0; j < 2; j++) {
                    value |= ((i * 2 + j) & 0xFF) << (j * 8);
                }
                break;
            case 4: // 32-bit
                for (int j = 0; j < 4; j++) {
                    value |= ((i * 4 + j) & 0xFF) << (j * 8);
                }
                break;
            case 8: // 64-bit
                for (int j = 0; j < 8; j++) {
                    value |= ((i * 8 + j) & 0xFF) << (j * 8);
                }
                break;
            default:
                printf("Invalid mode! Use 'b', 'w', 'd', or 'q'.\n");
                if (readBuf) {
                    readBuf->clear();
                }
                return false;  // Return failure status            
        }
        writeBuf[i] = value;

    }
    for (size_t i = 0; i < numInts; i++) {
        if (mode == 1) {
            pDrvr->write8(bar_num, (i * mode), writeBuf[i]);
        } else if (mode == 2) {
            pDrvr->write16(bar_num, (i * mode), writeBuf[i]);
        } else if (mode == 4) {
            pDrvr->write32(bar_num, (i * mode), writeBuf[i]);
        } else if (mode == 8) {
            pDrvr->write64(bar_num, (i * mode), writeBuf[i]);
        }
    }
    // Read data directly into output buffer and compare
    if (!readBuf) {
        printf("Error: readBuf pointer is null.\n");
        return false;
    }
    
    for (size_t i = 0; i < numInts; i++) {
        if (mode == 1) {
            (*readBuf)[i] = pDrvr->read8(bar_num, (i * mode));
        } else if (mode == 2) {
            (*readBuf)[i] = pDrvr->read16(bar_num, (i * mode));
        } else if (mode == 4) {
            (*readBuf)[i] = pDrvr->read32(bar_num, (i * mode));
        } else if (mode == 8) {
            (*readBuf)[i] = pDrvr->read64(bar_num, (i * mode));
        }
    }
    // Compare the buffers
    for (size_t i = 0; i < numInts; i++) {
        if (writeBuf[i] != (*readBuf)[i]) {
            printf("Mismatch at index %zu: wrote 0x%lx, read 0x%lx\n",
                   i, writeBuf[i], (*readBuf)[i]);
            match = false;
        }
    }
    if (match) {
        printf("Memory validation successful: all [%zu bytes] values match.\n", size);
        return true;  // Return success status
    } else {
        printf("Memory validation failed: mismatches found.\n");
        // Clear output buffer on failure - don't return data for display
        if (readBuf) {
            readBuf->clear();
        }
        return false;  // Return failure status
    }
}

/**
 * @brief Get the device mode.
 *
 * This function reads the device mode (TLP, BRIDGE or DMA) from the kernel driver
 * and returns the value.
 * @return device mode value
 */
deviceMode_t getDeviceMode(void) 
{
    int mode = pDrvr->getPCIeDeviceMode();
    //printf("Device Mode: ");
    
    switch (mode) {
        case TLP:
            printf("TLP Mode\n");
            return TLP;
        case BRIDGE_MSI:
            printf("Bridge Mode (MSI)\n");
            return BRIDGE_MSI;
        case BRIDGE_MSIX:
            printf("Bridge Mode (MSI-X)\n");
            return BRIDGE_MSIX;
        case DMA:
            printf("DMA Mode\n");
            return DMA;
        default:
            if (mode < 0) {
                printf("Error reading device mode!\n");
            } else {
                printf("Unknown device mode: %d\n", mode);
            }
            return TLP;  //default to TLP when error
    }
}

/**
 * @brief Configures a user interrupt with a specific MSI vector value.
 *
 * This function sets the MSI vector value for a user interrupt in bridge mode.
 * The user interrupt number must be between 0 and 15, and the vector value 
 * must be between 0 and 31.
 *
 * @param usr_int The user interrupt number (0-15).
 * @param vec_val The MSI vector value (0-31).
 */
void confUsrInt(uint8_t usr_int, uint8_t vec_val)
{
    pDrvr->setUserIntMSIVector(usr_int, vec_val);
}

/**
 * @brief Displays information about PCIe BARs (Base Address Registers).
 *
 * This function retrieves and displays information about the PCIe BARs, including 
 * the BAR number, physical start address, and size. If device mode is bridge or DMA, 
 * it marks the first BAR as containing FPGA registers.
 *
 * @param mode The device operating mode.
 */
void showBars(deviceMode_t mode)
{
    struct PCIResourceInfo PCIinfo;
    pDrvr->getPCIBarInfo(&PCIinfo);

    printf("\nPCIe BAR Info:\n");
    for (uint32_t i = 0; i < PCIinfo.numBARs; i++)
    {
        printf("BAR %d:\t", PCIinfo.BAR[i].nBAR);
        printf("Addr 0x%lx \t", PCIinfo.BAR[i].physStartAddr);
        if (i == 0) {
            if (mode == BRIDGE_MSI || mode == BRIDGE_MSIX || mode == DMA) {
                printf("Size %d Bytes \t   [FPGA Registers]\n", PCIinfo.BAR[i].size);
            }
            else {
                printf("Size %d Bytes \t\n", PCIinfo.BAR[i].size);
            }
            
        }
        else {
            printf("Size %d Bytes \t\n", PCIinfo.BAR[i].size);
        }
    }
}

/**
 * @brief Displays the PCIe Menu.
 *
 * This function prints the available commands and their descriptions for the PCIe 
 * menu. It provides options for dumping PCI configuration space, setting or 
 * showing BARs, reading and writing BARs, validating memory, showing help, and exiting.
 */
void showHelp(deviceMode_t mode)
{
    printf("\n============================================= PCIe Menu ============================================\n");
    printf("|  c           [Dump PCI Config Space]\n");
    printf("|  b           [Set/Show BARs]  [<bar number>]\n");
    printf("|  r[b|w|d|q]  [Read BAR b=8bit, w=16bit, d=32bit, q=64bit]   [<addr[hex]> <count>]\n");
    printf("|  w[b|w|d|q]  [Write BAR b=8bit, w=16bit, d=32bit, q=64bit]  [<addr[hex]> <data_1[hex]>...<data_n[hex]>]\n");
    printf("|  v[b|w|d|q]  [Validate Memory b=8bit, w=16bit, d=32bit, q=64bit]  [<size>]\n");
    
    if (mode == BRIDGE_MSI) {
        printf("|  u           [Configure User Interrupt] [<usr_int#: 0 - 15> <vector_val: 0 - 31>]\n");
    }
    
    printf("|  h           [Show Help]\n");
    printf("|  q,x         [Quit/Exit]\n");
    printf("====================================================================================================\n");
}

/**
 * @brief Runs the PCIe Menu.
 *
 * This function provides an interactive menu for performing various PCIe-related 
 * operations. It allows users to display PCI configuration space, 
 * set or show BARs, read and write BARs, validate memory, and display help. The menu 
 * processes user commands in a loop until the user chooses to exit.
 *
 * @param PCIinfo Pointer to the PCI resource information structure.
 * @param deviceMode The current device operating mode.
 */
void runMenu(const struct PCIResourceInfo *PCIinfo, deviceMode_t deviceMode) 
{
    bool done;
    std::string line;
    done = false;
    int bar_num = 0;
    while (!done) {
        showHelp(deviceMode);
        printf("Current BAR: %d\n", bar_num);
        printf("Enter command: ");
        fflush(stdout);  // Force output to be displayed immediately
        std::getline(std::cin, line);

        std::istringstream iss(line);
        std::string cmd_str;
        std::string results;
        iss >> cmd_str;
        if (cmd_str.length() == 1) {    
            switch (cmd_str[0]) {
                case 'q': // quit
                case 'x':
                case 'Q':
                case 'X':
                    printf("Exiting debug menu.\n");
                    done = true;
                    break;
                case 'c':
                case 'C':    
                {
                    std::vector<uint8_t> buf;
                    buf.resize(LINE_BUFFER_SIZE);
                    printf("\n\n======= PCI Config Registers ==========\n");
                    if (pDrvr->getPCIConfigRegs(buf.data())) {
                        printf("\nPCI Config Registers (0x00-0x3f):\n");
                        formatBlockOfBytes(results, PCI_CFG_START, PCI_CFG_END, buf);
                        printf("\nPCI Config Registers (0x40-0xff):\n");
                        std::vector<uint8_t> subBuf(buf.begin() + 0x40, buf.end());
                        formatBlockOfBytes(results, PCI_CAP_START, PCI_CAP_END, subBuf);
                    }
                    else {
                        printf("Error reading PCI Config Registers\n");
                    }  
                    break;    
                }  
                case 'h': //help
                case 'H':
                case '?':
                    showHelp(deviceMode);
                    break;       
                case 'b': // Show BARs
                {
                    int new_bar_num;
                    showBars(deviceMode);
                    if (!(iss >> new_bar_num)) {
                        printf("\n");
                    } else if (new_bar_num >= static_cast<int>(PCIinfo->numBARs)) {
                        printf("Invalid BAR number: %d. It must be less than %u (numBars).\n", new_bar_num, PCIinfo->numBARs);
                    } else {
                        bar_num = new_bar_num;
                        printf("BAR number set to %d.\n", bar_num);
                    }
                    break;
                }    
                case 'u': // Configure User Interrupt
                {
                    int usr_int = 0;
                    int vec_val = 0;
                    if (!(iss >> std::dec >> usr_int)) {
                        printf("Failed to read user interrupt number. Please provide a valid number.\n");
                        break;
                    }
                    if (usr_int < 0 || usr_int > 15) {
                        printf("Invalid user interrupt number: %d. It must be between 0 and 15.\n", usr_int);
                        break;
                    }
                    if (!(iss >> std::dec >> vec_val)) {
                        printf("Failed to read vector value. Please provide a valid number.\n");
                        break;
                    }   
                    if (vec_val < 0 || vec_val > 31) {
                        printf("Invalid vector value: %d. It must be between 0 and 31.\n", vec_val);
                        break;
                    }                 
                    if (!iss.fail()) {
                        confUsrInt(usr_int, vec_val);
                        printf("User Interrupt %d configured with vector value %d.\n", usr_int, vec_val);
                    }
                    break;
                }
            }
        }
        else if (cmd_str.length() == 2) {
            char operation = cmd_str[0];
            char type = cmd_str[1];

            switch (operation) {
                case 'r': // Read Operation
                {
                    size_t count = 1; // Default to reading 1 byte/word/dword/qword
                    uint64_t addr = 0; // Default address
                    if (!(iss >> std::hex >> addr)) {
                        printf("Failed to read address. Please provide a valid address.\n");
                        break;
                    }
                    if (!(iss >> std::dec >> count)) {
                        printf("Failed to read count. Please provide count in decimal.\n");
                        // count = 1;
                    }    
                    if (addr >= PCIinfo->BAR[bar_num].size) {
                        printf("Address exceed range of BAR %d. Please provide a valid address.\n", bar_num);
                        break;
                    }                 
                    if (!iss.fail()) {
                        switch(type) {
                        case 'b': 
                            {
                                if ( (addr + count - 1) >= PCIinfo->BAR[bar_num].size) {
                                    //adjust the count to the maximum possible value
                                    count = PCIinfo->BAR[bar_num].size - addr;
                                    printf("Exceed range of BAR %d. Count adjusted to %zu.\n", bar_num, count);
                                }
                                std::vector<uint8_t> buf(count);
                                printf("Reading %zu bytes from address 0x%lx\n", count, addr);
                                printf("Read Data (8-bit):\n");
                                if (count == 1) {
                                    buf[0] = pDrvr->read8(bar_num, addr);
                                } 
                                else if (count > 1){
                                    pDrvr->readBlock8(bar_num, addr, buf, count);
                                }
                                formatBlockOfBytes(results, addr, count, buf);
                                break;
                            }
                        case 'w': 
                            {
                                /* Round down address to nearest 16-bit (2-byte) alignment
                                to ease display formatting */
                                addr = addr & ~(sizeof(uint16_t) - 1);
                                if ( (addr + (count*sizeof(uint16_t)) - 1) >= PCIinfo->BAR[bar_num].size) {
                                    //adjust the count to the maximum possible value
                                    count = (PCIinfo->BAR[bar_num].size - addr) / sizeof(uint16_t);
                                    printf("Exceed range of BAR %d. Count adjusted to %zu.\n", bar_num, count);
                                }
                                std::vector<uint16_t> buf(count);
                                printf("Reading %zu words from address 0x%lx\n", count, addr);
                                printf("Read Data (16-bit):\n");
                                if (count == 1) {
                                    buf[0] = pDrvr->read16(bar_num, addr);
                                } 
                                else if (count > 1){
                                    pDrvr->readBlock16(bar_num, addr, buf, count);
                                }
                                formatBlockOfWords(results, addr, count, buf);
                                break;
                            }
                        case 'd': 
                            {
                                /* Round down address to nearest 32-bit (4-byte) alignment
                                to ease display formatting */
                                addr = addr & ~(sizeof(uint32_t) - 1);
                                if ( (addr + (count*sizeof(uint32_t)) - 1) >= PCIinfo->BAR[bar_num].size) {
                                    //adjust the count to the maximum possible value
                                    count = (PCIinfo->BAR[bar_num].size - addr) / sizeof(uint32_t);
                                    printf("Exceed range of BAR %d. Count adjusted to %zu.\n", bar_num, count);
                                }
                                std::vector<uint32_t> buf(count);
                                printf("Reading %zu dwords from address 0x%lx\n", count, addr);
                                printf("Read Data (32-bit):\n");
                                if (count == 1) {
                                    buf[0] = pDrvr->read32(bar_num, addr);
                                } 
                                else if (count > 1){
                                    pDrvr->readBlock32(bar_num, addr, buf, count);
                                }
                                formatBlockOfDWords(results, addr, count, buf);
                                break;
                            }
                        case 'q': 
                            {
                                if (deviceMode != TLP) {
                                    printf("64-bit read operation not supported.\n");
                                    break;
                                }
                                /* Round down address to nearest 64-bit (8-byte) alignment
                                to ease display formatting */
                                addr = addr & ~(sizeof(uint64_t) - 1);
                                if ( (addr + (count*sizeof(uint64_t)) - 1) >= PCIinfo->BAR[bar_num].size) {
                                    //adjust the count to the maximum possible value
                                    count = (PCIinfo->BAR[bar_num].size - addr) / sizeof(uint64_t);
                                    printf("Exceed range of BAR %d. Count adjusted to %zu.\n", bar_num, count);
                                }
                                std::vector<uint64_t> buf(count);
                                printf("Reading %zu qwords from address 0x%lx\n", count, addr);
                                printf("Read Data (64-bit):\n");
                                if (count == 1) {
                                    buf[0] = pDrvr->read64(bar_num, addr);
                                } 
                                else if (count > 1){
                                    pDrvr->readBlock64(bar_num, addr, buf, count);
                                }
                                formatBlockOfQWords(results, addr, count, buf);
                                break;
                            }
                        default:
                            printf("Unknown read type: %c\n", type);
                            break;                            
                        }
                    }
                    break;
                }
                case 'w': // Write Operation
                {
                    std::vector<uint64_t> data_vals; // Use uint64_t to hold any size data during parsing
                    uint64_t val;
                    uint64_t addr = 0; // Default address
                    if (!(iss >> std::hex >> addr)) {
                        printf("Failed to read address. Please provide a valid address.\n");
                        break;
                    }
                    while (iss >> std::hex >> val) {
                        data_vals.push_back(val);
                    }         
                    if (!data_vals.empty()) {
                        switch (type) {
                            case 'b': 
                            {
                                std::vector<uint8_t> buf(data_vals.size());
                                if (data_vals.size() == 1) {
                                    buf[0] = static_cast<uint8_t>(data_vals[0]);
                                    pDrvr->write8(bar_num, addr, buf[0]);
                                }
                                else if (data_vals.size() > 1) {
                                    for (size_t i = 0; i < data_vals.size(); ++i) {
                                        buf[i] = static_cast<uint8_t>(data_vals[i]);
                                    }
                                    pDrvr->writeBlock8(bar_num, addr, buf, data_vals.size());
                                }
                                break;
                            }
                            case 'w': 
                            {
                                std::vector<uint16_t> buf(data_vals.size());
                                if (data_vals.size() == 1) {
                                    buf[0] = static_cast<uint16_t>(data_vals[0]);
                                    pDrvr->write16(bar_num, addr, buf[0]);
                                }
                                else if (data_vals.size() > 1) {
                                    for (size_t i = 0; i < data_vals.size(); ++i) {
                                        buf[i] = static_cast<uint16_t>(data_vals[i]);
                                    }
                                    pDrvr->writeBlock16(bar_num, addr, buf, data_vals.size());
                                }
                                break;
                            }
                            case 'd': 
                            {
                                std::vector<uint32_t> buf(data_vals.size());
                                if (data_vals.size() == 1) {
                                    buf[0] = static_cast<uint32_t>(data_vals[0]);
                                    pDrvr->write32(bar_num, addr, buf[0]);
                                }
                                else if (data_vals.size() > 1) {
                                    for (size_t i = 0; i < data_vals.size(); ++i) {
                                        buf[i] = static_cast<uint32_t>(data_vals[i]);
                                    }
                                    pDrvr->writeBlock32(bar_num, addr, buf, data_vals.size());
                                }
                                break;
                            }
                            case 'q': 
                            {
                                if (deviceMode != TLP) {
                                    printf("64-bit write operation not supported.\n");
                                    break;
                                }

                                std::vector<uint64_t> buf(data_vals.size());
                                if (data_vals.size() == 1) {
                                    buf[0] = static_cast<uint64_t>(data_vals[0]);
                                    pDrvr->write64(bar_num, addr, buf[0]);
                                }
                                else if (data_vals.size() > 1) {
                                    for (size_t i = 0; i < data_vals.size(); ++i) {
                                        buf[i] = static_cast<uint64_t>(data_vals[i]);
                                    }
                                    pDrvr->writeBlock64(bar_num, addr, buf, data_vals.size());
                                }
                                break;
                            }
                            default:
                                printf("Unknown write type: %c\n", type);
                                break;
                        }
                    } 
                    else {
                        printf("Invalid write command format. Usage: w[b|s|l|d] <addr-in hex> <data_1>...<data_n>\n");
                    }   
                    break;
                }   
                case 'v':
                {
                    size_t size = 1024; // Default size of 1024 bytes
                    int minSize = 1;
                    int maxSize = 4096;
                    if (!(iss >> std::dec >> size)) {
                        printf("Failed to read size. Using default value: %zu\n", size);
                    }
                    if ( (bar_num == 0) && (deviceMode == BRIDGE_MSI || deviceMode == BRIDGE_MSIX))
                    {
                        printf("Memory validation is not supported for BAR 0 in bridge mode.\n");
                        break;
                    }

                    if (size > maxSize) {
                        printf("Set to maximum size of %d bytes.\n", maxSize);
                        size = maxSize;
                    }
                    if (!iss.fail()) {
                        switch(type) {
                            case 'b':
                                minSize = 1;
                                break;
                            case 'w':
                                minSize = 2;
                                break;
                            case 'd':
                                minSize = 4;
                                break;  
                            case 'q':
                                minSize = 8;
                                break;
                            default:
                                printf("Unknown validation type: %c\n", type);
                                break;
                        }
                        
                        if (size < minSize) {
                            size = minSize;
                            printf("Set to minimum size of %d bytes.\n", minSize);
                        }

                        if (size % minSize != 0) {
                            size = (size/minSize) * minSize;
                            printf("Size not divisible by %d. Rounded down to %zu bytes.\n", minSize, size);
                        }

                        // Allocate buffer for read data
                        std::vector<uint64_t> readBuf;
                        std::string results;
                        
                        switch(type) {
                            case 'b': 
                                printf("Validating %zu bytes of 8-bit memory region in BAR %d...\n", size, bar_num);
                                if (validate_memory(bar_num, size, 1, &readBuf)) {  // Check status - only display if successful
                                    std::vector<uint8_t> data(readBuf.size());
                                    for (size_t i = 0; i < readBuf.size(); i++) {
                                        data[i] = static_cast<uint8_t>(readBuf[i] & 0xFF);
                                    }
                                    printf("Validated Data (8-bit):\n");
                                    formatBlockOfBytes(results, 0, readBuf.size(), data);
                                }
                                break;
                            case 'w': 
                                printf("Validating %zu bytes of 16-bit memory region in BAR %d...\n", size, bar_num);
                                if (validate_memory(bar_num, size, 2, &readBuf)) {  // Check status - only display if successful
                                    std::vector<uint16_t> data(readBuf.size());
                                    for (size_t i = 0; i < readBuf.size(); i++) {
                                        data[i] = static_cast<uint16_t>(readBuf[i] & 0xFFFF);
                                    }
                                    printf("Validated Data (16-bit):\n");
                                    formatBlockOfWords(results, 0, readBuf.size(), data);
                                }
                                break;
                            case 'd': 
                                printf("Validating %zu bytes of 32-bit memory region in BAR %d...\n", size, bar_num);
                                if (validate_memory(bar_num, size, 4, &readBuf)) {  // Check status - only display if successful
                                    std::vector<uint32_t> data(readBuf.size());
                                    for (size_t i = 0; i < readBuf.size(); i++) {
                                        data[i] = static_cast<uint32_t>(readBuf[i] & 0xFFFFFFFF);
                                    }
                                    printf("Validated Data (32-bit):\n");
                                    formatBlockOfDWords(results, 0, readBuf.size(), data);
                                }
                                break;
                            case 'q': 
                                if (deviceMode != TLP) {
                                    printf("64-bit validation not supported.\n");
                                    break;
                                }
                                printf("Validating %zu bytes of 64-bit memory region in BAR %d...\n", size, bar_num);
                                if (validate_memory(bar_num, size, 8, &readBuf)) {  // Check status - only display if successful
                                    printf("Validated Data (64-bit):\n");
                                    formatBlockOfQWords(results, 0, readBuf.size(), readBuf);
                                }
                                break;
                            default:
                                printf("Unknown validation type: %c\n", type);
                                break;                            
                        }
                    }

                }
                break;
                default:
                    printf("Unknown command: %s\n", cmd_str.c_str());
                    showHelp(deviceMode);
                    continue; // Skip to the next iteration to avoid processing further 
            }
        }
    }
}   

/**
 * @brief Entry point for the PCIe application.
 *
 * This function initializes the PCIe interface, retrieves PCIe BAR information, 
 * and processes command-line arguments to perform various operations. It supports 
 * displaying PCI capabilities, running a debug menu, reading from or writing to 
 * BARs, and other PCIe-related tasks. The function handles different argument 
 * configurations to execute specific commands or display relevant information.
 *
 * @param argc The number of command-line arguments.
 * @param argv The array of command-line arguments.
 * @return Returns 0 on successful execution.
 */
int main(int argc, char *argv[])
{
    // BAR/Register access parameters
    uint8_t bar_num = 0;
    uint8_t reg_size = 4;
    uint32_t numBars = 1;
    uint32_t offset = 0;
    uint64_t data64 = 0;           // Only needed for 64-bit operations
   
    // General
    std::string command;
    deviceMode_t deviceMode = TLP; //default

    struct PCIResourceInfo PCIinfo;
    
    try {
        pDrvr = new PCIE_IF(PCIE_DRIVER_NAME);
    }
    catch(std::exception &e) {
        ERRORSTR(e.what());
        exit(-1);
    }
    store_pci_cap();
    pDrvr->getPCIBarInfo(&PCIinfo);
    numBars = PCIinfo.numBARs;
    
    deviceMode = getDeviceMode();
        
    if (argc < 2) {
        print_pci_cap(false);
        showBars(deviceMode);
        runMenu(&PCIinfo, deviceMode);
    }
    else if (argc == 2) {
        command = argv[1];
        if (command == "cap") {
            printf("Printing PCI Capabilities in Detailed Mode\n");
            print_pci_cap(true);
        }
    }
    else if (argc == 5) {
        command  = argv[1];
        if (command == "rr") {
            bar_num = std::strtol(argv[2], nullptr, 0);
            offset = std::strtol(argv[3], nullptr, 0);
            reg_size = std::strtol(argv[4], nullptr, 0);
            
            if (reg_size == 8 && deviceMode != TLP) {
                printf("64-bit read not supported.\n");
                return 0;
            }
            if (bar_num >= static_cast<int>(numBars)) {
                printf("Invalid BAR number: %d. It must be less than %u.\n", bar_num, numBars);
                return 0;
            }
            read_bridge(bar_num, offset, reg_size);
        }
    }
    else if (argc == 6) {
        command = argv[1];
        if (command == "wr") {
            bar_num = std::strtol(argv[2], nullptr, 0);
            offset = std::strtol(argv[3], nullptr, 0);
            reg_size = std::strtol(argv[4], nullptr, 0);
            data64 = std::strtoull(argv[5], nullptr, 0);

            if (reg_size == 8 && deviceMode != TLP) {
                printf("64-bit write not supported.\n");
                return 0;
            }
            if (bar_num >= static_cast<int>(numBars)) {
                printf("Invalid BAR number: %d. It must be less than %u.\n", bar_num, numBars);
                return 0;
            }
            write_bridge(bar_num, offset, reg_size, data64);
        }
    }
    return 0;   
}
