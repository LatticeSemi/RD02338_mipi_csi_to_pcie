#!/bin/bash
cd ..
sudo insmod drv_src/lscpcie_dma.ko

