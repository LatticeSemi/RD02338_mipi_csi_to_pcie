// SPDX-License-Identifier: MIT
/*
 * ==================================================================
 *
 * >>>>>>>>>>>>>>>>>>>>> COPYRIGHT NOTICE <<<<<<<<<<<<<<<<<<<<<<<<<
 * ------------------------------------------------------------------
 * Copyright (c) 2026 by Lattice Semiconductor Corporation
 * ALL RIGHTS RESERVED
 * ------------------------------------------------------------------
 *
 * DISCLAIMER:
 *
 * LATTICE MAKES NO WARRANTIES ON THIS FILE OR ITS CONTENTS,
 * WHETHER EXPRESSED, IMPLIED, STATUTORY,
 * OR IN ANY PROVISION OF THE LATTICE PROPEL LICENSE AGREEMENT OR
 * COMMUNICATION WITH LICENSEE,
 * AND LATTICE SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
 * MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
 * LATTICE DOES NOT WARRANT THAT THE FUNCTIONS CONTAINED HEREIN WILL MEET
 * LICENSEE 'S REQUIREMENTS, OR THAT LICENSEE' S OPERATION OF ANY DEVICE,
 * SOFTWARE OR SYSTEM USING THIS FILE OR ITS CONTENTS WILL BE
 * UNINTERRUPTED OR ERROR FREE,
 * OR THAT DEFECTS HEREIN WILL BE CORRECTED.
 * LICENSEE ASSUMES RESPONSIBILITY FOR SELECTION OF MATERIALS TO ACHIEVE
 * ITS INTENDED RESULTS, AND FOR THE PROPER INSTALLATION, USE,
 * AND RESULTS OBTAINED THEREFROM.
 * LICENSEE ASSUMES THE ENTIRE RISK OF THE FILE AND ITS CONTENTS PROVING
 * DEFECTIVE OR FAILING TO PERFORM PROPERLY AND IN SUCH EVENT,
 * LICENSEE SHALL ASSUME THE ENTIRE COST AND RISK OF ANY REPAIR, SERVICE,
 * CORRECTION,
 * OR ANY OTHER LIABILITIES OR DAMAGES CAUSED BY OR ASSOCIATED WITH THE
 * SOFTWARE.IN NO EVENT SHALL LATTICE BE LIABLE TO ANY PARTY FOR DIRECT,
 * INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES,
 * INCLUDING LOST PROFITS,
 * ARISING OUT OF THE USE OF THIS FILE OR ITS CONTENTS,
 * EVEN IF LATTICE HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * LATTICE 'S SOLE LIABILITY, AND LICENSEE' S SOLE REMEDY,
 * IS SET FORTH ABOVE.
 * LATTICE DOES NOT WARRANT OR REPRESENT THAT THIS FILE,
 * ITS CONTENTS OR USE THEREOF DOES NOT INFRINGE ON THIRD PARTIES'
 * INTELLECTUAL PROPERTY RIGHTS, INCLUDING ANY PATENT. IT IS THE USER' S
 * RESPONSIBILITY TO VERIFY THE USER SOFTWARE DESIGN FOR CONSISTENCY AND
 * FUNCTIONALITY THROUGH THE USE OF FORMAL SOFTWARE VALIDATION METHODS.
 * ------------------------------------------------------------------
 *
 * ==================================================================
 */
#include <linux/init.h>
#include <linux/module.h>
#include <linux/pci.h>
#include <linux/interrupt.h>
#include <linux/fs.h>
#include <linux/uaccess.h>   /* copy_to_user */
#include <linux/delay.h>     /* msleep */
#include <linux/completion.h>
#include <linux/jiffies.h>  /* jiffies, msecs_to_jiffies */
#include <linux/iopoll.h>   /* read_poll_timeout */
#include <linux/bitfield.h> /* FIELD_GET */
#include "lsc_pcie_regs.h"
#include "lsc_pcie_core.h"
#include "lsc_pcie_dma.h"
#include "lsc_pcie_cdev.h"
#include "../include/lsc_pcie.h"

/* pr_fmt: only affects pr_info / pr_err / etc. */
#ifdef pr_fmt
#undef pr_fmt
#define pr_fmt(fmt)	KBUILD_MODNAME " %s: " fmt, __func__
#endif

static const struct pci_device_id lsc_pcie_id_table[] = {
		{ PCI_DEVICE(0x1204, 0x9c25), },
		{ PCI_DEVICE(0x1204, 0x9c1d), },
		{}                     /* Terminating entry */
};

MODULE_DEVICE_TABLE(pci, lsc_pcie_id_table);

/* ================================================================
 * Generic BAR register I/O
 * ================================================================
 */

/**
 * lsc_pcie_read_reg8 - Read an 8-bit value from a BAR MMIO region.
 * @pBrd: Board context.
 * @bar_num: BAR index into @pBrd->ctrlBARaddr[].
 * @offset: Byte offset within that BAR mapping.
 *
 * Return: The value read from MMIO.
 */
u8 lsc_pcie_read_reg8(struct lsc_pcie *pBrd, u8 bar_num, u32 offset)
{
	return readb(pBrd->ctrlBARaddr[bar_num]  + offset);
}

/**
 * lsc_pcie_read_reg16 - Read a 16-bit value from a BAR MMIO region.
 * @pBrd: Board context.
 * @bar_num: BAR index into @pBrd->ctrlBARaddr[].
 * @offset: Byte offset within that BAR mapping.
 *
 * Return: The value read from MMIO.
 */
u16 lsc_pcie_read_reg16(struct lsc_pcie *pBrd, u8 bar_num, u32 offset)
{
	return readw(pBrd->ctrlBARaddr[bar_num]  + offset);
}

/**
 * lsc_pcie_read_reg32 - Read a 32-bit value from a BAR MMIO region.
 * @pBrd: Board context.
 * @bar_num: BAR index into @pBrd->ctrlBARaddr[].
 * @offset: Byte offset within that BAR mapping.
 *
 * Return: The value read from MMIO.
 */
u32 lsc_pcie_read_reg32(struct lsc_pcie *pBrd, u8 bar_num, u32 offset)
{
	return readl(pBrd->ctrlBARaddr[bar_num]  + offset);
}

/**
 * lsc_pcie_read_reg64 - Read a 64-bit value from a BAR MMIO region.
 * @pBrd: Board context.
 * @bar_num: BAR index into @pBrd->ctrlBARaddr[].
 * @offset: Byte offset within that BAR mapping.
 *
 * Return: The value read from MMIO.
 */
u64 lsc_pcie_read_reg64(struct lsc_pcie *pBrd, u8 bar_num, u32 offset)
{
	return readq(pBrd->ctrlBARaddr[bar_num]  + offset);
}

/**
 * lsc_pcie_write_reg8 - Write an 8-bit value to a BAR MMIO region.
 * @pBrd: Board context.
 * @bar_num: BAR index into @pBrd->ctrlBARaddr[].
 * @offset: Byte offset within that BAR mapping.
 * @val: Value to write.
 *
 * Return: void
 */
void lsc_pcie_write_reg8(struct lsc_pcie *pBrd, u8 bar_num, u32 offset, u8 val)
{
	writeb(val, pBrd->ctrlBARaddr[bar_num]  + offset);
	/*Make sure the writes go through before next operation*/
	wmb();
}

/**
 * lsc_pcie_write_reg16 - Write a 16-bit value to a BAR MMIO region.
 * @pBrd: Board context.
 * @bar_num: BAR index into @pBrd->ctrlBARaddr[].
 * @offset: Byte offset within that BAR mapping.
 * @val: Value to write.
 *
 * Return: void
 */
void lsc_pcie_write_reg16(struct lsc_pcie *pBrd, u8 bar_num, u32 offset, u16 val)
{
	writew(val, pBrd->ctrlBARaddr[bar_num]  + offset);
	/*Make sure the writes go through before next operation*/
	wmb();
}

/**
 * lsc_pcie_write_reg32 - Write a 32-bit value to a BAR MMIO region.
 * @pBrd: Board context.
 * @bar_num: BAR index into @pBrd->ctrlBARaddr[].
 * @offset: Byte offset within that BAR mapping.
 * @val: Value to write.
 *
 * Return: void
 */
void lsc_pcie_write_reg32(struct lsc_pcie *pBrd, u8 bar_num, u32 offset, u32 val)
{
	writel(val, pBrd->ctrlBARaddr[bar_num] + offset);
	/*Make sure the writes go through before next operation*/
	wmb();
}

/**
 * lsc_pcie_write_reg64 - Write a 64-bit value to a BAR MMIO region.
 * @pBrd: Board context.
 * @bar_num: BAR index into @pBrd->ctrlBARaddr[].
 * @offset: Byte offset within that BAR mapping.
 * @val: Value to write.
 *
 * Return: void
 */
void lsc_pcie_write_reg64(struct lsc_pcie *pBrd, u8 bar_num, u32 offset, u64 val)
{
	writeq(val, pBrd->ctrlBARaddr[bar_num] + offset);
	/*Make sure the writes go through before next operation*/
	wmb();
}

/* ================================================================
 * PCI configuration space access
 * ================================================================
 */

/**
 * lsc_pcie_read_config_byte - Read an 8-bit PCI configuration register at the specified offset.
 * @pBrd: Board context.
 * @offset: Config-space byte offset.
 * @val: Output pointer for the read value.
 *
 * Return: 0 on success, negative errno on failure.
 */
int lsc_pcie_read_config_byte(struct lsc_pcie *pBrd, u32 offset, u8 *val)
{
	int ret;

	ret = pci_read_config_byte(pBrd->pdev, offset, val);
	if (ret < 0)
		dev_err(&pBrd->pdev->dev,
			"Device Configuration Space Byte Read failed (ret=%d).\n", ret);

	return ret;
}

/**
 * lsc_pcie_write_config_byte - Write an 8-bit PCI configuration register at the specified offset.
 * @pBrd: Board context.
 * @offset: Config-space byte offset.
 * @val: Value to write.
 *
 * Return: 0 on success, negative errno on failure.
 */
int lsc_pcie_write_config_byte(struct lsc_pcie *pBrd, u32 offset, u8 val)
{
	int ret;

	ret = pci_write_config_byte(pBrd->pdev, offset, val);
	if (ret < 0)
		dev_err(&pBrd->pdev->dev,
			"Device Configuration Space Byte Write failed (ret=%d).\n", ret);

	return ret;
}

/**
 * lsc_pcie_read_config_word - Read a 16-bit PCI configuration register at the specified offset.
 * @pBrd: Board context.
 * @offset: Config-space byte offset.
 * @val: Output pointer for the read value.
 *
 * Return: 0 on success, negative errno on failure.
 */
int lsc_pcie_read_config_word(struct lsc_pcie *pBrd, u32 offset, u16 *val)
{
	int ret;

	ret = pci_read_config_word(pBrd->pdev, offset, val);
	if (ret < 0)
		dev_err(&pBrd->pdev->dev,
			"Device Configuration Space Word Read failed (ret=%d).\n", ret);

	return ret;
}

/**
 * lsc_pcie_write_config_word - Write a 16-bit PCI configuration register at the specified offset.
 * @pBrd: Board context.
 * @offset: Config-space byte offset.
 * @val: Value to write.
 *
 * Return: 0 on success, negative errno on failure.
 */
int lsc_pcie_write_config_word(struct lsc_pcie *pBrd, u32 offset, u16 val)
{
	int ret;

	ret = pci_write_config_word(pBrd->pdev, offset, val);
	if (ret < 0)
		dev_err(&pBrd->pdev->dev,
			"Device Configuration Space Word Write failed (ret=%d).\n", ret);

	return ret;
}

/**
 * lsc_pcie_read_config_dword - Read a 32-bit PCI configuration register at the specified offset.
 * @pBrd: Board context.
 * @offset: Config-space byte offset.
 * @val: Output pointer for the read value.
 *
 * Return: 0 on success, negative errno on failure.
 */
int lsc_pcie_read_config_dword(struct lsc_pcie *pBrd, u32 offset, u32 *val)
{
	int ret;

	ret = pci_read_config_dword(pBrd->pdev, offset, val);
	if (ret < 0)
		dev_err(&pBrd->pdev->dev,
			"Device Configuration Space Dword Read failed (ret=%d).\n", ret);

	return ret;
}

/**
 * lsc_pcie_write_config_dword - Write a 32-bit PCI configuration register at the specified offset.
 * @pBrd: Board context.
 * @offset: Config-space byte offset.
 * @val: Value to write.
 *
 * Return: 0 on success, negative errno on failure.
 */
int lsc_pcie_write_config_dword(struct lsc_pcie *pBrd, u32 offset, u32 val)
{
	int ret;

	ret = pci_write_config_dword(pBrd->pdev, offset, val);
	if (ret < 0)
		dev_err(&pBrd->pdev->dev,
			"Device Configuration Space Dword Write failed (ret=%d).\n", ret);

	return ret;
}

/* ================================================================
 * PCIe capability readback
 * ================================================================
 */

/**
 * read_pcie_caps - Query PCIe capability parameters using kernel APIs.
 * @pBrd: Board context.
 *
 * Populates MPS, MRRS, RCB, and negotiated link width/PCIe generation from
 * the kernel's cached PCIe capability registers.
 */
static void read_pcie_caps(struct lsc_pcie *pBrd)
{
	struct pci_dev *pdev = pBrd->pdev;
	u16 lnksta;

	pBrd->hw_info.max_payload_size = pcie_get_mps(pdev);
	pBrd->hw_info.max_read_req_size = pcie_get_readrq(pdev);

	pcie_capability_read_word(pdev, PCI_EXP_LNKCTL, &lnksta);
	pBrd->hw_info.rcb_size = (lnksta & PCI_EXP_LNKCTL_RCB) ? 128 : 64;

	pcie_capability_read_word(pdev, PCI_EXP_LNKSTA, &lnksta);
	pBrd->hw_info.link_width = FIELD_GET(PCI_EXP_LNKSTA_NLW, lnksta);
	pBrd->hw_info.pcie_gen = FIELD_GET(PCI_EXP_LNKSTA_CLS, lnksta);

	dev_info(&pdev->dev, "MaxPayloadSize = %uB\n", pBrd->hw_info.max_payload_size);
	dev_info(&pdev->dev, "MaxReadReqSize = %uB\n", pBrd->hw_info.max_read_req_size);
	dev_info(&pdev->dev, "RCBSize = %uB\n", pBrd->hw_info.rcb_size);
	dev_info(&pdev->dev, "LinkWidth = x%u\n", pBrd->hw_info.link_width);
	dev_info(&pdev->dev, "PCIeGen = Gen%u\n", pBrd->hw_info.pcie_gen);
}

/* ================================================================
 * BAR discovery and mapping
 * ================================================================
 */

/**
 * scan_bars - Read PCI BAR resources into Dev_BARs[].
 * @pBrd: Board context.
 * @pdev: PCI device.
 *
 * Fills pci_resource_*() data for every BAR index. num_bars is the count of
 * BARs with a non-empty resource (available to map). Memory vs I/O mapping
 * is handled in map_bars().
 */
static void scan_bars(struct lsc_pcie *pBrd, struct pci_dev *pdev)
{
	int i;
	struct PCI_Dev_BAR *p;

	pBrd->num_bars = 0;

	for (i = 0; i < NUM_BARS; i++) {
		p = &pBrd->Dev_BARs[i];

		p->bar = i;
		p->pci_start = pci_resource_start(pdev, i);
		p->pci_end = pci_resource_end(pdev, i);
		p->len = pci_resource_len(pdev, i);
		p->pci_flags = pci_resource_flags(pdev, i);
		p->pci_addr = (void *)(unsigned long)p->pci_start;
		p->kvm_addr = NULL;

		if (p->pci_start > 0 && p->pci_end > 0)
			pBrd->num_bars++;

		dev_info(&pdev->dev,
			 "BAR=%d start=%llx end=%llx len=0x%llx flags=0x%llx %s\n",
			 i, p->pci_start, p->pci_end, p->len, p->pci_flags,
			 (p->pci_flags & IORESOURCE_MEM) ? "mem" :
			 (p->pci_flags & IORESOURCE_IO) ? "io" : "none");
	}
}

/**
 * map_bars - Map BARs into kernel virtual address space.
 * @pBrd: Board context.
 * @pdev: PCI device.
 *
 * Maps every BAR with non-zero length via pci_iomap().  Skips zero-length
 * regions only.
 *
 * Return: 0 on success, -ENOMEM if pci_iomap() fails for any BAR.
 */
static int map_bars(struct lsc_pcie *pBrd, struct pci_dev *pdev)
{
	int i;
	struct PCI_Dev_BAR *p;

	for (i = 0; i < NUM_BARS; i++) {
		p = &pBrd->Dev_BARs[i];
		pBrd->ctrlBARaddr[i] = NULL;

		if (!p->len)
			continue;

		pBrd->ctrlBARaddr[i] = pci_iomap(pdev, i, p->len);
		if (!pBrd->ctrlBARaddr[i]) {
			dev_err(&pdev->dev,
				"pci_iomap failed for BAR %d\n", i);
			return -ENOMEM;
		}

		p->kvm_addr = pBrd->ctrlBARaddr[i];
		dev_info(&pdev->dev,
			 "Mapped BAR %d into kernel space (len=0x%llx)\n",
			 i, p->len);
	}

	return 0;
}

/**
 * unmap_bars - Unmap memory BARs previously mapped by map_bars().
 * @pBrd: Board context.
 * @pdev: PCI device.
 */
static void unmap_bars(struct lsc_pcie *pBrd, struct pci_dev *pdev)
{
	int i;

	for (i = 0; i < NUM_BARS; i++) {
		if (!pBrd->ctrlBARaddr[i])
			continue;

		pci_iounmap(pdev, pBrd->ctrlBARaddr[i]);
		pBrd->ctrlBARaddr[i] = NULL;
		pBrd->Dev_BARs[i].kvm_addr = NULL;
	}
}

/* ================================================================
 * BAR accessor for in-module consumers
 * ================================================================
 */

/**
 * lsc_pcie_get_bar_va - Return the kernel MMIO mapping for a BAR.
 * @pdev:    PCI device whose driver data points to struct lsc_pcie.
 * @bar:     BAR index (0..5).
 * @bar_len: Optional output for the BAR size in bytes (may be NULL).
 *
 * The returned pointer is valid as long as the device has not been removed.
 * The caller must not unmap it.
 *
 * Return: Kernel virtual MMIO pointer on success, NULL if the BAR is
 *         not mapped or arguments are invalid.
 */
void __iomem *lsc_pcie_get_bar_va(struct pci_dev *pdev, u8 bar,
				  resource_size_t *bar_len)
{
	struct lsc_pcie *pBrd;

	if (!pdev || bar >= NUM_BARS)
		return NULL;

	pBrd = pci_get_drvdata(pdev);
	if (!pBrd || !pBrd->ctrlBARaddr[bar] || !pBrd->Dev_BARs[bar].len)
		return NULL;

	if (bar_len)
		*bar_len = pBrd->Dev_BARs[bar].len;

	return (void __iomem *)pBrd->ctrlBARaddr[bar];
}

/* ================================================================
 * DMA mask configuration
 * ================================================================
 */

/**
 * set_dma_mask - Configure DMA addressing width for this PCI device.
 * @pdev: PCI device.
 *
 * Prefers 64-bit DMA when supported, and falls back to 32-bit where
 * applicable.
 *
 * Return: 0 on success, negative errno on failure.
 */
static int set_dma_mask(struct pci_dev *pdev)
{
	if (!pdev) {
		pr_err("Invalid pdev\n");
		return -EINVAL;
	}

	dev_info(&pdev->dev, "sizeof(dma_addr_t) == %ld\n", sizeof(dma_addr_t));
#if LINUX_VERSION_CODE < KERNEL_VERSION(5, 18, 0)
	/* Returns zero if card can perform DMA for the given address mask. */
	if (!pci_set_dma_mask(pdev, DMA_BIT_MASK(64)) &&
	    !pci_set_consistent_dma_mask(pdev, DMA_BIT_MASK(64))) {
		dev_info(&pdev->dev, "set DMA_BIT_MASK(64) ok\n");
	} else if (!pci_set_dma_mask(pdev, DMA_BIT_MASK(32)) &&
		   !pci_set_consistent_dma_mask(pdev, DMA_BIT_MASK(32))) {
		dev_info(&pdev->dev, "set DMA_BIT_MASK(32) ok\n");
	} else {
		dev_err(&pdev->dev, "DMA not supported on this platform!\n");
		return -EIO;
	}
#else
	if (!dma_set_mask_and_coherent(&pdev->dev, DMA_BIT_MASK(64))) {
		dev_info(&pdev->dev, "Set DMA_BIT_MASK(64) ok\n");
	} else if (!dma_set_mask_and_coherent(&pdev->dev, DMA_BIT_MASK(32))) {
		dev_info(&pdev->dev, "Set DMA_BIT_MASK(32) ok\n");
	} else {
		dev_err(&pdev->dev, "DMA not supported on this platform!\n");
		return -EIO;
	}
#endif
	return 0;
}

/* ================================================================
 * Legacy INTx interrupts
 * ================================================================
 */

/**
 * lsc_pcie_irq_handler - Legacy INTx interrupt handler (stub).
 * @irq:  Linux IRQ number.
 * @arg:  Board context (struct lsc_pcie *).
 *
 * Return: IRQ_HANDLED.
 */
static irqreturn_t lsc_pcie_irq_handler(int irq, void *arg)
{
	struct lsc_pcie *pBrd = (struct lsc_pcie *)arg;
	(void)pBrd;

	/*
	 * TODO: Add your interrupt handling logic here.
	 * Read your FPGA/IP interrupt status register, acknowledge/clear the
	 * interrupt source, then signal any waiting threads (e.g. wake_up(),
	 * complete(), or schedule a tasklet/workqueue for heavier processing).
	 * Return IRQ_NONE if this interrupt did not originate from your device.
	 */

	return IRQ_HANDLED;
}

/**
 * irq_legacy_setup - Register the legacy INTx handler.
 * @pBrd: Board context.
 *
 * Reads PCI_INTERRUPT_PIN to verify the device supports legacy interrupts,
 * then registers lsc_pcie_irq_handler as a shared IRQ handler.
 *
 * On success, sets pBrd->IRQ to the active IRQ line.
 * On failure, sets pBrd->IRQ to -1.  When no interrupt pin is assigned,
 * also sets pBrd->IRQ to -1 but returns 0.
 *
 * Return: 0 on success or when no legacy pin is assigned, negative errno
 *         if request_irq() fails.
 */
static int irq_legacy_setup(struct lsc_pcie *pBrd)
{
	struct pci_dev *pdev = pBrd->pdev;
	u8 int_pin = 0;
	int ret;

	pci_read_config_byte(pdev, PCI_INTERRUPT_PIN, &int_pin);
	if (int_pin == 0) {
		dev_info(&pdev->dev,
			 "No interrupt pin assigned, legacy INTx not available\n");
		pBrd->IRQ = -1;
		return 0;
	}

	ret = request_irq(pdev->irq, lsc_pcie_irq_handler, IRQF_SHARED,
			  "lsc_pcie_intx", pBrd);
	if (ret) {
		dev_err(&pdev->dev, "INTx request_irq %d failed: %d\n",
			pdev->irq, ret);
		pBrd->IRQ = -1;
		return ret;
	}

	pBrd->IRQ = pdev->irq;
	dev_info(&pdev->dev, "INTx IRQ=%d\n", pBrd->IRQ);
	return 0;
}

/* ================================================================
 * User interrupt MSI vector programming
 * ================================================================
 */

/**
 * lsc_set_user_msi_vector_reg - Write a single user-interrupt MSI vector.
 * @pBrd:     Board context.
 * @user_idx: User interrupt index (0..15).
 * @msi_vec:  MSI vector number to assign.
 *
 * Reads the appropriate USR_INT_VEC_Px register, clears the 8-bit
 * field for @user_idx, ORs in @msi_vec, and writes back.
 */
void lsc_set_user_msi_vector_reg(struct lsc_pcie *pBrd, int user_idx,
				 int msi_vec)
{
	u32 reg_offset;
	u32 reg_val;
	u32 new_val;
	int field;
	int shift;

	if (user_idx < 0 || user_idx >= LSC_PCIE_MSI_MAX_VEC) {
		dev_err(&pBrd->pdev->dev,
			"user interrupt index %d is out of range\n", user_idx);
		return;
	}

	reg_offset = USR_INT_VEC_P1_REG + (user_idx / 4) * sizeof(u32);
	field = user_idx % 4;
	shift = field * 8;

	reg_val = ctrl_read_reg32(pBrd, reg_offset);
	reg_val &= ~(USR_INT_VEC_MASK << shift);
	new_val = reg_val | ((msi_vec & USR_INT_VEC_MASK) << shift);
	ctrl_write_reg32(pBrd, reg_offset, new_val);
}

/**
 * lsc_program_user_msi_vector - Program all user-interrupt MSI vector mappings.
 * @pBrd: Board context (nr_dma_vecs and nr_user_vecs must be set).
 *
 * Maps each user interrupt index to its corresponding MSI vector
 * (nr_dma_vecs + i). Only applicable for MSI mode; MSI-X uses
 * per-vector addressing and does not need explicit vector programming.
 */
void lsc_program_user_msi_vector(struct lsc_pcie *pBrd)
{
	int i;

	if (!pBrd->msi)
		return;

	for (i = 0; i < pBrd->nr_user_vecs; i++)
		lsc_set_user_msi_vector_reg(pBrd, i,
					    pBrd->nr_dma_vecs + i);
}

/* ================================================================
 * MSI / MSI-X configuration
 * ================================================================
 */

/**
 * lsc_pcie_dma_vec_count - Number of DMA MSI/MSI-X vectors for a mode.
 * @mode: Device operating mode.
 *
 * Authoritative source for nr_dma_vecs.  Indices 0 .. count-1 are passed
 * to get_dma_irq_handler().
 *
 * Return: Number of DMA vectors required (0, 1, 2, or 3).
 */
static int lsc_pcie_dma_vec_count(deviceMode_t mode)
{
	switch (mode) {
	case TLP:
	case BRIDGE_MSI:
	case BRIDGE_MSIX:
		return 0;
	case DMA_AXI_S:
		return 1;   /* F2H only */
	case AXI_BRIDGE:
		return 3;   /* F2H + H2F + bridge error */
	default:
		return 2;   /* F2H + H2F */
	}
}

/**
 * lsc_pcie_user_vec_count - Number of user MSI/MSI-X vectors for a mode.
 * @mode: Device operating mode.
 *
 * TLP and AXI_BRIDGE designs expose no user interrupt vectors.
 *
 * Return: 0 or LSC_USER_VEC_COUNT_DEFAULT.
 */
static int lsc_pcie_user_vec_count(deviceMode_t mode)
{
	/* TLP and AXI_BRIDGE example designs do not expose user interrupt. */
	if (mode == TLP || mode == AXI_BRIDGE)
		return 0;

	return LSC_USER_VEC_COUNT_DEFAULT;
}

/**
 * get_dma_irq_handler - Return the handler and name for a DMA vector index.
 * @vec_idx: MSI/MSI-X message index (enum lsc_msi_vec_idx).
 * @name:    Output /proc/interrupts label; set only when handler is returned.
 *
 * Return: Handler function pointer, or NULL if @vec_idx is unknown.
 */
static irq_handler_t get_dma_irq_handler(int vec_idx, const char **name)
{
	switch (vec_idx) {
	case F2H_MSI_VEC:
		*name = "lsc_pcie_dma_f2h";
		return dma_f2h_irq_handler;
	case H2F_MSI_VEC:
		*name = "lsc_pcie_dma_h2f";
		return dma_h2f_irq_handler;
	case AXI_BRIDGE_ERR_MSI_VEC:
		*name = "lsc_pcie_axi_bridge_err";
		return axi_bridge_err_irq_handler;
	default:
		return NULL;
	}
}

/**
 * enable_msi_msix - Detect capability and allocate MSI-X or MSI vectors.
 * @pBrd:     Board context (nr_dma_vecs and nr_user_vecs must be set).
 * @irq_mode: Output — set to LSC_MSIX_ENABLED, LSC_MSI_ENABLED,
 *            or LSC_MSI_MSIX_NONE.
 *
 * Computes total_requested_vecs from nr_dma_vecs + nr_user_vecs. Checks for
 * MSI-X capability first, then MSI, validates the total against the per-type
 * limit (64 for MSI-X, 16 for MSI), and allocates vectors.
 *
 * Return: 0 on success (including zero vectors needed or no MSI/MSI-X
 *         capability — caller may fall back to legacy INTx),
 *         negative errno on allocation failure.
 */
static int enable_msi_msix(struct lsc_pcie *pBrd,
			   enum lsc_pcie_irq_mode *irq_mode)
{
	struct pci_dev *pdev = pBrd->pdev;
	const char *type_str;
	int flags, vec_cnt, vec_max;
	int total_requested_vecs = pBrd->nr_dma_vecs +
				   pBrd->nr_user_vecs;

	*irq_mode = LSC_MSI_MSIX_NONE;

	dev_info(&pdev->dev,
		 "IRQ plan: dma_vec=%d user_vec=%d total=%d\n",
		 pBrd->nr_dma_vecs, pBrd->nr_user_vecs,
		 total_requested_vecs);

	if (total_requested_vecs == 0) {
		pBrd->num_irqs = 0;
		return 0;
	}

	if (pci_find_capability(pdev, PCI_CAP_ID_MSIX)) {
		dev_info(&pdev->dev, "MSI-X capability detected\n");
		type_str = "MSI-X";
		flags = PCI_IRQ_MSIX;
		vec_max = LSC_PCIE_MSIX_MAX_VEC;
	} else if (pci_find_capability(pdev, PCI_CAP_ID_MSI)) {
		dev_info(&pdev->dev, "MSI capability detected\n");
		type_str = "MSI";
		flags = PCI_IRQ_MSI;
		vec_max = LSC_PCIE_MSI_MAX_VEC;
	} else {
		dev_info(&pdev->dev,
			 "No MSI-X or MSI capability, will try INTx\n");
		return 0;
	}

	if (total_requested_vecs > vec_max) {
		dev_err(&pdev->dev,
			"%s: total vectors %d exceeds max %d\n",
			type_str, total_requested_vecs, vec_max);
		return -EINVAL;
	}

	vec_cnt = pci_alloc_irq_vectors(pdev, total_requested_vecs,
					total_requested_vecs,
					flags);
	if (vec_cnt < 0) {
		dev_err(&pdev->dev,
			"Failed to allocate %d %s vector(s): %d\n",
			total_requested_vecs, type_str, vec_cnt);
		pBrd->num_irqs = 0;
		return vec_cnt;
	}

	dev_info(&pdev->dev, "%s: %d vector(s) allocated\n",
		 type_str, vec_cnt);

	pBrd->num_irqs = vec_cnt;
	*irq_mode = (flags == PCI_IRQ_MSIX) ? LSC_MSIX_ENABLED
					     : LSC_MSI_ENABLED;
	return 0;
}

/**
 * lsc_pcie_user_irq_default - Default user MSI/MSI-X interrupt handler.
 * @irq:  Linux IRQ number.
 * @arg:  Board context (struct lsc_pcie *).
 *
 * Return: IRQ_HANDLED.
 */
static irqreturn_t lsc_pcie_user_irq_default(int irq, void *arg)
{
	struct lsc_pcie *pBrd = arg;

	dev_info(&pBrd->pdev->dev, "user interrupt received irq %d\n", irq);
	return IRQ_HANDLED;
}

/**
 * irq_msi_msix_user_setup - Register handlers for user MSI/MSI-X vectors.
 * @pBrd:     Board context.
 * @irq_mode: LSC_MSIX_ENABLED or LSC_MSI_ENABLED.
 *
 * Registers lsc_pcie_user_irq_default for vectors nr_dma_vecs .. total-1.
 * Sets pBrd->msi or pBrd->msix after all handlers are registered so the
 * cleanup path in irq_teardown() always knows what to free.
 *
 * Return: 0 on success, negative errno on failure (frees only user vectors
 *         registered so far; caller owns vector cleanup).
 */
static int irq_msi_msix_user_setup(struct lsc_pcie *pBrd,
				   enum lsc_pcie_irq_mode irq_mode)
{
	const char *type_str = (irq_mode == LSC_MSIX_ENABLED) ?
			       "MSI-X" : "MSI";
	irq_handler_t handler;
	int base = pBrd->nr_dma_vecs;
	int nr_user_vecs = pBrd->nr_user_vecs;
	int i, j, ret;

	if (nr_user_vecs == 0)
		return 0;

	handler = lsc_pcie_user_irq_default;

	for (i = 0; i < nr_user_vecs; i++) {
		int idx = base + i;
		const char *name;

		name = devm_kasprintf(&pBrd->pdev->dev, GFP_KERNEL,
				      "lsc_pcie_user%d", i);
		if (!name) {
			ret = -ENOMEM;
			goto err_free_irqs;
		}

		pBrd->irq_vec[idx] = pci_irq_vector(pBrd->pdev, idx);

		ret = request_irq(pBrd->irq_vec[idx], handler, 0, name, pBrd);
		if (ret) {
			dev_err(&pBrd->pdev->dev,
				"%s: request_irq %d (%s) failed %d\n",
				type_str, pBrd->irq_vec[idx], name, ret);
			goto err_free_irqs;
		}
		dev_info(&pBrd->pdev->dev, "%s user irq %d %s (vec %d)\n",
			 type_str, pBrd->irq_vec[idx], name, idx);
	}

	if (irq_mode == LSC_MSIX_ENABLED)
		pBrd->msix = true;
	else
		pBrd->msi = true;

	return 0;

err_free_irqs:
	for (j = 0; j < i; j++)
		free_irq(pBrd->irq_vec[base + j], pBrd);
	return ret;
}

/**
 * irq_msi_msix_dma_setup - Register DMA MSI/MSI-X handlers.
 * @pBrd:     Board context (num_irqs set by enable_msi_msix).
 * @irq_mode: LSC_MSIX_ENABLED or LSC_MSI_ENABLED.
 *
 * Registers handlers for vectors 0 .. nr_dma_vecs-1 by looking up each
 * vector index in get_dma_irq_handler(). Returns 0 immediately if
 * nr_dma_vecs is 0 (no DMA handlers needed). Sets pBrd->msi or
 * pBrd->msix after all handlers are registered so the cleanup path in
 * irq_teardown() always knows what to free. On failure, frees
 * all registered handlers; caller owns vector cleanup.
 *
 * Return: 0 on success, negative errno on failure.
 */
static int irq_msi_msix_dma_setup(struct lsc_pcie *pBrd,
				  enum lsc_pcie_irq_mode irq_mode)
{
	const char *type_str = (irq_mode == LSC_MSIX_ENABLED) ?
			       "MSI-X" : "MSI";
	int i, j, ret;

	if (pBrd->nr_dma_vecs == 0)
		return 0;

	for (i = 0; i < pBrd->nr_dma_vecs; i++) {
		const char *name;
		irq_handler_t handler = get_dma_irq_handler(i, &name);

		if (!handler) {
			dev_err(&pBrd->pdev->dev,
				"no handler for DMA vector %d\n", i);
			ret = -EINVAL;
			goto err_free_irqs;
		}

		pBrd->irq_vec[i] = pci_irq_vector(pBrd->pdev, i);

		ret = request_irq(pBrd->irq_vec[i], handler, 0, name, pBrd);
		if (ret) {
			dev_err(&pBrd->pdev->dev,
				"%s: request_irq %d (%s) failed %d\n",
				type_str, pBrd->irq_vec[i], name, ret);
			goto err_free_irqs;
		}
		dev_info(&pBrd->pdev->dev, "%s DMA irq %d %s (vec %d)\n",
			 type_str, pBrd->irq_vec[i], name, i);
	}

	if (irq_mode == LSC_MSIX_ENABLED)
		pBrd->msix = true;
	else
		pBrd->msi = true;

	return 0;

err_free_irqs:
	for (j = 0; j < i; j++)
		free_irq(pBrd->irq_vec[j], pBrd);
	return ret;
}

/**
 * irq_setup - Register interrupt handlers based on the allocated mode.
 * @pBrd:     Board context (num_irqs set by enable_msi_msix).
 * @irq_mode: Result from enable_msi_msix().
 *
 * For MSI/MSI-X: registers DMA handlers via irq_msi_msix_dma_setup(), then
 * user handlers via irq_msi_msix_user_setup(), then programs FPGA MSI vector
 * routing via lsc_program_dma_msi_vector() and lsc_program_user_msi_vector().
 * Falls back to legacy INTx when @irq_mode is LSC_MSI_MSIX_NONE or DMA handler
 * registration fails.  User-handler registration failure is non-fatal.
 *
 * On DMA handler failure, frees allocated MSI/MSI-X vectors before INTx
 * fallback.
 *
 * Return: 0 if an interrupt mode was established, negative errno otherwise.
 */
static int irq_setup(struct lsc_pcie *pBrd, enum lsc_pcie_irq_mode irq_mode)
{
	struct pci_dev *pdev = pBrd->pdev;
	const char *type_str;
	int ret;

	if (irq_mode != LSC_MSIX_ENABLED && irq_mode != LSC_MSI_ENABLED)
		goto legacy;

	type_str = (irq_mode == LSC_MSIX_ENABLED) ? "MSI-X" : "MSI";

	ret = irq_msi_msix_dma_setup(pBrd, irq_mode);
	if (ret) {
		dev_warn(&pdev->dev,
			 "%s DMA handler setup failed (%d), trying INTx\n",
			 type_str, ret);
		goto err_free_vectors;
	}

	ret = irq_msi_msix_user_setup(pBrd, irq_mode);
	if (ret) {
		dev_warn(&pdev->dev,
			 "%s user handler setup failed (%d), continuing without user IRQs\n",
			 type_str, ret);
		pBrd->nr_user_vecs = 0;
	}

	lsc_program_dma_msi_vector(pBrd);
	lsc_program_user_msi_vector(pBrd);

	return 0;

err_free_vectors:
	pci_free_irq_vectors(pdev);
	pBrd->num_irqs = 0;

legacy:
	return irq_legacy_setup(pBrd);
}

/**
 * irq_teardown - Free MSI/MSI-X or INTx resources for @pBrd.
 * @pBrd: Board context (pdev must be set if MSI/MSI-X vectors were allocated).
 *
 * Shared by lsc_pcie_device_close() and the lsc_pcie_device_open()
 * error path after init_board() fails.
 */
static void irq_teardown(struct lsc_pcie *pBrd)
{
	int i;

	if (!pBrd)
		return;

	if (pBrd->msi || pBrd->msix) {
		/* Free user IRQs (vectors nr_dma_vecs .. nr_dma_vecs+nr_user_vecs-1) */
		for (i = 0; i < pBrd->nr_user_vecs; i++)
			free_irq(pBrd->irq_vec[pBrd->nr_dma_vecs + i],
				 pBrd);

		/* Free DMA IRQs (vectors 0 .. nr_dma_vecs-1) */
		for (i = 0; i < pBrd->nr_dma_vecs; i++)
			free_irq(pBrd->irq_vec[i], pBrd);

		pci_free_irq_vectors(pBrd->pdev);
		pBrd->msi = false;
		pBrd->msix = false;
		pBrd->num_irqs = 0;
	} else if (pBrd->IRQ != -1) {
		free_irq(pBrd->IRQ, pBrd);
		pBrd->IRQ = -1;
	}
}

/* ================================================================
 * Device instance allocation
 * ================================================================
 */

/**
 * lsc_pcie_alloc - Allocate and initialize an lsc_pcie instance.
 * @pdev: PCI device to associate with the board.
 *
 * Allocates a zeroed lsc_pcie, sets safe defaults for all fields,
 * and initializes per-engine locks, back-pointers, and wait queues.
 *
 * Return: Pointer to the new instance on success, ERR_PTR on failure.
 */
static struct lsc_pcie *lsc_pcie_alloc(struct pci_dev *pdev)
{
	struct lsc_pcie *pBrd;
	int i, ch;

	pBrd = kzalloc(sizeof(*pBrd), GFP_KERNEL);
	if (!pBrd)
		return ERR_PTR(-ENOMEM);

	pBrd->pdev = pdev;
	pBrd->ID = pdev->device;
	pBrd->IRQ = -1;

	init_waitqueue_head(&pBrd->dma.wq);

	for (i = 0; i < NUM_DMA_DIRECTIONS; i++) {
		for (ch = 0; ch < NUM_DMA_CHANNELS; ch++) {
			struct lsc_dma_engine *engine =
				__lsc_dma_engine_get(pBrd, i, ch);

			engine->pBrd = pBrd;
			engine->dir = i;
			engine->channel = ch;
			snprintf(engine->name, sizeof(engine->name),
				 "%s-%d",
				 i == DMA_DIR_H2F ? "H2F" : "F2H", ch);
			spin_lock_init(&engine->lock);
			spin_lock_init(&engine->irq_ops_lock);
		}
	}

	return pBrd;
}

/* ================================================================
 * Board initialization
 * ================================================================
 */

/**
 * get_device_mode - Identify the PCIe IP operating mode.
 * @pBrd:     Board context (pdev must be set).
 * @dev_mode: Output device mode.
 *
 * Must be called after map_bars().  When the device has MSI or MSI-X,
 * reads GEN_STS_REG from BAR0 to determine the IP mode.  Designs without
 * MSI/MSI-X are reported as TLP without reading BAR0.
 *
 * Return: 0 on success, negative errno on failure.
 */
static int get_device_mode(struct lsc_pcie *pBrd, deviceMode_t *dev_mode)
{
	u32 dma_sup;
	u32 mode, dma_type;
	bool has_msix, has_msi;

	has_msix = pci_find_capability(pBrd->pdev, PCI_CAP_ID_MSIX);
	has_msi = pci_find_capability(pBrd->pdev, PCI_CAP_ID_MSI);
	if (!has_msix && !has_msi) {
		*dev_mode = TLP;
		return 0;
	}

	if (!pBrd->ctrlBARaddr[BAR0]) {
		dev_err(&pBrd->pdev->dev, "BAR0 not mapped, cannot read GEN_STS_REG\n");
		return -ENODEV;
	}

	dma_sup  = readl(pBrd->ctrlBARaddr[BAR0] + GEN_STS_REG);
	mode     = FIELD_GET(GEN_STS_MODE, dma_sup);
	dma_type = FIELD_GET(GEN_STS_DMA_TYPE, dma_sup);

	if (mode == GEN_STS_MODE_HALF_BRIDGE) {
		*dev_mode = has_msix ? BRIDGE_MSIX : BRIDGE_MSI;
	} else if (mode == GEN_STS_MODE_DMA_F2H &&
		   dma_type == GEN_STS_DMA_TYPE_AXI_S) {
		*dev_mode = DMA_AXI_S;
	} else if (mode == GEN_STS_MODE_AXI_BRIDGE) {
		*dev_mode = AXI_BRIDGE;
	} else if (dma_type == GEN_STS_DMA_TYPE_AXI_MM) {
		*dev_mode = DMA;
	} else {
		*dev_mode = DMA;
	}

	return 0;
}

/**
 * setup_reg_bases - Assign control and DMA MMIO bases from mapped BARs.
 * @pBrd: Board context (@pBrd->dev_mode must be set).
 * @pdev: PCI device.
 *
 * ctrl_reg_base is always BAR0.  dma_reg_base is BAR1 for AXI_BRIDGE and
 * BAR0 for all other modes.
 *
 * Return: 0 on success, -ENODEV if AXI_BRIDGE requires BAR1 but it is
 *         not mapped.
 */
static int setup_reg_bases(struct lsc_pcie *pBrd, struct pci_dev *pdev)
{
	pBrd->dma.ctrl_reg_base = (void __iomem *)pBrd->ctrlBARaddr[BAR0];

	if (pBrd->dev_mode == AXI_BRIDGE) {
		if (!pBrd->ctrlBARaddr[BAR1]) {
			dev_err(&pdev->dev, "AXI_BRIDGE mode requires BAR1; BAR1 not mapped\n");
			return -ENODEV;
		}
		pBrd->dma.dma_reg_base = (void __iomem *)pBrd->ctrlBARaddr[BAR1];
	} else {
		pBrd->dma.dma_reg_base = (void __iomem *)pBrd->ctrlBARaddr[BAR0];
	}

	return 0;
}

/**
 * init_board - Bring up the PCIe board after the PCI device is enabled.
 * @pBrd: Board context allocated by lsc_pcie_alloc().
 * @pdev: PCI device whose regions have already been requested.
 *
 * Hardware-dependent initialization.  Steps must run in order:
 *
 * 1. scan_bars() / map_bars() — discover and map BAR MMIO.
 * 2. get_device_mode() — read BAR0 and set @pBrd->dev_mode.  Required before
 *    any step that branches on mode.
 * 3. setup_reg_bases() — depends on @pBrd->dev_mode (e.g. AXI_BRIDGE uses
 *    BAR1 for DMA registers; other modes use BAR0).
 * 4. lsc_pcie_dma_vec_count() / lsc_pcie_user_vec_count() — both depend on
 *    @pBrd->dev_mode; enable_msi_msix() and irq_setup() use those counts.
 *    irq_setup() also programs FPGA MSI vector routing when MSI is used.
 * 5. read_pcie_caps(), dma_set_max_seg_size(), and mode-specific DMA IRQ
 *    masking (DMA_AXI_S only).
 *
 * Return: 0 on success, negative errno on failure.
 */
static int init_board(struct lsc_pcie *pBrd, struct pci_dev *pdev)
{
	int ret;

	dev_info(&pdev->dev,
		 "VendorID=0x%04x DeviceID=0x%04x SubSystemVendorID=0x%04x SubSystemID=0x%04x\n",
		 pdev->vendor, pdev->device,
		 pdev->subsystem_vendor, pdev->subsystem_device);

	scan_bars(pBrd, pdev);
	ret = map_bars(pBrd, pdev);
	if (ret)
		return ret;

	/* Identify IP mode before setting up reg bases — reads BAR0 directly. */
	ret = get_device_mode(pBrd, &pBrd->dev_mode);
	if (ret)
		return ret;
	dev_info(&pdev->dev, "device mode = %d\n", pBrd->dev_mode);

	ret = setup_reg_bases(pBrd, pdev);
	if (ret)
		return ret;

	/* Derive vector counts and allocate MSI-X or MSI vectors. */
	{
		enum lsc_pcie_irq_mode irq_mode = LSC_MSI_MSIX_NONE;

		pBrd->nr_dma_vecs  = lsc_pcie_dma_vec_count(pBrd->dev_mode);
		pBrd->nr_user_vecs = lsc_pcie_user_vec_count(pBrd->dev_mode);

		ret = enable_msi_msix(pBrd, &irq_mode);
		if (ret < 0) {
			dev_err(&pdev->dev,
				"enable_msi_msix failed (%d)\n", ret);
			return ret;
		}

		/* Register handlers (MSI-X/MSI) or fall back to INTx. */
		ret = irq_setup(pBrd, irq_mode);
		if (ret) {
			dev_err(&pdev->dev,
				"irq_setup failed (%d)\n", ret);
			return ret;
		}
	}

	/* Cache PCIe link/capability info for reporting. */
	read_pcie_caps(pBrd);

	/* Limit scatter-gather segment size for DMA mapping. */
	dma_set_max_seg_size(&pBrd->pdev->dev, LSC_DMA_MAX_SEG_SIZE);

	if (pBrd->dev_mode == DMA_AXI_S)
		lsc_program_dma_irq_mask(pBrd, DMA_DIR_F2H, F2H_AXI_S_DMA_INT_MASK);

	dev_info(&pdev->dev, "Done board initialization!\n");
	return 0;
}

/* ================================================================
 * Device open / close — reusable by any kernel module
 * ================================================================
 */

/**
 * lsc_pcie_device_open - Initialize a Lattice PCIe DMA device.
 * @mod_name: Module name (used for pci_request_regions and logging).
 * @pdev:     PCI device from the caller's probe().
 *
 * Enables the PCI device, requests regions, sets up DMA mask, maps BARs,
 * detects device mode, configures MSI/MSI-X or INTx interrupts, and
 * initializes per-engine locks and wait queues in struct lsc_pcie.
 *
 * The caller is responsible for creating any character devices or other
 * front-end interfaces on top of the returned handle.
 *
 * Return: Pointer to an initialized struct lsc_pcie on success, ERR_PTR
 *         on failure.
 */
struct lsc_pcie *lsc_pcie_device_open(const char *mod_name,
				      struct pci_dev *pdev)
{
	struct lsc_pcie *pBrd;
	int err;

	dev_info(&pdev->dev, "%s: device open\n", mod_name);

	pBrd = lsc_pcie_alloc(pdev);
	if (IS_ERR(pBrd))
		return pBrd;

	err = pci_enable_device(pdev);
	if (err)
		goto err_free;

	err = pci_request_regions(pdev, mod_name);
	if (err)
		goto err_disable;

	pci_set_master(pdev);

	err = set_dma_mask(pdev);
	if (err)
		goto err_release_regions;

	err = init_board(pBrd, pdev);
	if (err) {
		dev_err(&pdev->dev, "error initializing board\n");
		goto err_board;
	}

	dev_info(&pdev->dev, "%s: device open success\n", mod_name);
	return pBrd;

err_board:
	irq_teardown(pBrd);
	unmap_bars(pBrd, pdev);
err_release_regions:
	pci_release_regions(pdev);
err_disable:
	pci_disable_device(pdev);
err_free:
	kfree(pBrd);
	return ERR_PTR(err);
}

/**
 * lsc_pcie_device_close - Tear down a Lattice PCIe DMA device.
 * @pdev: PCI device (same one passed to lsc_pcie_device_open).
 * @pBrd: Handle returned by lsc_pcie_device_open.
 *
 * Frees interrupts, unmaps BARs, releases PCI regions and disables the
 * device.  The caller must destroy any front-end interfaces (cdevs, etc.)
 * before calling this.
 */
void lsc_pcie_device_close(struct pci_dev *pdev, struct lsc_pcie *pBrd)
{
	if (!pBrd)
		return;

	dev_info(&pdev->dev, "device close\n");

	irq_teardown(pBrd);
	unmap_bars(pBrd, pdev);

	pci_release_regions(pdev);
	pci_disable_device(pdev);
	kfree(pBrd);
}

/* ================================================================
 * PCI probe / remove / PM / error recovery
 * ================================================================
 */

static int lsc_pcie_probe(struct pci_dev *pdev, const struct pci_device_id *ent)
{
	struct lsc_pcie *pBrd;
	int err;

	pBrd = lsc_pcie_device_open(DRV_MODULE_NAME, pdev);
	if (IS_ERR(pBrd))
		return PTR_ERR(pBrd);

	err = lsc_pcie_cdev_create(pBrd, pdev);
	if (err) {
		lsc_pcie_device_close(pdev, pBrd);
		return err;
	}

	pci_set_drvdata(pdev, pBrd);
	return 0;
}

static void lsc_pcie_remove(struct pci_dev *pdev)
{
	struct lsc_pcie *pBrd = pci_get_drvdata(pdev);

	if (!pBrd)
		return;

	dev_info(&pdev->dev, "pci remove for device: %s%d\n",
		 DRV_MODULE_NAME, MINOR(pBrd->chrdev.cdevno));

	lsc_pcie_cdev_destroy(pBrd);
	lsc_pcie_device_close(pdev, pBrd);
	pci_set_drvdata(pdev, NULL);
}

static int lsc_pcie_suspend(struct pci_dev *pdev, pm_message_t state)
{
	dev_info(&pdev->dev, "suspend\n");
	return 0;
}

static int lsc_pcie_resume(struct pci_dev *pdev)
{
	dev_info(&pdev->dev, "resume\n");
	return 0;
}

static void lsc_pcie_shutdown(struct pci_dev *pdev)
{
	dev_info(&pdev->dev, "shutdown\n");
}

static pci_ers_result_t lsc_pcie_error_detected(struct pci_dev *pdev, pci_channel_state_t state)
{
	switch (state) {
	case pci_channel_io_normal:
		return PCI_ERS_RESULT_CAN_RECOVER;

	case pci_channel_io_frozen:
		dev_warn(&pdev->dev, " dev 0x%p, frozen state error, reset controller\n", pdev);
		pci_disable_device(pdev);
		return PCI_ERS_RESULT_NEED_RESET;

	case pci_channel_io_perm_failure:
		dev_warn(&pdev->dev, "dev 0x%p, failure state error, request disconnect\n", pdev);
		return PCI_ERS_RESULT_DISCONNECT;
	}

	return PCI_ERS_RESULT_NEED_RESET;
}

static pci_ers_result_t lsc_pcie_slot_reset(struct pci_dev *pdev)
{
	dev_info(&pdev->dev, "0x%p restart after slot reset\n", pdev);
	if (pci_enable_device_mem(pdev)) {
		dev_err(&pdev->dev, " failed to reenable after slot reset\n");
		return PCI_ERS_RESULT_DISCONNECT;
	}
	pci_set_master(pdev);
	pci_restore_state(pdev);
	pci_save_state(pdev);

	return PCI_ERS_RESULT_RECOVERED;
}

static const struct pci_error_handlers lsc_pcie_err_handler = {
	.error_detected = lsc_pcie_error_detected,
	.slot_reset = lsc_pcie_slot_reset,
};

static struct pci_driver lsc_pcie_driver = {
	.name = DRV_MODULE_NAME,
	.id_table = lsc_pcie_id_table,
	.probe = lsc_pcie_probe,
	.remove = lsc_pcie_remove,
	.suspend = lsc_pcie_suspend,
	.resume = lsc_pcie_resume,
	.shutdown = lsc_pcie_shutdown,
	.err_handler = &lsc_pcie_err_handler,
};

/* ================================================================
 * Module init / exit
 * ================================================================
 */

static int __init lsc_pcie_init(void)
{
	int err;

	err = lsc_pcie_cdev_init();
	if (err)
		return err;

	err = pci_register_driver(&lsc_pcie_driver);
	if (err < 0) {
		pr_err("Error registering PCI driver: %d\n", err);
		lsc_pcie_cdev_cleanup();
		return err;
	}
	return 0;
}

module_init(lsc_pcie_init);

static void __exit lsc_pcie_exit(void)
{
	pci_unregister_driver(&lsc_pcie_driver);
	lsc_pcie_cdev_cleanup();
}

module_exit(lsc_pcie_exit);

MODULE_AUTHOR("Lattice Semiconductor");
MODULE_DESCRIPTION("LSC PCIe DMA Driver");
MODULE_VERSION(DRV_MODULE_VERSION);

/* License this so no annoying messages when loading module */
MODULE_LICENSE("Dual BSD/GPL");
