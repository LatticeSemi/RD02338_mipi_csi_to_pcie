// SPDX-License-Identifier: MIT
/*   ==================================================================
 
     >>>>>>>>>>>>>>>>>>>>>>> COPYRIGHT NOTICE <<<<<<<<<<<<<<<<<<<<<<<<<
     ------------------------------------------------------------------
     Copyright (c) 2025 by Lattice Semiconductor Corporation
     ALL RIGHTS RESERVED
     ------------------------------------------------------------------
 
     DISCLAIMER:
 
    LATTICE MAKES NO WARRANTIES ON THIS FILE OR ITS CONTENTS,
    WHETHER EXPRESSED, IMPLIED, STATUTORY,
    OR IN ANY PROVISION OF THE LATTICE PROPEL LICENSE AGREEMENT OR
    COMMUNICATION WITH LICENSEE,
    AND LATTICE SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
    MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
    LATTICE DOES NOT WARRANT THAT THE FUNCTIONS CONTAINED HEREIN WILL MEET
    LICENSEE 'S REQUIREMENTS, OR THAT LICENSEE' S OPERATION OF ANY DEVICE,
    SOFTWARE OR SYSTEM USING THIS FILE OR ITS CONTENTS WILL BE
    UNINTERRUPTED OR ERROR FREE,
    OR THAT DEFECTS HEREIN WILL BE CORRECTED.
    LICENSEE ASSUMES RESPONSIBILITY FOR SELECTION OF MATERIALS TO ACHIEVE
    ITS INTENDED RESULTS, AND FOR THE PROPER INSTALLATION, USE,
    AND RESULTS OBTAINED THEREFROM.
    LICENSEE ASSUMES THE ENTIRE RISK OF THE FILE AND ITS CONTENTS PROVING
    DEFECTIVE OR FAILING TO PERFORM PROPERLY AND IN SUCH EVENT,
    LICENSEE SHALL ASSUME THE ENTIRE COST AND RISK OF ANY REPAIR, SERVICE,
    CORRECTION,
    OR ANY OTHER LIABILITIES OR DAMAGES CAUSED BY OR ASSOCIATED WITH THE
    SOFTWARE.IN NO EVENT SHALL LATTICE BE LIABLE TO ANY PARTY FOR DIRECT,
    INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES,
    INCLUDING LOST PROFITS,
    ARISING OUT OF THE USE OF THIS FILE OR ITS CONTENTS,
    EVEN IF LATTICE HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
    LATTICE 'S SOLE LIABILITY, AND LICENSEE' S SOLE REMEDY,
    IS SET FORTH ABOVE.
    LATTICE DOES NOT WARRANT OR REPRESENT THAT THIS FILE,
    ITS CONTENTS OR USE THEREOF DOES NOT INFRINGE ON THIRD PARTIES'
    INTELLECTUAL PROPERTY RIGHTS, INCLUDING ANY PATENT. IT IS THE USER' S
    RESPONSIBILITY TO VERIFY THE USER SOFTWARE DESIGN FOR CONSISTENCY AND
    FUNCTIONALITY THROUGH THE USE OF FORMAL SOFTWARE VALIDATION METHODS.
     ------------------------------------------------------------------
 
     ================================================================== */
#ifndef CAP_CHECK_H
#define CAP_CHECK_H

#include <stdint.h>
#include <stdio.h>
#include <vector>

// External dependencies - you'll need to add proper includes based on your project
// Forward declaration of any driver class used
class PCIE_IF;
extern class PCIE_IF* pDrvr;
extern std::vector<uint32_t> pci_cap_ptrs;

#define PCI_PM_CAP_AUX_POWER_0                  0x000
#define PCI_PM_CAP_AUX_POWER_1                  0x040
#define PCI_PM_CAP_AUX_POWER_2                  0x080
#define PCI_PM_CAP_AUX_POWER_3                  0x0C0
#define PCI_PM_CAP_AUX_POWER_4                  0x100
#define PCI_PM_CAP_AUX_POWER_5                  0x140
#define PCI_PM_CAP_AUX_POWER_6                  0x180
#define PCI_PM_CAP_AUX_POWER_7                  0x1C0

#define PCI_PM_CTRL_STATE_D0                    0x0
#define PCI_PM_CTRL_STATE_D1                    0x1
#define PCI_PM_CTRL_STATE_D2                    0x2
#define PCI_PM_CTRL_STATE_D3hot                 0x3

#define PCI_MSI_FLAGS_EXT_MSG_DATA_CAP          0x200
#define PCI_MSI_FLAGS_EXT_MSG_DATA_EN           0x400

#define PCI_MSIX_TABLE_BIR_0                    0x0
#define PCI_MSIX_TABLE_BIR_1                    0x1
#define PCI_MSIX_TABLE_BIR_2                    0x2
#define PCI_MSIX_TABLE_BIR_3                    0x3
#define PCI_MSIX_TABLE_BIR_4                    0x4
#define PCI_MSIX_TABLE_BIR_5                    0x5

#define PCI_EXP_DEVCAP2_COMP_TMOUT_RANGE        0x7
#define PCI_EXP_DEVCAP_L0s_LATENCY_64n          0x00
#define PCI_EXP_DEVCAP_L0s_LATENCY_128n         0x40
#define PCI_EXP_DEVCAP_L0s_LATENCY_256n         0x80
#define PCI_EXP_DEVCAP_L0s_LATENCY_512n         0xC0
#define PCI_EXP_DEVCAP_L0s_LATENCY_1u           0x100
#define PCI_EXP_DEVCAP_L0s_LATENCY_2u           0x140
#define PCI_EXP_DEVCAP_L0s_LATENCY_4u           0x180
#define PCI_EXP_DEVCAP_L0s_LATENCY_NO_LIMIT     0x1C0

#define PCI_EXP_DEVCAP_L1_LATENCY_1u            0x000
#define PCI_EXP_DEVCAP_L1_LATENCY_2u            0x200
#define PCI_EXP_DEVCAP_L1_LATENCY_4u            0x400
#define PCI_EXP_DEVCAP_L1_LATENCY_8u            0x600
#define PCI_EXP_DEVCAP_L1_LATENCY_16u           0x800
#define PCI_EXP_DEVCAP_L1_LATENCY_32u           0xA00
#define PCI_EXP_DEVCAP_L1_LATENCY_64u           0xC00
#define PCI_EXP_DEVCAP_L1_LATENCY_NO_LIMIT      0xE00

#define PCI_EXP_LNKCAP_L0s_LATENCY_64n          0x0000
#define PCI_EXP_LNKCAP_L0s_LATENCY_128n         0x1000
#define PCI_EXP_LNKCAP_L0s_LATENCY_256n         0x2000
#define PCI_EXP_LNKCAP_L0s_LATENCY_512n         0x3000
#define PCI_EXP_LNKCAP_L0s_LATENCY_1u           0x4000
#define PCI_EXP_LNKCAP_L0s_LATENCY_2u           0x5000
#define PCI_EXP_LNKCAP_L0s_LATENCY_4u           0x6000
#define PCI_EXP_LNKCAP_L0s_LATENCY_NO_LIMIT     0x7000

#define PCI_EXP_LNKCAP_L1_LATENCY_1u            0x00000
#define PCI_EXP_LNKCAP_L1_LATENCY_2u            0x08000
#define PCI_EXP_LNKCAP_L1_LATENCY_4u            0x10000
#define PCI_EXP_LNKCAP_L1_LATENCY_8u            0x18000
#define PCI_EXP_LNKCAP_L1_LATENCY_16u           0x20000
#define PCI_EXP_LNKCAP_L1_LATENCY_32u           0x28000
#define PCI_EXP_LNKCAP_L1_LATENCY_64u           0x30000
#define PCI_EXP_LNKCAP_L1_LATENCY_NO_LIMIT      0x38000

#define PCI_EXP_LNK_CAP_ASPMOC                  0x400000

#define PCI_EXP_DEVCAP2_NROPRPRP                0x00000400
#define PCI_EXP_DEVCAP2_TPH                     0x00003000
#define  PCI_EXP_DEVCAP2_TPH_SUP                0x00001000
#define  PCI_EXP_DEVCAP2_TPH_RSVD               0x00002000
#define  PCI_EXP_DEVCAP2_TPH_TPHEXT             0x00003000
#define PCI_EXP_DEVCAP2_10B_TAG_COMP            0x00010000
#define PCI_EXP_DEVCAP2_10B_TAG_REQ             0x00020000
#define PCI_EXP_DEVCAP2_EXT_FMT_FIELD           0x00100000
#define PCI_EXP_DEVCAP2_MAX_EE_PREFIX	        0x00C00000
#define  PCI_EXP_DEVCAP2_MAX_1_EE_PREFIX	    0x00400000
#define  PCI_EXP_DEVCAP2_MAX_2_EE_PREFIX	    0x00800000
#define  PCI_EXP_DEVCAP2_MAX_3_EE_PREFIX	    0x00C00000
#define  PCI_EXP_DEVCAP2_MAX_4_EE_PREFIX	    0x00000000
#define PCI_EXP_DEVCAP2_EPRS           	        0x03000000
#define PCI_EXP_DEVCAP2_EPRIR           	    0x04000000
#define PCI_EXP_DEVCAP2_FRS          	        0x80000000

#define PCI_EXP_DEVCTL2_COMP_TIMEOUT_1          0x0
#define PCI_EXP_DEVCTL2_COMP_TIMEOUT_2          0x1
#define PCI_EXP_DEVCTL2_COMP_TIMEOUT_3          0x2
#define PCI_EXP_DEVCTL2_COMP_TIMEOUT_4          0x5
#define PCI_EXP_DEVCTL2_COMP_TIMEOUT_5          0x6
#define PCI_EXP_DEVCTL2_COMP_TIMEOUT_6          0x9
#define PCI_EXP_DEVCTL2_COMP_TIMEOUT_7          0xA
#define PCI_EXP_DEVCTL2_COMP_TIMEOUT_8          0xD
#define PCI_EXP_DEVCTL2_COMP_TIMEOUT_9          0xE
#define PCI_EXP_DEVCTL2_10B_TAG_REQ_EN          0x1000
#define PCI_EXP_DEVCTL2_EE_TLPP_BLOCKING        0x8000 

#define PCI_EXP_LNKCAP2_SUPP_LINK_SPEEDS        0x000000FE
#define PCI_EXP_LNKCAP2_RETIMER_PDS             0x00800000
#define PCI_EXP_LNKCAP2_2_RETIMER_PDS           0x01000000
#define PCI_EXP_LNKCAP2_DRS                     0x80000000

#define PCI_EXP_LNKCTL2_SEL_DEEMPHASIS          0x00000040
#define PCI_EXP_LNKCTL2_TRANS_MARGIN            0x00000380
#define PCI_EXP_LNKCTL2_ENT_MOD_COMP            0x00000400
#define PCI_EXP_LNKCTL2_COMP_SOS                0x00000800
#define PCI_EXP_LNKCTL2_COMP_PRESET_DEEMPHASIS  0x0000F000

#define PCI_EXP_LNKSTS2_CURR_DEEMPHASIS         0x00000001
#define PCI_EXP_LNKSTS2_EQ_8_COMPLETE           0x00000002
#define PCI_EXP_LNKSTS2_EQ_8_PHASE_1            0x00000004
#define PCI_EXP_LNKSTS2_EQ_8_PHASE_2            0x00000008
#define PCI_EXP_LNKSTS2_EQ_8_PHASE_3            0x00000010
#define PCI_EXP_LNKSTS2_LNK_EQ_REQ              0x00000020
#define PCI_EXP_LNKSTS2_RETIMER_PD              0x00000040
#define PCI_EXP_LNKSTS2_2_RETIMER_PD            0x00000080
#define PCI_EXP_LNKSTS2_CROSSLINK_RES           0x00000300
#define  PCI_EXP_LNKSTS2_CROSSLINK_NO_SUPP      0x00000000
#define  PCI_EXP_LNKSTS2_CROSSLINK_SUPP_UP      0x00000100
#define  PCI_EXP_LNKSTS2_CROSSLINK_SUPP_DOWN    0x00000200
#define  PCI_EXP_LNKSTS2_CROSSLINK_SUPP_NOTC    0x00000300
#define PCI_EXP_LNKSTS2_DS_CP                   0x00006000
#define  PCI_EXP_LNKSTS2_DS_CP_LD_PND           0x00000000
#define  PCI_EXP_LNKSTS2_DS_CP_LD_CNP           0x00001000
#define  PCI_EXP_LNKSTS2_DS_CP_LU_CP            0x00004000
#define  PCI_EXP_LNKSTS2_DS_CP_LU_CP_DRS        0x00005000
#define PCI_EXP_LNKSTS2_DRS_MSG_REC             0x00008000

// Compatibility definition for kernel 6.8+ where register bits definition missing
// According to Linux kernel pci_regs.h, this is bit 13 (0x2000) of Slot Control register
#ifndef PCI_EXP_SLTCTL_ASPL_DISABLE
#define PCI_EXP_SLTCTL_ASPL_DISABLE             0x2000
#endif
// According to PCI Express Base Specification, PME Requester ID is bits 15:0 of Root Status register
#ifndef PCI_EXP_RTSTA_PME_RQ_ID
#define PCI_EXP_RTSTA_PME_RQ_ID                 0x0000FFFF
#endif


// Function declarations
void pci_pm_flag_print(uint32_t pci_cap_ptr, bool detailed);
void pci_dev_cap_print(uint32_t pci_cap_ptr, bool detailed);
void pci_dev_ctl_print(uint32_t pci_cap_ptr, bool detailed);
void pci_dev_link_cap_print(uint32_t pci_cap_ptr, bool detailed);
void pci_dev_link_ctl_print(uint32_t pci_cap_ptr, bool detailed);
void pci_dev_link_sts_print(uint32_t pci_cap_ptr, bool detailed);
void pci_dev_slot_cap_print(uint32_t pci_cap_ptr, bool detailed);
void pci_dev_slot_ctl_print(uint32_t pci_cap_ptr, bool detailed);
void pci_dev_slot_sts_print(uint32_t pci_cap_ptr, bool detailed);
void pci_dev_root_ctl_print(uint32_t pci_cap_ptr, bool detailed);
void pci_dev_root_cap_print(uint32_t pci_cap_ptr, bool detailed);
void pci_dev_root_sts_print(uint32_t pci_cap_ptr, bool detailed);
void pci_dev_cap_2_print(uint32_t pci_cap_ptr, bool detailed);
void pci_dev_ctl_2_print(uint32_t pci_cap_ptr, bool detailed);
void pci_dev_link_cap_2_print(uint32_t pci_cap_ptr, bool detailed);
void pci_dev_link_ctl_2_print(uint32_t pci_cap_ptr, bool detailed);
void pci_dev_link_sts_2_print(uint32_t pci_cap_ptr, bool detailed);
void pci_msix_flag_print(uint32_t pci_cap_ptr, bool detailed);
void pci_msix_table_off_print(uint32_t pci_cap_ptr, bool detailed);
void pci_msix_pba_off_print(uint32_t pci_cap_ptr, bool detailed);
void print_pci_cap(bool detailed);
void store_pci_cap(void);

#endif // CAP_CHECK_H