#!/bin/bash
cd ..
sudo insmod drv_src/pcie_lattice.ko

