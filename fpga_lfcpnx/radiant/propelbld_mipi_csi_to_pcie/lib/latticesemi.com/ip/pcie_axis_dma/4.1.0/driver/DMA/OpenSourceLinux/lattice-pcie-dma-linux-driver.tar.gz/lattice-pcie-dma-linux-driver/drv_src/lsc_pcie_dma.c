// SPDX-License-Identifier: MIT
/*
 * Lattice Semiconductor PCIe DMA Driver - DMA Engine Library
 *
 * DMA buffer management, descriptor generation, transfer control, status
 * readback, throughput measurement, and IRQ dispatch.  All functions in
 * this file operate on a struct lsc_pcie handle and use pBrd->dma.*
 * register bases for MMIO.
 *
 * The DMA engine library is independent of PCI probe/remove lifecycle and
 * character device VFS code.  It is linked into lscpcie_dma.ko and used
 * in-module only
 * (no EXPORT_SYMBOL*); user-space and other processes use the char
 * device ioctl ABI in include/lsc_pcie.h.
 *
 * Copyright (c) 2026 by Lattice Semiconductor Corporation
 * ALL RIGHTS RESERVED
 */

#include <linux/pci.h>
#include <linux/scatterlist.h>
#include <linux/dma-mapping.h>
#include <linux/version.h>
#include <linux/delay.h>
#include <linux/completion.h>
#include <linux/jiffies.h>
#include <linux/wait.h>
#include <linux/iopoll.h>
#include <linux/bitfield.h>
#include "lsc_pcie_regs.h"
#include "lsc_pcie_core.h"
#include "lsc_pcie_dma.h"
#include "../include/lsc_pcie.h"

/*
 * Custom wait-event macro that holds a spinlock across the condition check
 * and sleep, dropping/reacquiring around schedule_timeout.
 */
#define __wait_event_lock_timeout(wq_head, condition, lock, flags, timeout, state) \
	___wait_event(wq_head, ___wait_cond_timeout(condition),             \
			  state, 0, timeout,                                    \
			  spin_unlock_irqrestore(&(lock), flags);                \
			  __ret = schedule_timeout(__ret);                      \
			  spin_lock_irqsave(&(lock), flags))

#define wait_event_lock_timeout(wq_head, condition, lock, flags, timeout)   \
({                                                                          \
	long __ret = timeout;                                                 \
	if (!___wait_cond_timeout(condition))                                 \
		__ret = __wait_event_lock_timeout(                            \
				wq_head, condition, lock, flags, timeout,         \
				TASK_UNINTERRUPTIBLE);                            \
	__ret;                                                                \
})

/* ================================================================
 * MSI vector programming (DMA / ctrl regs for interrupt routing)
 * ================================================================
 */

/**
 * lsc_program_dma_msi_vector - Program MSI vector routing registers.
 * @pBrd: Board context (nr_dma_vecs must be set by lsc_pcie_dma_vec_count).
 *
 * Programs F2H, H2F, and (for AXI_BRIDGE) error MSI vector indices
 * into the appropriate DMA or control registers so the hardware sends
 * interrupts on the correct vectors.  Uses nr_dma_vecs to decide how
 * many standard DMA vectors to program, keeping this function in sync
 * with lsc_pcie_dma_vec_count().
 *
 * AXI_BRIDGE uses a different register interface (user interrupt vector
 * registers + bridge error register) and is handled as a special case.
 *
 * Called from irq_setup() after MSI/MSI-X vectors and handlers are ready.
 */
void lsc_program_dma_msi_vector(struct lsc_pcie *pBrd)
{
	int nr_vecs = pBrd->nr_dma_vecs;

	if (nr_vecs == 0)
		return;

	/*
	 * AXI bridge ED: routes interrupts through user interrupt vector
	 * registers instead of DMA engine registers.
	 * user 0 interrupt mapped to F2H, user 1 interrupt mapped to H2F.
	 */
	if (pBrd->dev_mode == AXI_BRIDGE) {
		lsc_set_user_msi_vector_reg(pBrd, 0, F2H_MSI_VEC);
		lsc_set_user_msi_vector_reg(pBrd, 1, H2F_MSI_VEC);
		ctrl_write_reg32(pBrd, AXI_BRIDGE_MSI_VEC_REG,
				 AXI_BRIDGE_ERR_MSI_VEC);
		return;
	}

	/* DMA_AXI_S: F2H only (nr_vecs == 1) */
	if (pBrd->dev_mode == DMA_AXI_S) {
		dma_write_reg32(pBrd, F2H_INT_VEC_REG, F2H_MSI_VEC);
		return;
	}

	/* Standard DMA modes: program F2H, then H2F if nr_vecs >= 2 */
	dma_write_reg32(pBrd, F2H_INT_VEC_REG, F2H_MSI_VEC);

	if (nr_vecs >= 2)
		dma_write_reg32(pBrd, H2F_INT_VEC_REG, H2F_MSI_VEC);
}

/**
 * lsc_program_dma_irq_mask - Program a DMA engine interrupt mask register.
 * @pBrd: Board context (dma_reg_base must be set).
 * @dir:  DMA_DIR_H2F or DMA_DIR_F2H.
 * @mask: Value to write to the engine's DMA_INT_MASK register.
 *
 * Sets which DMA interrupt sources are masked in hardware.  A set bit
 * suppresses that interrupt source.
 */
void lsc_program_dma_irq_mask(struct lsc_pcie *pBrd, enum dma_direction dir,
			      u32 mask)
{
	u32 reg = (dir == DMA_DIR_H2F) ? H2F_DMA_INT_MASK_REG
					   : F2H_DMA_INT_MASK_REG;

	dma_write_reg32(pBrd, reg, mask);
}

/* ================================================================
 * User-buffer page management (static helpers)
 * ================================================================
 */

/**
 * put_ubuf_pages - Release and dereference pinned user-buffer pages.
 * @info: Page tracking structure with array of pinned page pointers.
 *
 * Marks each page as dirty and decrements its refcount, then frees the
 * page pointer array.
 */
static void put_ubuf_pages(struct ubuf_info *info)
{
	int i;

	for (i = 0; i < info->nr_pages; i++) {
		set_page_dirty(info->pages[i]);
		put_page(info->pages[i]);
	}
	kfree(info->pages);
}

/**
 * get_ubuf_pages - Pin user-space pages and populate page array.
 * @dev: Device for dev_err logging.
 * @info: Page tracking structure to be filled (pages, nr_pages, offset, size).
 * @uaddr: Start address of the user buffer.
 * @size: Buffer size in bytes.
 *
 * Pins user pages using get_user_pages (with kernel version compatibility),
 * calculates offset and page count, and stores the page pointers in @info->pages.
 * On error, any partially-pinned pages are released.
 *
 * Return: 0 on success, -ENOMEM if allocation fails, -EINVAL on partial pin,
 *         or another negative errno from get_user_pages*().
 */
static int get_ubuf_pages(struct device *dev, struct ubuf_info *info,
			  unsigned long uaddr, unsigned long size)
{
	unsigned long first = (uaddr & PAGE_MASK) >> PAGE_SHIFT;
	unsigned long last = ((uaddr + size - 1) & PAGE_MASK) >> PAGE_SHIFT;
	unsigned int flags = FOLL_FORCE | FOLL_WRITE; // TODO
	int ret, i;

	info->offset = uaddr & ~PAGE_MASK;
	info->nr_pages = last - first + 1;
	info->size = size;

	info->pages = kmalloc(info->nr_pages * sizeof(struct page *), GFP_KERNEL);
	if (!info->pages)
		return -ENOMEM;

	dev_info(dev, "%#lx + %ld => %d pages\n", uaddr, size, info->nr_pages);
#if LINUX_VERSION_CODE < KERNEL_VERSION(4, 0, 0)
	ret = get_user_pages(current, current->mm, uaddr & PAGE_MASK,
			     info->nr_pages, flags & FOLL_WRITE, flags & FOLL_FORCE,
			     info->pages, NULL);
#elif LINUX_VERSION_CODE < KERNEL_VERSION(4, 4, 168)
	ret = get_user_pages_unlocked(current, current->mm, uaddr & PAGE_MASK,
				      info->nr_pages, flags & FOLL_WRITE,
				      flags & FOLL_FORCE, info->pages);
#elif LINUX_VERSION_CODE < KERNEL_VERSION(4, 9, 0)
	ret = get_user_pages_unlocked(current, current->mm, uaddr & PAGE_MASK,
				      info->nr_pages, info->pages, flags);
#else
	ret = get_user_pages_unlocked(uaddr & PAGE_MASK, info->nr_pages,
				      info->pages, flags);
#endif
	if (ret != info->nr_pages)
		goto fail_map;

	return 0;

fail_map:
	dev_err(dev, "get_user_pages fail: ret=%d [%d]\n", ret, info->nr_pages);
	if (ret > 0) {
		for (i = 0; i < ret; i++)
			put_page(info->pages[i]);
		ret = -EINVAL;
	}

	kfree(info->pages);

	return ret;
}

/* ================================================================
 * Scatter-gather allocation and teardown
 * ================================================================
 */

/**
 * ubuf_sg_free - Release all scatter-gather tables and page references for a channel.
 * @pBrd: Board context.
 * @direction: DMA_DIR_H2F or DMA_DIR_F2H.
 *
 * Iterates through all frame-buffer slots, frees SG tables, releases pinned
 * pages, and clears ubuf_sg_table[] / ubuf_info[]. Safe to call multiple
 * times.
 */
static void ubuf_sg_free(struct lsc_pcie *pBrd, enum dma_direction direction)
{
	int i;
	struct sg_table *table;
	struct ubuf_info *info;
	struct lsc_dma_engine *engine = lsc_dma_engine_get(pBrd, direction);

	for (i = 0; i < MAX_NUM_FRAME_BUF; i++) {
		table = engine->xfer.ubuf_sg_table[i];
		info = engine->xfer.ubuf_info[i];

		if (info) {
			put_ubuf_pages(info);
			kfree(info);
		}

		if (table) {
			sg_free_table(table);
			kfree(table);
		}

		engine->xfer.ubuf_sg_table[i] = NULL;
		engine->xfer.ubuf_info[i] = NULL;
	}
}

static enum dma_data_direction lsc_dma_data_dir(enum dma_direction direction)
{
	return (direction == DMA_DIR_H2F) ? DMA_TO_DEVICE : DMA_FROM_DEVICE;
}

/**
 * dma_ubuf_unmap - Unmap and free user-buffer SG resources for a DMA channel.
 * @pBrd: Board context.
 * @direction: DMA_DIR_H2F or DMA_DIR_F2H.
 *
 * Unmaps all scatter-gather buffers via dma_unmap_sg(), then releases
 * the SG tables and user-buffer page references.  Safe to call even if
 * no buffers are currently mapped.
 */
void dma_ubuf_unmap(struct lsc_pcie *pBrd, enum dma_direction direction)
{
	int i;
	struct sg_table *table;
	struct lsc_dma_engine *engine = lsc_dma_engine_get(pBrd, direction);
	enum dma_data_direction dma_dir = lsc_dma_data_dir(direction);

	for (i = 0; i < MAX_NUM_FRAME_BUF; i++) {
		table = engine->xfer.ubuf_sg_table[i];
		if (table)
			dma_unmap_sg(&pBrd->pdev->dev, table->sgl, table->nents, dma_dir);
	}

	ubuf_sg_free(pBrd, direction);
}

/**
 * ubuf_sg_alloc - Pin a user buffer and build a scatter-gather table for it.
 * @pBrd: Board context.
 * @idx: Frame-buffer slot index (0 .. MAX_NUM_FRAME_BUF-1).
 * @addr: User-space buffer address.
 * @len: Buffer size in bytes.
 * @direction: DMA_DIR_H2F or DMA_DIR_F2H.
 *
 * Pins user-space pages, allocates an SG table, and stores both in
 * @engine->xfer for the given @idx.  On error, releases pinned pages
 * and allocated memory before returning.
 *
 * Return: 0 on success, negative errno on allocation or page-pinning failure.
 */
static int ubuf_sg_alloc(struct lsc_pcie *pBrd, int idx, void *addr,
			 size_t len, enum dma_direction direction)
{
	unsigned long uaddr = (unsigned long)addr;
	struct ubuf_info *info;
	struct sg_table *table;
	struct lsc_dma_engine *engine = lsc_dma_engine_get(pBrd, direction);
	int ret;

	info = kmalloc(sizeof(*info), GFP_KERNEL);
	if (!info)
		return -ENOMEM;

	ret = get_ubuf_pages(&pBrd->pdev->dev, info, uaddr, len);
	if (ret)
		goto fail_init_ubuf;

	table = kmalloc(sizeof(*table), GFP_KERNEL);
	if (!table) {
		ret = -ENOMEM;
		goto fail_table;
	}

	ret = sg_alloc_table_from_pages(table, info->pages, info->nr_pages,
					info->offset, info->size, GFP_KERNEL);
	if (ret)
		goto fail_sg;

	engine->xfer.ubuf_sg_table[idx] = table;
	engine->xfer.ubuf_info[idx] = (void *)info;

	return 0;

fail_sg:
	kfree(table);
fail_table:
	put_ubuf_pages(info);
fail_init_ubuf:
	kfree(info);

	return ret;
}

/**
 * dma_ubuf_map - Pin user-space buffers and create DMA SG mappings.
 * @pBrd: Board context.
 * @uaddr: Array of user-space buffer addresses (one per frame buffer).
 * @len: Length of each buffer in bytes.
 * @buf_cnt: Number of buffers to map (1 .. MAX_NUM_FRAME_BUF).
 * @direction: DMA_DIR_H2F or DMA_DIR_F2H.
 *
 * For each user buffer: pins pages with get_user_pages, builds an SG table,
 * and maps it for DMA.  On failure any partially-mapped buffers are cleaned up.
 *
 * Return: 0 on success, -ENOMEM on allocation or mapping failure.
 */
int dma_ubuf_map(struct lsc_pcie *pBrd, void **uaddr, int len, int buf_cnt,
		 enum dma_direction direction)
{
	struct sg_table *table;
	struct lsc_dma_engine *engine = lsc_dma_engine_get(pBrd, direction);
	enum dma_data_direction dma_dir = lsc_dma_data_dir(direction);
	u8 i;
	int mapped;

	for (i = 0; i < buf_cnt; i++) {
		if (ubuf_sg_alloc(pBrd, i, uaddr[i], len, direction)) {
			ubuf_sg_free(pBrd, direction);
			return -ENOMEM;
		}

		table = engine->xfer.ubuf_sg_table[i];

		mapped = dma_map_sg(&pBrd->pdev->dev, table->sgl, table->nents, dma_dir);
		if (!mapped) {
			dma_ubuf_unmap(pBrd, direction);
			return (-ENOMEM);
		}
		engine->xfer.mapped_nents[i] = mapped;
	}

	return 0;
}

/* ================================================================
 * Parameter validation
 * ================================================================
 */

/**
 * validate_dma_xfer_params - Sanity-check DMA transfer parameters.
 * @dev: Device for dev_err logging.
 * @dir: Channel index (must be < NUM_DMA_DIRECTIONS).
 * @buf_cnt: Number of user buffers (1 .. MAX_NUM_FRAME_BUF).
 * @fpga_addr: Device-side offset; must be 8-DW (32-byte) aligned.
 * @len: Bytes per buffer; must be non-zero and dword-aligned.
 *
 * Return: 0 on success, -EINVAL if any parameter is out of range.
 */
int validate_dma_xfer_params(struct device *dev, u8 dir, int buf_cnt,
			     u64 fpga_addr, size_t len)
{
	if (dir >= NUM_DMA_DIRECTIONS) {
		dev_err(dev, "invalid DMA direction %u\n", dir);
		return -EINVAL;
	}

	if (buf_cnt < 1 || buf_cnt > MAX_NUM_FRAME_BUF) {
		dev_err(dev, "invalid buf_cnt %d (must be 1....%d)\n", buf_cnt,
			MAX_NUM_FRAME_BUF);
		return -EINVAL;
	}

	if (fpga_addr & (DMA_FPGA_ADDR_8DW_ALIGN - 1)) {
		dev_err(dev, "fpga_addr 0x%llx not %u-byte (8-DW) aligned\n",
			(unsigned long long)fpga_addr, DMA_FPGA_ADDR_8DW_ALIGN);
		return -EINVAL;
	}

	if (len == 0 || (len & (DMA_XFER_LEN_ALIGN - 1))) {
		dev_err(dev, "invalid transfer len %zu (non-zero, multiple of %u required)\n",
			len, DMA_XFER_LEN_ALIGN);
		return -EINVAL;
	}

	return 0;
}

/* ================================================================
 * Descriptor management
 * ================================================================
 */

/**
 * dma_desc_free - Free DMA descriptor arrays for a channel.
 * @pBrd: Board context.
 * @direction: DMA_DIR_H2F or DMA_DIR_F2H.
 *
 * Iterates over all frame-buffer slots and, for each one that has a
 * descriptor array, releases the coherent DMA allocation.
 */
void dma_desc_free(struct lsc_pcie *pBrd,
		   enum dma_direction direction)
{
	struct lsc_dma_engine *engine = lsc_dma_engine_get(pBrd, direction);
	struct dma_desc_hw *dma_desc;
	u8 i;

	dev_info(&pBrd->pdev->dev, "free dma desc dir=%s\n",
		 direction == DMA_DIR_H2F ? "H2F" : "F2H");

	for (i = 0; i < MAX_NUM_FRAME_BUF; i++) {
		dma_desc = engine->xfer.dma_desc[i];

		if (dma_desc && engine->xfer.mapped_nents[i])
			dma_free_coherent(&pBrd->pdev->dev,
					  engine->xfer.mapped_nents[i] * sizeof(struct dma_desc_hw),
					  dma_desc, engine->xfer.dma_desc_handle[i]);
		engine->xfer.dma_desc[i] = NULL;
	}
}

/**
 * dma_xfer_cleanup - Release descriptors, unmap user buffers, and reset xfer state.
 * @pBrd: Board context.
 * @direction: DMA_DIR_H2F or DMA_DIR_F2H.
 *
 * Frees coherent descriptor memory, unmaps and unpins user buffers, and clears
 * per-transfer bookkeeping (ubuf_cnt, circ_buffer_on).  Safe to call when nothing
 * is mapped; used from IOCTL_PCIEDMA_CLEANUP, device release, and GEN_DESC errors.
 */
void dma_xfer_cleanup(struct lsc_pcie *pBrd, enum dma_direction direction)
{
	struct lsc_dma_engine *engine = lsc_dma_engine_get(pBrd, direction);

	dma_desc_free(pBrd, direction);
	dma_ubuf_unmap(pBrd, direction);
	engine->xfer.ubuf_cnt = 0;
	engine->xfer.circ_buffer_on = false;
}

/**
 * dma_program_desc_fetch_regs - Program DMA descriptor fetch address registers.
 * @pBrd: Board context.
 * @dir: DMA_DIR_H2F or DMA_DIR_F2H.
 * @first_desc_phy_addr: Physical address of the first descriptor in the chain.
 * @number_of_contiguous_desc: Number of descriptors in the first contiguous run.
 *
 * Writes the descriptor address (split into HI/LO) and the contiguous
 * descriptor count into the appropriate DMA control registers based on @dir.
 * A full 64-descriptor run is encoded as CONT_DESC_64.
 */
static void dma_program_desc_fetch_regs(struct lsc_pcie *pBrd,
					enum dma_direction dir,
					dma_addr_t first_desc_phy_addr,
					u32 number_of_contiguous_desc)
{
	u32 desc_addr_lo_reg = (dir == DMA_DIR_H2F) ? H2F_DESC_ADDR_LO_REG : F2H_DESC_ADDR_LO_REG;
	u32 desc_addr_hi_reg = (dir == DMA_DIR_H2F) ? H2F_DESC_ADDR_HI_REG : F2H_DESC_ADDR_HI_REG;
	u32 cont_remain_reg = (dir == DMA_DIR_H2F) ? H2F_CONT_REMAIN_REG : F2H_CONT_REMAIN_REG;

	u32 cont_decs = (number_of_contiguous_desc >= CONT_DESC_MAX) ?
			CONT_DESC_64 : number_of_contiguous_desc;

	dma_write_reg32(pBrd, desc_addr_hi_reg, (u32)(first_desc_phy_addr >> 32));
	dma_write_reg32(pBrd, desc_addr_lo_reg, (u32)first_desc_phy_addr);
	dma_write_reg32(pBrd, cont_remain_reg, cont_decs);
}

/**
 * dma_desc_hw_debug_dump - Log hardware descriptor fields for debugging.
 * @dev: Device for dev_info logging.
 * @buf_idx: Frame-buffer index being dumped (for log context).
 * @desc: Pointer to descriptor array.
 * @num_desc: Number of descriptors in the array to dump.
 *
 * Prints all 8 DWs of each descriptor in the chain.  Returns silently if
 * @desc is NULL or @num_desc is 0.
 */
static void dma_desc_hw_debug_dump(struct device *dev, unsigned int buf_idx,
				   const struct dma_desc_hw *desc,
				   unsigned int num_desc)
{
	unsigned int k;

	if (!desc || num_desc == 0)
		return;

	for (k = 0; k < num_desc; k++) {
		if (k == 0)
			dev_info(dev, "****buf[%u] Descriptor*****\n", buf_idx);

		dev_info(dev,
			 "DESC[%u] - DW0:0x%x, DW1:0x%x, DW2:0x%x, DW3:0x%x, "
			 "DW4:0x%x, DW5:0x%x, DW6:0x%x, DW7:0x%x\n",
			 k,
			 desc[k].desc_ctrl, desc[k].dma_len,
			 desc[k].next_desc_addr_lo, desc[k].next_desc_addr_hi,
			 desc[k].src_addr_lo, desc[k].src_addr_hi,
			 desc[k].dest_addr_lo, desc[k].dest_addr_hi);
	}
}

/**
 * set_descriptor_eop - Mark the last descriptor as end-of-packet.
 * @pBrd: Board context.
 * @direction: DMA_DIR_H2F or DMA_DIR_F2H.
 *
 * Sets the DESC_CTRL_EOP flag on the final descriptor in the last buffer's
 * descriptor chain.  Used in direct (non-circular) mode to signal the DMA
 * engine to stop after this transfer.
 *
 */
static void set_descriptor_eop(struct lsc_pcie *pBrd,
			       enum dma_direction direction)
{
	struct lsc_dma_engine *engine = lsc_dma_engine_get(pBrd, direction);
	struct dma_desc_hw *desc;
	int last_buf_idx, nents;

	if (engine->xfer.ubuf_cnt == 0)
		return;

	last_buf_idx = engine->xfer.ubuf_cnt - 1;
	desc = engine->xfer.dma_desc[last_buf_idx];
	nents = engine->xfer.mapped_nents[last_buf_idx];

	if (!desc || nents == 0)
		return;

	desc[nents - 1].desc_ctrl |= DESC_CTRL_EOP;
}

/**
 * set_descriptor_interrupt - Enable interrupt on the last descriptor.
 * @pBrd: Board context.
 * @direction: DMA_DIR_H2F or DMA_DIR_F2H.
 *
 * Sets the DESC_CTRL_INT flag on the final descriptor in the last buffer's
 * descriptor chain.  Causes the DMA engine to raise an interrupt when that
 * descriptor completes.
 *
 */
static void set_descriptor_interrupt(struct lsc_pcie *pBrd,
				     enum dma_direction direction)
{
	struct lsc_dma_engine *engine = lsc_dma_engine_get(pBrd, direction);
	struct dma_desc_hw *desc;
	int last_buf_idx, nents;

	if (engine->xfer.ubuf_cnt == 0)
		return;

	last_buf_idx = engine->xfer.ubuf_cnt - 1;
	desc = engine->xfer.dma_desc[last_buf_idx];
	nents = engine->xfer.mapped_nents[last_buf_idx];

	if (!desc || nents == 0)
		return;

	desc[nents - 1].desc_ctrl |= DESC_CTRL_INT;
}

/**
 * dma_gen_desc - Generate DMA descriptors from an already-mapped SG list.
 * @pBrd: Board context.
 * @dir: DMA_DIR_H2F or DMA_DIR_F2H.
 * @fpga_addr: Device-side base address for the transfer.
 * @circ_buff: When 1 the last descriptor chains back to the first (circular mode);
 *             when 0 the last descriptor is marked EOP + INT (direct / one-shot mode).
 *
 * Allocates a coherent descriptor array for each mapped buffer, fills
 * in the source/destination addresses from the SG entries, chains
 * multi-buffer transfers together, and programs the hardware descriptor-
 * fetch registers.
 *
 * Return: 0 on success, negative errno on failure.
 */
int dma_gen_desc(struct lsc_pcie *pBrd, enum dma_direction dir, u64 fpga_addr,
		 u8 circ_buff)
{
	int i, j;
	struct sg_table *table;
	struct scatterlist *sg;
	unsigned int num_sg, sum_sg = 0;
	struct dma_desc_hw *desc;
	size_t desc_size;
	struct lsc_dma_engine *engine;

	if (dir >= NUM_DMA_DIRECTIONS)
		return -EINVAL;
	engine = lsc_dma_engine_get(pBrd, dir);

	/* xfer params validated in ioctl (validate_dma_xfer_params) before map/desc */

	//Generate desc for buffer from user space
	for (i = 0; i < engine->xfer.ubuf_cnt; i++) {
		desc_size = engine->xfer.mapped_nents[i] * sizeof(struct dma_desc_hw);
		engine->xfer.dma_desc[i] = dma_alloc_coherent(&pBrd->pdev->dev, desc_size,
							      &engine->xfer.dma_desc_handle[i],
							      GFP_KERNEL | __GFP_ZERO);
		if (!engine->xfer.dma_desc[i]) {
			dma_desc_free(pBrd, dir);
			return -ENOMEM;
		}
		dev_info(&pBrd->pdev->dev, "desc[%d]: cpu_addr %px dma_addr: %llx, len = %zu\n", i,
			 engine->xfer.dma_desc[i], engine->xfer.dma_desc_handle[i], desc_size);
	}

	u64 host_addr;
	u64 fpga_seg_addr, fpga_addr_offset;
	u64 src_addr, dest_addr;
	u64 next_desc_addr;

	//Fill SG-Elements info
	for (i = 0; i < engine->xfer.ubuf_cnt; i++) {
		table = engine->xfer.ubuf_sg_table[i];
		desc = engine->xfer.dma_desc[i];
		num_sg = engine->xfer.mapped_nents[i];

		sum_sg += num_sg;
		fpga_addr_offset = 0;

		dev_info(&pBrd->pdev->dev, "=== buf[%d] has mapped_nents %d (orig %d) ===\n",
			 i, num_sg, table->nents);
		for_each_sg(table->sgl, sg, num_sg, j) {
#ifdef CONFIG_ARCH_DMA_ADDR_T_64BIT
			dev_info(&pBrd->pdev->dev, "[%02d]: dma_addr: %#llx, len = %u(0x%x)\n", j,
				 sg_dma_address(sg), sg_dma_len(sg), sg_dma_len(sg));
#else
			dev_info(&pBrd->pdev->dev, "[%02d]: dma_addr: %#x, len = %u\n", j,
				 sg_dma_address(sg), sg_dma_len(sg));
#endif
			host_addr = sg_dma_address(sg);
			fpga_seg_addr = fpga_addr + fpga_addr_offset;
			src_addr = (dir == DMA_DIR_F2H) ? fpga_seg_addr : host_addr;
			dest_addr = (dir == DMA_DIR_F2H) ? host_addr : fpga_seg_addr;
			next_desc_addr = engine->xfer.dma_desc_handle[i] +
					 (sizeof(struct dma_desc_hw) * (j + 1));
			fpga_addr_offset += sg_dma_len(sg);

			desc[j].dma_len = sg_dma_len(sg);
			desc[j].src_addr_lo = (u32)(src_addr & 0xFFFFFFFF);
			desc[j].src_addr_hi = (u32)(src_addr >> 32);
			desc[j].dest_addr_lo = (u32)(dest_addr & 0xFFFFFFFF);
			desc[j].dest_addr_hi = (u32)(dest_addr >> 32);
			desc[j].next_desc_addr_lo = (u32)(next_desc_addr & 0xFFFFFFFF);
			desc[j].next_desc_addr_hi = (u32)(next_desc_addr >> 32);

			/*
			 * At each 64-descriptor boundary (j == 63, 127, ...), encode how
			 * many descriptors follow in the next segment: min(64, remaining).
			 * E.g. num_sg 150 -> desc[63] gets 64, desc[127] gets 22.
			 */
			if (num_sg > CONT_DESC_MAX &&
			    (j + 1) % CONT_DESC_MAX == 0 &&
			    j < num_sg - 1) {
				unsigned int remaining = num_sg - (j + 1);
				unsigned int next_chunk = min_t(unsigned int, remaining,
								CONT_DESC_MAX);

				/* a full 64-descriptor run is encoded as 0 in this field */
				if (next_chunk == CONT_DESC_MAX)
					next_chunk = CONT_DESC_64;

				desc[j].desc_ctrl = (next_chunk << 8);
			}
		}

		/*
		 * Multiple buffers in the chain: configure the last entry in the
		 * current buffer to point to the next buffer.
		 */
		/* not the last buffer in the chain */
		if (engine->xfer.ubuf_cnt > 1 && i != engine->xfer.ubuf_cnt - 1) {
			int next_mapped = engine->xfer.mapped_nents[i + 1];
			u32 next_nents_val = (next_mapped >= CONT_DESC_MAX) ?
					     CONT_DESC_64 : next_mapped;

			desc[num_sg - 1].desc_ctrl = (next_nents_val << 8);
			next_desc_addr = engine->xfer.dma_desc_handle[i + 1];
			desc[num_sg - 1].next_desc_addr_lo =
				(u32)(next_desc_addr & 0xFFFFFFFF);
			desc[num_sg - 1].next_desc_addr_hi =
				(u32)(next_desc_addr >> 32);
		}

		/* last buffer */
		if (i == engine->xfer.ubuf_cnt - 1) {
			if (circ_buff == 1) {
				int first_mapped = engine->xfer.mapped_nents[0];
				u32 first_nents_val = (first_mapped >= CONT_DESC_MAX) ?
						      CONT_DESC_64 : first_mapped;

				desc[num_sg - 1].desc_ctrl = (first_nents_val << 8);
				next_desc_addr = engine->xfer.dma_desc_handle[0];
				desc[num_sg - 1].next_desc_addr_lo =
					(u32)(next_desc_addr & 0xFFFFFFFF);
				desc[num_sg - 1].next_desc_addr_hi =
					(u32)(next_desc_addr >> 32);
			} else {
				/* direct mode: set EOP and INT on last descriptor */
				set_descriptor_eop(pBrd, dir);
				set_descriptor_interrupt(pBrd, dir);
			}
		}

		dma_desc_hw_debug_dump(&pBrd->pdev->dev, (unsigned int)i, desc, num_sg);
	}

	engine->xfer.total_descriptors = sum_sg;

	dma_program_desc_fetch_regs(pBrd, dir, engine->xfer.dma_desc_handle[0],
				    min_t(unsigned int,
					  engine->xfer.mapped_nents[0],
					  CONT_DESC_MAX));

	return 0;
}

/* ================================================================
 * DMA transfer start / stop
 * ================================================================
 */

/**
 * dma_start - Kick the DMA engine on the given channel (non-blocking).
 * @pBrd: Board context.
 * @direction: DMA_DIR_H2F or DMA_DIR_F2H.
 *
 * Clears the engine's dma_done flag, then writes the START bit to the
 * control register.  Completion is signalled asynchronously via the
 * DMA IRQ handler.
 *
 * Return: 0 on success, -EBUSY if the previous request has not yet cleared.
 */
int dma_start(struct lsc_pcie *pBrd, enum dma_direction direction)
{
	u32 read_val;
	u32 ctrl_reg;
	unsigned long flags;

	ctrl_reg = (direction == DMA_DIR_H2F ? H2F_DMA_CTRL_REG : F2H_DMA_CTRL_REG);

	read_val = dma_read_reg32(pBrd, ctrl_reg) & START_DMA_MASK;
	if (read_val != 0) {
		dev_err(&pBrd->pdev->dev, "DMA REQUEST BIT NOT CLEARED YET\n");
		return -EBUSY;
	}

	struct lsc_dma_engine *engine = lsc_dma_engine_get(pBrd, direction);

	spin_lock_irqsave(&engine->lock, flags);
	engine->xfer.dma_done = false;
	spin_unlock_irqrestore(&engine->lock, flags);

	dma_write_reg32(pBrd, ctrl_reg, START_DMA);

	return 0;
}

/**
 * dma_stop - Stops a running DMA transfer.
 * @pBrd: Board context.
 * @direction: DMA_DIR_H2F or DMA_DIR_F2H.
 *
 * For AXI-Stream mode: writes STOP_DMA and polls until the stop bit clears.
 * For other modes: sets the EOP flag on the last descriptor and
 * polls the DMA BUSY status bit until it clears.
 *
 * Return: 0 when the engine has stopped, -EOPNOTSUPP or -ETIMEDOUT on error.
 */
int dma_stop(struct lsc_pcie *pBrd, enum dma_direction direction)
{
	u32 read_val;
	u32 sts_reg;
	int ret;

	if (pBrd->dev_mode == DMA_AXI_S) {
		if (direction != DMA_DIR_F2H) {
			dev_err(&pBrd->pdev->dev, "only F2H direction is supported for AXI-S mode\n");
			return -EOPNOTSUPP;
		}

		dma_write_reg32(pBrd, F2H_DMA_CTRL_2_REG, STOP_DMA);

		/* Poll until STOP_DMA clears (1 ms interval, 10 s timeout) */
		ret = read_poll_timeout(dma_read_reg32,
					read_val,
					!(read_val & STOP_DMA_MASK),  /* cond: stop when bit cleared */
					1000,                      /* sleep 1ms between reads */
					10000000,                       /* 10 second total timeout */
					false,                         /* read first, then sleep */
					pBrd, F2H_DMA_CTRL_2_REG);

		if (ret == 0)
			dev_info(&pBrd->pdev->dev, "stop bit (cleared) = %d\n", read_val);
		else
			dev_err(&pBrd->pdev->dev, "poll stop bit for 0 failed\n");

		return ret;
	}

	sts_reg = (direction == DMA_DIR_H2F) ? H2F_DMA_STS_REG : F2H_DMA_STS_REG;

	set_descriptor_eop(pBrd, direction);

	/* Poll until DMA BUSY clears (1 ms interval, 10 s timeout) */
	ret = read_poll_timeout(dma_read_reg32,
				read_val,
				!(read_val & DMA_STS_BUSY_MASK),  /* cond: stop when bit cleared */
				1000,                      /* sleep 1ms between reads */
				10000000,                       /* 10 second total timeout */
				false,                         /* read first, then sleep */
				pBrd, sts_reg);

	if (ret == 0)
		dev_info(&pBrd->pdev->dev, "DMA BUSY bit (cleared) = %d\n", read_val);
	else
		dev_err(&pBrd->pdev->dev, "poll DMA BUSY bit for 0 failed\n");

	return ret;
}

/**
 * dma_start_and_wait - Start a DMA transfer and block until completion or timeout.
 * @pBrd:       Board context (buffers must already be mapped and descriptors generated).
 * @direction:  DMA_DIR_H2F or DMA_DIR_F2H.
 * @timeout_ms: Max wait in milliseconds; 0 uses the driver default of 1000 ms.
 * @ops:        IRQ callback table; NULL uses the built-in dma_irq_default_ops.
 *              Custom ops MUST set engine->xfer.dma_done = true and call
 *              wake_up(&pBrd->dma.wq) on completion, otherwise this function
 *              will time out.
 * @ops_priv:   Opaque pointer forwarded to @ops callbacks; ignored when @ops is NULL.
 * @result:     Filled on successful return; may be NULL if the caller only needs pass/fail.
 *
 * Registers IRQ ops, starts the engine, waits for dma_done, harvests
 * completion status, and unregisters ops before returning.
 * Called from the character device IOCTL path (lsc_pcie_cdev.c).
 *
 * Return: 0 on success, -EBUSY if the engine is already running,
 *         -ETIME on timeout.
 */
int dma_start_and_wait(struct lsc_pcie *pBrd, enum dma_direction direction,
		       u32 timeout_ms, const struct dma_irq_ops *ops,
		       void *ops_priv, struct dma_completion_result *result)
{
	struct lsc_dma_engine *engine = lsc_dma_engine_get(pBrd, direction);
	unsigned long timeout_j;
	unsigned long flags;
	long wait_ret;
	int ret;

	if (!ops)
		ops = &dma_irq_default_ops;

	pcie_register_dma_irq_ops(pBrd, direction, ops, ops_priv);

	ret = dma_start(pBrd, direction);
	if (ret < 0)
		goto out_unregister;

	timeout_j = msecs_to_jiffies(timeout_ms ? timeout_ms : 1000UL);

	spin_lock_irqsave(&engine->lock, flags);
	wait_ret = wait_event_lock_timeout(pBrd->dma.wq,
					   engine->xfer.dma_done,
					   engine->lock,
					   flags,
					   timeout_j);
	if (wait_ret == 0) {
		spin_unlock_irqrestore(&engine->lock, flags);
		ret = -ETIME;
		goto out_unregister;
	}

	if (result) {
		result->status_reg = engine->xfer.dma_status_reg;
		result->error = dma_status_has_error(pBrd, result->status_reg);
		if (pBrd->dev_mode == AXI_BRIDGE) {
			result->completed_desc_cnt = 0;
			result->expected_desc_cnt  = 0;
		} else {
			result->completed_desc_cnt = engine->xfer.comp_desc_cnt;
			result->expected_desc_cnt  = engine->xfer.total_descriptors;
		}
	}
	spin_unlock_irqrestore(&engine->lock, flags);
	ret = 0;

out_unregister:
	pcie_unregister_dma_irq_ops(pBrd, direction);
	return ret;
}

/* ================================================================
 * DMA status readback
 * ================================================================
 */

/**
 * dma_get_h2f_dma_status - Read and decode the H2F DMA status register.
 * @pBrd: Board context.
 *
 * Return: A populated struct h2f_dma_sts with each field extracted via
 *         FIELD_GET from the raw 32-bit register value.
 */
struct h2f_dma_sts dma_get_h2f_dma_status(struct lsc_pcie *pBrd)
{
	u32 reg_val = dma_read_reg32(pBrd, H2F_DMA_STS_REG);
	struct h2f_dma_sts status = {0};

	status.rsvd              = FIELD_GET(H2F_RSVD_1, reg_val);
	status.dma_len_err       = FIELD_GET(H2F_DMA_LEN_ERR, reg_val);
	status.h2f_dest_addr_err = FIELD_GET(H2F_DEST_ADDR_ERR, reg_val);
	status.h2f_src_addr_err  = FIELD_GET(H2F_SRC_ADDR_ERR, reg_val);
	status.desc_addr_err     = FIELD_GET(H2F_DESC_ADDR_ERR, reg_val);
	status.axi_write_err     = FIELD_GET(H2F_AXI_WRITE_ERR, reg_val);
	status.h2f_cplto_err     = FIELD_GET(H2F_CPLTO_ERR, reg_val);
	status.h2f_cpl_err       = FIELD_GET(H2F_CPL_ERR, reg_val);
	status.desc_cplto_err    = FIELD_GET(H2F_DESC_CPLTO_ERR, reg_val);
	status.desc_cpl_err      = FIELD_GET(H2F_DESC_CPL_ERR, reg_val);
	status.dma_int_done      = FIELD_GET(H2F_INT_DONE, reg_val);
	status.dma_eop_done      = FIELD_GET(H2F_EOP_DONE, reg_val);
	status.busy              = FIELD_GET(H2F_BUSY, reg_val);

	return status;
}

/**
 * dma_get_f2h_dma_status - Read and decode the F2H DMA status register.
 * @pBrd: Board context.
 *
 * Return: A populated struct f2h_dma_sts with each field extracted via
 *         FIELD_GET from the raw 32-bit register value.
 */
struct f2h_dma_sts dma_get_f2h_dma_status(struct lsc_pcie *pBrd)
{
	u32 reg_val = dma_read_reg32(pBrd, F2H_DMA_STS_REG);
	struct f2h_dma_sts status = {0};

	status.rsvd              = FIELD_GET(F2H_RSVD_1, reg_val);
	status.axi_st_data_l_err = FIELD_GET(F2H_AXI_ST_DATA_L_ERR, reg_val);
	status.axi_st_data_s_err = FIELD_GET(F2H_AXI_ST_DATA_S_ERR, reg_val);
	status.dma_len_err       = FIELD_GET(F2H_DMA_LEN_ERR, reg_val);
	status.f2h_dest_addr_err = FIELD_GET(F2H_DEST_ADDR_ERR, reg_val);
	status.f2h_src_addr_err  = FIELD_GET(F2H_SRC_ADDR_ERR, reg_val);
	status.desc_addr_err     = FIELD_GET(F2H_DESC_ADDR_ERR, reg_val);
	status.axi_read_err      = FIELD_GET(F2H_AXI_READ_ERR, reg_val);
	status.rsvd_2            = FIELD_GET(F2H_RSVD_2, reg_val);
	status.desc_cplto_err    = FIELD_GET(F2H_DESC_CPLTO_ERR, reg_val);
	status.desc_cpl_err      = FIELD_GET(F2H_DESC_CPL_ERR, reg_val);
	status.dma_int_done      = FIELD_GET(F2H_INT_DONE, reg_val);
	status.dma_eop_done      = FIELD_GET(F2H_EOP_DONE, reg_val);
	status.busy              = FIELD_GET(F2H_BUSY, reg_val);

	return status;
}

/**
 * dma_status_has_error - Check whether a DMA status register contains error bits.
 * @pBrd: Board context (used to determine DMA mode for AXI-S extra valid bits).
 * @status_reg: Raw 32-bit value read from H2F_DMA_STS_REG or F2H_DMA_STS_REG.
 *
 * Masks out the expected status bits (EOP_DONE, INT_DONE, and AXI-S
 * data-error bits when applicable).  Any remaining set bits are errors.
 *
 * Return: true if at least one error bit is set; false otherwise.
 */
bool dma_status_has_error(struct lsc_pcie *pBrd, u32 status_reg)
{
	u32 valid_bits = DMA_EOP_DONE_BIT | DMA_INT_DONE_BIT;

	if (pBrd->dev_mode == DMA_AXI_S)
		valid_bits |= F2H_AXI_ST_DATA_S_ERR | F2H_AXI_ST_DATA_L_ERR;

	return !!(status_reg & ~valid_bits);
}

/**
 * dma_status_check - Read and populate a DMA status report for user-space.
 * @pBrd: Board context.
 * @status: User-facing status struct (direction in, fields filled on return).
 *
 * Reads the DMA status register and completed-descriptor count for the
 * requested direction, populates the ioctl arg, and logs an error when the
 * completed count does not equal the expected count.
 *
 * Return: 0 on success, -EINVAL for invalid direction.
 */
int dma_status_check(struct lsc_pcie *pBrd, struct dma_status_ioctl_arg *status)
{
	enum dma_direction direction;
	struct lsc_dma_engine *engine;
	u32 ctrl_reg;

	direction = (enum dma_direction)status->dir;
	if (direction >= NUM_DMA_DIRECTIONS) {
		dev_err(&pBrd->pdev->dev, "Invalid DMA direction: %u\n", status->dir);
		return -EINVAL;
	}

	engine = lsc_dma_engine_get(pBrd, direction);

	/* Check DMA status register */
	ctrl_reg = (direction == DMA_DIR_H2F ? H2F_DMA_STS_REG : F2H_DMA_STS_REG);
	status->status_reg = dma_read_reg32(pBrd, ctrl_reg);
	status->dma_error = dma_status_has_error(pBrd, status->status_reg);

	/* Read completed descriptor count */
	ctrl_reg = (direction == DMA_DIR_H2F ? H2F_CPLT_DESC_COUNT_REG : F2H_CPLT_DESC_COUNT_REG);
	status->completed_desc_cnt = dma_read_reg32(pBrd, ctrl_reg);
	status->expected_desc_cnt = engine->xfer.total_descriptors;

	if (status->expected_desc_cnt != status->completed_desc_cnt) {
		dev_err(&pBrd->pdev->dev, "DMA descriptor count mismatch: expected %d, completed %d\n",
			status->expected_desc_cnt, status->completed_desc_cnt);
	} else {
		dev_info(&pBrd->pdev->dev, "DMA completed descriptor count %d matched expected.\n",
			 status->completed_desc_cnt);
	}

	return 0;
}

/* ================================================================
 * Throughput measurement
 * ================================================================
 */

/*
 * ISR-chained throughput measurement context. Passed as dma_ops_priv; the
 * EOP callback decrements remaining and re-triggers DMA until complete.
 */
struct throughput_state {
	int remaining;
	u64 start_ns;
	u64 end_ns;
	u32 ctrl_reg;
	int errors;
	struct completion done;
};

/**
 * throughput_chain_eop_cb - EOP callback for chained (repeated) throughput measurement.
 * @pBrd: Board context.
 * @dir: DMA_DIR_H2F or DMA_DIR_F2H.
 * @status_reg: DMA status register value (unused).
 * @comp_desc_cnt: Completed descriptor count (unused).
 * @priv: Opaque pointer to struct throughput_state.
 *
 * Decrements the remaining transfer count; if more remain, restarts the DMA
 * engine; otherwise records the end timestamp and signals completion.
 */
static void throughput_chain_eop_cb(struct lsc_pcie *pBrd, enum dma_direction dir,
				    u32 status_reg, u32 comp_desc_cnt, void *priv)
{
	struct throughput_state *st = priv;

	if (--st->remaining > 0) {
		dma_write_reg32(pBrd, st->ctrl_reg, START_DMA);
		return;
	}

	st->end_ns = ktime_get_ns();
	complete(&st->done);
}

/**
 * throughput_chain_err_cb - Error callback for chained throughput measurement.
 * @pBrd: Board context.
 * @dir: DMA_DIR_H2F or DMA_DIR_F2H.
 * @status_reg: DMA status register value (logged on error).
 * @priv: Opaque pointer to struct throughput_state.
 *
 * Increments the error counter, logs the error, records end timestamp,
 * and signals completion to unblock the measurement.
 */
static void throughput_chain_err_cb(struct lsc_pcie *pBrd, enum dma_direction dir,
				    u32 status_reg, void *priv)
{
	struct throughput_state *st = priv;

	st->errors++;
	dev_err(&pBrd->pdev->dev, "DMA error during chained throughput dir=%d sts=0x%08x\n",
		dir, status_reg);
	st->end_ns = ktime_get_ns();
	complete(&st->done);
}

static const struct dma_irq_ops dma_irq_throughput_chain_ops = {
	.eop = throughput_chain_eop_cb,
	.err = throughput_chain_err_cb,
};

/**
 * dma_measure_throughput_chained - Run back-to-back DMA iterations and time them.
 * @pBrd: Board context.
 * @throughput_arg: ioctl arg carrying direction, iteration count (in),
 *                  and start/end timestamps (out).
 *
 * Temporarily installs a chained-throughput IRQ callback that re-triggers
 * the DMA engine from IRQ context (no round-trip to user space) for each
 * iteration.  Uses a kernel completion to block until all iterations
 * finish or a timeout / DMA error occurs.
 *
 * Return: 0 on success, -EBUSY / -ETIMEDOUT / -EIO on error.
 */
int dma_measure_throughput_chained(struct lsc_pcie *pBrd,
				   struct dma_throughput_ioctl_arg *throughput_arg)
{
	enum dma_direction direction = (enum dma_direction)throughput_arg->dir;
	struct throughput_state st;
	u32 ctrl_reg, read_val;
	unsigned long timeout_ms;
	long ret;

	ctrl_reg = (direction == DMA_DIR_H2F) ? H2F_DMA_CTRL_REG : F2H_DMA_CTRL_REG;

	read_val = dma_read_reg32(pBrd, ctrl_reg) & START_DMA_MASK;
	if (read_val != 0) {
		dev_err(&pBrd->pdev->dev, "DMA REQUEST BIT NOT CLEARED YET\n");
		return -EBUSY;
	}

	st.remaining = throughput_arg->iterations;
	st.ctrl_reg  = ctrl_reg;
	st.errors    = 0;
	st.start_ns  = 0;
	st.end_ns    = 0;
	init_completion(&st.done);

	pcie_register_dma_irq_ops(pBrd, direction,
				  &dma_irq_throughput_chain_ops, &st);

	timeout_ms = max((unsigned long)throughput_arg->iterations * 5000UL, 10000UL);

	st.start_ns = ktime_get_ns();
	dma_write_reg32(pBrd, ctrl_reg, START_DMA);

	ret = wait_for_completion_timeout(&st.done, msecs_to_jiffies(timeout_ms));

	pcie_unregister_dma_irq_ops(pBrd, direction);

	if (st.errors) {
		dev_err(&pBrd->pdev->dev,
			"Chained throughput aborted: %d DMA error(s)\n", st.errors);
		return -EIO;
	}
	if (ret == 0) {
		dev_err(&pBrd->pdev->dev,
			"Chained throughput timed out (%lu ms, %d remaining)\n",
			timeout_ms, st.remaining);
		return -ETIMEDOUT;
	}

	throughput_arg->start_time_in_ns = st.start_ns;
	throughput_arg->end_time_in_ns   = st.end_ns;

	return 0;
}

/* ================================================================
 * DMA IRQ dispatch callbacks and registration
 * ================================================================
 */

/**
 * dma_irq_default_eop_cb - Default DMA IRQ EOP callback; records status and wakes waiters.
 * @pBrd: Board context.
 * @dir: DMA_DIR_H2F or DMA_DIR_F2H.
 * @status_reg: DMA status register value.
 * @comp_desc_cnt: Completed descriptor count.
 * @priv: Opaque data pointer (unused).
 *
 * Updates the transfer status and descriptor count, sets the done flag,
 * and wakes any threads waiting on the DMA wait queue.
 */
static void dma_irq_default_eop_cb(struct lsc_pcie *pBrd, enum dma_direction dir,
				   u32 status_reg, u32 comp_desc_cnt, void *priv)
{
	struct lsc_dma_engine *engine = lsc_dma_engine_get(pBrd, dir);

	spin_lock(&engine->lock);
	engine->xfer.dma_status_reg = status_reg;
	engine->xfer.comp_desc_cnt = comp_desc_cnt;
	engine->xfer.dma_done = true;
	spin_unlock(&engine->lock);
	wake_up(&pBrd->dma.wq);

	dev_dbg(&pBrd->pdev->dev, "dma_status_reg=0x%x, completed desc cnt=%u\n",
		status_reg, comp_desc_cnt);
}

/**
 * dma_irq_default_err_cb - Default DMA IRQ error callback; logs the DMA error.
 * @pBrd: Board context.
 * @dir: DMA_DIR_H2F or DMA_DIR_F2H.
 * @status_reg: DMA status register value (logged).
 * @priv: Opaque data pointer (unused).
 *
 * Logs error details with rate limiting to prevent log spam.
 */
static void dma_irq_default_err_cb(struct lsc_pcie *pBrd, enum dma_direction dir,
				   u32 status_reg, void *priv)
{
	dev_err_ratelimited(&pBrd->pdev->dev, "DMA error dir=%d sts=0x%08x\n", dir, status_reg);
}

const struct dma_irq_ops dma_irq_default_ops = {
	.eop = dma_irq_default_eop_cb,
	.err = dma_irq_default_err_cb,
};

/**
 * pcie_register_dma_irq_ops - Install custom DMA IRQ callbacks for a channel.
 * @pBrd: Board context.
 * @dir: DMA_DIR_H2F or DMA_DIR_F2H.
 * @ops: Callback table (eop, desc_int, err).
 * @priv: Opaque pointer passed back to each callback.
 *
 * Atomically replaces the IRQ dispatch callbacks for the given channel.
 * The caller must pair this with pcie_unregister_dma_irq_ops() when done.
 */
void pcie_register_dma_irq_ops(struct lsc_pcie *pBrd, enum dma_direction dir,
			       const struct dma_irq_ops *ops, void *priv)
{
	struct lsc_dma_engine *engine;
	unsigned long flags;

	if (!pBrd || dir >= NUM_DMA_DIRECTIONS || !ops)
		return;

	engine = lsc_dma_engine_get(pBrd, dir);
	spin_lock_irqsave(&engine->irq_ops_lock, flags);
	WRITE_ONCE(engine->dma_ops_priv, priv);
	WRITE_ONCE(engine->dma_ops, ops);
	spin_unlock_irqrestore(&engine->irq_ops_lock, flags);
}

/**
 * pcie_unregister_dma_irq_ops - Remove custom DMA IRQ callbacks.
 * @pBrd: Board context.
 * @dir: DMA_DIR_H2F or DMA_DIR_F2H.
 *
 * Clears the ops pointer and synchronises all IRQ vectors so that no
 * callback is in-flight after this function returns.
 */
void pcie_unregister_dma_irq_ops(struct lsc_pcie *pBrd, enum dma_direction dir)
{
	struct lsc_dma_engine *engine;
	unsigned long flags;
	int i;

	if (!pBrd || dir >= NUM_DMA_DIRECTIONS)
		return;

	engine = lsc_dma_engine_get(pBrd, dir);
	spin_lock_irqsave(&engine->irq_ops_lock, flags);
	WRITE_ONCE(engine->dma_ops, NULL);
	WRITE_ONCE(engine->dma_ops_priv, NULL);
	spin_unlock_irqrestore(&engine->irq_ops_lock, flags);

	for (i = 0; i < (int)pBrd->num_irqs; i++)
		synchronize_irq(pBrd->irq_vec[i]);
}

/* ================================================================
 * DMA IRQ handlers (registered by irq_msi_msix_dma_setup in core)
 * ================================================================
 */

/**
 * dma_irq_handler - Core DMA interrupt dispatcher.
 * @pBrd: Board context.
 * @dir: DMA_DIR_H2F or DMA_DIR_F2H.
 * @irq: Linux IRQ number (unused, for consistency with handler signature).
 *
 * Reads the status register and completed descriptor count, then dispatches
 * registered EOP, descriptor-interrupt, and error callbacks for any status
 * bits that are set.
 *
 * Return: IRQ_HANDLED.
 */
static irqreturn_t dma_irq_handler(struct lsc_pcie *pBrd,
				   enum dma_direction dir, int irq)
{
	const struct dma_irq_ops *ops;
	void *priv;
	u32 sts, comp_desc_cnt, err_bits, valid_bits;

	sts = dma_read_reg32(pBrd,
			     dir == DMA_DIR_H2F ? H2F_DMA_STS_REG : F2H_DMA_STS_REG);

	if (pBrd->dev_mode != AXI_BRIDGE)
		comp_desc_cnt = dma_read_reg32(pBrd,
					       dir == DMA_DIR_H2F ? H2F_CPLT_DESC_COUNT_REG
					       : F2H_CPLT_DESC_COUNT_REG);
	else
		comp_desc_cnt = 0;

	{
		struct lsc_dma_engine *engine = lsc_dma_engine_get(pBrd, dir);

		ops  = READ_ONCE(engine->dma_ops);
		priv = READ_ONCE(engine->dma_ops_priv);
	}

	if (!ops)
		return IRQ_HANDLED;

	if ((sts & DMA_EOP_DONE_BIT) && ops->eop)
		ops->eop(pBrd, dir, sts, comp_desc_cnt, priv);

	if ((sts & DMA_INT_DONE_BIT) && ops->desc_int)
		ops->desc_int(pBrd, dir, sts, comp_desc_cnt, priv);

	valid_bits = DMA_EOP_DONE_BIT | DMA_INT_DONE_BIT;
	if (pBrd->dev_mode == DMA_AXI_S)
		valid_bits |= F2H_AXI_ST_DATA_L_ERR | F2H_AXI_ST_DATA_S_ERR;

	err_bits = sts & ~valid_bits;
	if (err_bits && ops->err)
		ops->err(pBrd, dir, sts, priv);

	return IRQ_HANDLED;
}

/**
 * dma_f2h_irq_handler - ISR top-half for F2H (FPGA-to-Host) DMA channel.
 * @irq: IRQ number.
 * @arg: Pointer to struct lsc_pcie (registered with request_irq).
 *
 * Return: IRQ_HANDLED.
 */
irqreturn_t dma_f2h_irq_handler(int irq, void *arg)
{
	return dma_irq_handler((struct lsc_pcie *)arg, DMA_DIR_F2H, irq);
}

/**
 * dma_h2f_irq_handler - ISR top-half for H2F (Host-to-FPGA) DMA channel.
 * @irq: IRQ number.
 * @arg: Pointer to struct lsc_pcie (registered with request_irq).
 *
 * Return: IRQ_HANDLED.
 */
irqreturn_t dma_h2f_irq_handler(int irq, void *arg)
{
	return dma_irq_handler((struct lsc_pcie *)arg, DMA_DIR_H2F, irq);
}

/**
 * axi_bridge_err_irq_handler - ISR for AXI bridge error interrupts.
 * @irq: IRQ number.
 * @arg: Pointer to struct lsc_pcie.
 *
 * Reads AXI_BRIDGE_STS_REG and logs the error.  Used only when the IP
 * is configured in AXI_BRIDGE mode.
 *
 * Return: IRQ_HANDLED, or IRQ_NONE if @arg is NULL.
 */
irqreturn_t axi_bridge_err_irq_handler(int irq, void *arg)
{
	struct lsc_pcie *pBrd = arg;
	u32 sts;

	(void)irq;
	if (!pBrd)
		return IRQ_NONE;

	sts = ctrl_read_reg32(pBrd, AXI_BRIDGE_STS_REG);
	dev_warn_ratelimited(&pBrd->pdev->dev,
			     "AXI bridge error/status IRQ (MSI vec %u), AXI_BRIDGE_STS_REG=0x%x\n",
			     AXI_BRIDGE_ERR_MSI_VEC, sts);

	return IRQ_HANDLED;
}
