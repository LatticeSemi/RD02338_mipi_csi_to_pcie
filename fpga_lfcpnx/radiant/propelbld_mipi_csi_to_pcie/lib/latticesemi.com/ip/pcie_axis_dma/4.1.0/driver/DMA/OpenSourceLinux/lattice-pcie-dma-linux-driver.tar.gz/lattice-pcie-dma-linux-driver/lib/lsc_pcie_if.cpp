/* SPDX-License-Identifier: MIT */
/*   ==================================================================
 
     >>>>>>>>>>>>>>>>>>>>>>> COPYRIGHT NOTICE <<<<<<<<<<<<<<<<<<<<<<<<<
     ------------------------------------------------------------------
     Copyright (c) 2026 by Lattice Semiconductor Corporation
     ALL RIGHTS RESERVED
     ------------------------------------------------------------------
 
     DISCLAIMER:
 
    LATTICE MAKES NO WARRANTIES ON THIS FILE OR ITS CONTENTS,
    WHETHER EXPRESSED, IMPLIED, STATUTORY,
    OR IN ANY PROVISION OF THE LATTICE PROPEL LICENSE AGREEMENT OR
    COMMUNICATION WITH LICENSEE,
    AND LATTICE SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
    MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
    LATTICE DOES NOT WARRANT THAT THE FUNCTIONS CONTAINED HEREIN WILL MEET
    LICENSEE 'S REQUIREMENTS, OR THAT LICENSEE' S OPERATION OF ANY DEVICE,
    SOFTWARE OR SYSTEM USING THIS FILE OR ITS CONTENTS WILL BE
    UNINTERRUPTED OR ERROR FREE,
    OR THAT DEFECTS HEREIN WILL BE CORRECTED.
    LICENSEE ASSUMES RESPONSIBILITY FOR SELECTION OF MATERIALS TO ACHIEVE
    ITS INTENDED RESULTS, AND FOR THE PROPER INSTALLATION, USE,
    AND RESULTS OBTAINED THEREFROM.
    LICENSEE ASSUMES THE ENTIRE RISK OF THE FILE AND ITS CONTENTS PROVING
    DEFECTIVE OR FAILING TO PERFORM PROPERLY AND IN SUCH EVENT,
    LICENSEE SHALL ASSUME THE ENTIRE COST AND RISK OF ANY REPAIR, SERVICE,
    CORRECTION,
    OR ANY OTHER LIABILITIES OR DAMAGES CAUSED BY OR ASSOCIATED WITH THE
    SOFTWARE.IN NO EVENT SHALL LATTICE BE LIABLE TO ANY PARTY FOR DIRECT,
    INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES,
    INCLUDING LOST PROFITS,
    ARISING OUT OF THE USE OF THIS FILE OR ITS CONTENTS,
    EVEN IF LATTICE HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
    LATTICE 'S SOLE LIABILITY, AND LICENSEE' S SOLE REMEDY,
    IS SET FORTH ABOVE.
    LATTICE DOES NOT WARRANT OR REPRESENT THAT THIS FILE,
    ITS CONTENTS OR USE THEREOF DOES NOT INFRINGE ON THIRD PARTIES'
    INTELLECTUAL PROPERTY RIGHTS, INCLUDING ANY PATENT. IT IS THE USER' S
    RESPONSIBILITY TO VERIFY THE USER SOFTWARE DESIGN FOR CONSISTENCY AND
    FUNCTIONALITY THROUGH THE USE OF FORMAL SOFTWARE VALIDATION METHODS.
     ------------------------------------------------------------------
 
     ================================================================== */


#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/mman.h>
using namespace std;

#include "lsc_pcie_if.h"

/* IOCTL wrappers; public API docs are in lsc_pcie_if.h. */

PCIEDMA_IF::PCIEDMA_IF(const char *pDeviceName)
{
    char drivername[MAX_DEV_FILENAME_SIZE];
    hDev = -1;

    if (pDeviceName == NULL) {
        throw(PCIEDMA_IF_Error("ERROR: Device name is NULL\n"));
    }
    
    // Check if device name is empty
    if (pDeviceName[0] == '\0') {
        throw(PCIEDMA_IF_Error("ERROR: Device name is empty\n"));
    }
    
    // Check if device name will fit in buffer with "/dev/" prefix and null terminator
    if (strlen(pDeviceName) > (MAX_DEV_FILENAME_SIZE - 6)) {
        throw(PCIEDMA_IF_Error("ERROR: Device name string too large\n"));
    }
        
    // Open the kernel driver using the device name (using snprintf for safety)
    int ret = snprintf(drivername, sizeof(drivername), "/dev/%s", pDeviceName);
    if (ret < 0 || ret >= (int)sizeof(drivername)) {
        throw(PCIEDMA_IF_Error("ERROR: Failed to format device path\n"));
    }

    hDev = open(drivername, O_RDWR, 0666); 
    if (hDev == -1) {
        perror("PCIEDMA_IF: open");
        throw(PCIEDMA_IF_Error("ERROR: Device file not found!\n"));
    }

    // Use driver specific IOCTL call to get PCI info from the driver
    if (ioctl(hDev, IOCTL_PCIE_GET_RESOURCES, &PCIinfo) != 0)
    {
        close(hDev);
        hDev = -1;
        throw(PCIEDMA_IF_Error("ERROR: ioctl GET PCI RESOURCES Failed!\n"));
    }

}

PCIEDMA_IF::~PCIEDMA_IF()
{
    if (hDev != -1)
    {
        close(hDev);
        hDev = -1;  
    }
}

bool PCIEDMA_IF::getPCIConfigRegs(uint8_t *pCfg)
{
    struct PCIResourceInfo PCIinfo;

    if (ioctl(hDev, IOCTL_PCIE_GET_RESOURCES, &PCIinfo) != 0)
        return(false);

    memcpy(pCfg, PCIinfo.PCICfgReg, sizeof(PCIinfo.PCICfgReg));
    return(true);
}

int PCIEDMA_IF::getPCIeDeviceMode()
{
    int pcie_mode = 0;

    if (ioctl(hDev, IOCTL_PCIE_GET_DEVICE_MODE, &pcie_mode) < 0) {
        throw(PCIEDMA_IF_Error("PCIEDMA_IF: Failed to obtain PCIE device mode\n"));
    }
    return pcie_mode;
}

bool PCIEDMA_IF::getPCIBarInfo(struct PCIResourceInfo *pInfo)
{
    struct PCIResourceInfo PCIinfo;

    if (ioctl(hDev, IOCTL_PCIE_GET_RESOURCES, &PCIinfo) != 0)
        return(false);
    // Copy the retrieved data into the provided buffer
    if (pInfo != nullptr) {
        memcpy(pInfo, &PCIinfo, sizeof(struct PCIResourceInfo));
    }
    
    return(true);
}


void PCIEDMA_IF::setUserIntMSIVector(uint8_t usr_int, uint8_t vec_val)
{
    struct usr_vec_data usr_vec;
    usr_vec.usr_int = usr_int;
    usr_vec.vec_val = vec_val;
    if(ioctl(hDev, IOCTL_PCIE_USR_VEC_ALLOC, &usr_vec) != 0) {
        throw(PCIEDMA_IF_Error("PCIEDMA_IF: setUserIntMSIVector failed! \n"));
    }
}


uint8_t PCIEDMA_IF::readReg8(uint32_t offset) 
{
    struct rw_ioctl rw;
    uint8_t val;
    uint8_t bar_num = 0; 
    rw.bar_num = bar_num; // Set the BAR number to 0, as we are using BAR0 for register access
    rw.reg = offset;
    rw.value = 0;
    
    if (ioctl(hDev, IOCTL_PCIE_READ_8BIT, &rw) != 0) {
        throw(PCIEDMA_IF_Error("PCIEDMA_IF: readReg8 failed! \n"));
    }
    
    val = (uint8_t)rw.value;

    return(val);
}
    

void PCIEDMA_IF::writeReg8(uint32_t offset, uint8_t val)
{
    struct rw_ioctl rw;
    uint8_t bar_num = 0; 
    rw.bar_num = bar_num; // Set the BAR number to 0, as we are using BAR0 for register access    
    rw.reg = offset;
    rw.value = val;

    if (ioctl(hDev, IOCTL_PCIE_WRITE_8BIT, &rw) != 0)
    {
        throw(PCIEDMA_IF_Error("PCIEDMA_IF: writeReg8 failed! \n"));
    }
    
}


uint16_t PCIEDMA_IF::readReg16(uint32_t offset)
{
    struct rw_ioctl rw;
    uint16_t val;
    uint8_t bar_num = 0; 
    rw.bar_num = bar_num; // Set the BAR number to 0, as we are using BAR0 for register access
    rw.reg = offset;
    rw.value = 0;
    
    if (ioctl(hDev, IOCTL_PCIE_READ_16BIT, &rw) != 0)
    {
        throw(PCIEDMA_IF_Error("PCIEDMA_IF: readReg16 failed! \n"));
    }
    
    val = (uint16_t)rw.value;

    return(val);
}


void PCIEDMA_IF::writeReg16(uint32_t offset, uint16_t val)
{
    struct rw_ioctl rw;
    uint8_t bar_num = 0; 
    rw.bar_num = bar_num; // Set the BAR number to 0, as we are using BAR0 for register access    
    rw.reg = offset;
    rw.value = val;

    if (ioctl(hDev, IOCTL_PCIE_WRITE_16BIT, &rw) != 0)
    {
        throw(PCIEDMA_IF_Error("PCIEDMA_IF: writeReg16 failed! \n"));
    }

}

uint32_t PCIEDMA_IF::readReg32(uint32_t offset)
{
    struct rw_ioctl rw;
    uint32_t val;
    uint8_t bar_num = 0; 
    rw.bar_num = bar_num; // Set the BAR number to 0, as we are using BAR0 for register access
    rw.reg = offset;
    rw.value = 0;
    
    if (ioctl(hDev, IOCTL_PCIE_READ_32BIT, &rw) != 0)
    {
        throw(PCIEDMA_IF_Error("PCIEDMA_IF: readReg32 failed! \n"));
    }
    
    val = (uint32_t)rw.value;

    return(val);
}
    
void PCIEDMA_IF::writeReg32(uint32_t offset, uint32_t val)
{
    struct rw_ioctl rw;
    uint8_t bar_num = 0; 
    rw.bar_num = bar_num; // Set the BAR number to 0, as we are using BAR0 for register access    
    rw.reg = offset;
    rw.value = val;

    if (ioctl(hDev, IOCTL_PCIE_WRITE_32BIT, &rw) != 0)
    {
        throw(PCIEDMA_IF_Error("PCIEDMA_IF: writeReg32 failed! \n"));
    }

}

uint64_t PCIEDMA_IF::readReg64(uint32_t offset)
{
    struct rw_ioctl rw;
    uint64_t val;
    uint8_t bar_num = 0; 
    rw.bar_num = bar_num; // Set the BAR number to 0, as we are using BAR0 for register access
    rw.reg = offset;
    rw.value = 0;
    
    if (ioctl(hDev, IOCTL_PCIE_READ_64BIT, &rw) != 0)
    {
        throw(PCIEDMA_IF_Error("PCIEDMA_IF: readReg64 failed! \n"));
    }
    
    val = (uint64_t)rw.value;

    return(val);
}
    
void PCIEDMA_IF::writeReg64(uint32_t offset, uint64_t val)
{
    struct rw_ioctl rw;
    uint8_t bar_num = 0; 
    rw.bar_num = bar_num; // Set the BAR number to 0, as we are using BAR0 for register access    
    rw.reg = offset;
    rw.value = val;
    if (ioctl(hDev, IOCTL_PCIE_WRITE_64BIT, &rw) != 0)
    {
        throw(PCIEDMA_IF_Error("PCIEDMA_IF: writeReg64 failed! \n"));
    }

}

bool PCIEDMA_IF::readBlock8(uint8_t bar_num, uint32_t offset, std::vector<uint8_t> &val, size_t len, bool incAddr)
{
    struct rw_ioctl rw;
    rw.value = 0;
    rw.bar_num = bar_num;
    val.resize(len);
    for (size_t i = 0; i < len; ++i)
    {
        rw.reg = offset;
        if (ioctl(hDev, IOCTL_PCIE_READ_8BIT, &rw) != 0)
        {
            throw PCIEDMA_IF_Error("PCIEDMA_IF: block read8 failed!");
        }
        val[i] = static_cast<uint8_t>(rw.value);

        if (incAddr)
        {
            offset += sizeof(uint8_t);
        }
    }

    return(true);
}

bool PCIEDMA_IF::writeBlock8(uint8_t bar_num, uint32_t offset, const std::vector<uint8_t> &val, size_t len, bool incAddr)
{
    struct rw_ioctl rw;
    rw.bar_num = bar_num;
    for (size_t i = 0; i < len; ++i)
    {
        rw.reg = offset;
        rw.value = val[i];
        if (ioctl(hDev, IOCTL_PCIE_WRITE_8BIT, &rw) != 0)
        {
            throw PCIEDMA_IF_Error("PCIEDMA_IF: block write8 failed!");
        }

        if (incAddr)
        {
            offset += sizeof(uint8_t);;
        }
    }

    return(true);
}

bool PCIEDMA_IF::readBlock16(uint8_t bar_num, uint32_t offset, std::vector<uint16_t> &val, size_t len, bool incAddr)
{
    struct rw_ioctl rw;
    rw.value = 0;
    rw.bar_num = bar_num;
    val.resize(len);
    for (size_t i = 0; i < len; ++i)
    {
        rw.reg = offset;
        if (ioctl(hDev, IOCTL_PCIE_READ_16BIT, &rw) != 0)
        {
            throw PCIEDMA_IF_Error("PCIEDMA_IF: block read16 failed!");
        }
        val[i] = static_cast<uint16_t>(rw.value);

        if (incAddr)
        {
            offset += sizeof(uint16_t);
        }
    }

    return(true);
}

bool PCIEDMA_IF::writeBlock16(uint8_t bar_num, uint32_t offset, const std::vector<uint16_t> &val, size_t len, bool incAddr)
{
    struct rw_ioctl rw;
    rw.bar_num = bar_num;
    for (size_t i = 0; i < len; ++i)
    {
        rw.reg = offset;
        rw.value = val[i];
        if (ioctl(hDev, IOCTL_PCIE_WRITE_16BIT, &rw) != 0)
        {
            throw PCIEDMA_IF_Error("PCIEDMA_IF: block write16 failed!");
        }

        if (incAddr)
        {
            offset += sizeof(uint16_t);;
        }
    }

    return(true);
}

bool PCIEDMA_IF::readBlock32(uint8_t bar_num, uint32_t offset, std::vector<uint32_t> &val, size_t len, bool incAddr)
{
    struct rw_ioctl rw;
    rw.value = 0;
    rw.bar_num = bar_num;
    val.resize(len);
    for (size_t i = 0; i < len; ++i)
    {
        rw.reg = offset;
        if (ioctl(hDev, IOCTL_PCIE_READ_32BIT, &rw) != 0)
        {
            throw PCIEDMA_IF_Error("PCIEDMA_IF: block read32 failed!");
        }

        val[i] = static_cast<uint32_t>(rw.value);

        if (incAddr)
        {
            offset += sizeof(uint32_t);
        }
    }

    return(true);
}

bool PCIEDMA_IF::writeBlock32(uint8_t bar_num, uint32_t offset, const std::vector<uint32_t> &val, size_t len, bool incAddr)
{
    struct rw_ioctl rw;
    rw.bar_num = bar_num;
    for (size_t i = 0; i < len; ++i)
    {
        rw.reg = offset;
        rw.value = val[i];
        if (ioctl(hDev, IOCTL_PCIE_WRITE_32BIT, &rw) != 0)
        {
            throw PCIEDMA_IF_Error("PCIEDMA_IF: block write32 failed!");
        }

        if (incAddr)
        {
            offset += sizeof(uint32_t);;
        }
    }

    return(true);
}

bool PCIEDMA_IF::readBlock64(uint8_t bar_num, uint32_t offset, std::vector<uint64_t> &val, size_t len, bool incAddr)
{
    struct rw_ioctl rw;
    rw.value = 0;
    rw.bar_num = bar_num;
    val.resize(len);
    for (size_t i = 0; i < len; ++i)
    {
        rw.reg = offset;
        if (ioctl(hDev, IOCTL_PCIE_READ_64BIT, &rw) != 0)
        {
            throw PCIEDMA_IF_Error("PCIEDMA_IF: block read64 failed!");
        }

        val[i] = static_cast<uint64_t>(rw.value);

        if (incAddr)
        {
            offset += sizeof(uint64_t);
        }
    }

    return(true);
}

bool PCIEDMA_IF::writeBlock64(uint8_t bar_num, uint32_t offset, const std::vector<uint64_t> &val, size_t len, bool incAddr)
{
    struct rw_ioctl rw;
    rw.bar_num = bar_num;
    for (size_t i = 0; i < len; ++i)
    {
        rw.reg = offset;
        rw.value = val[i];
        if (ioctl(hDev, IOCTL_PCIE_WRITE_64BIT, &rw) != 0)
        {
            throw PCIEDMA_IF_Error("PCIEDMA_IF: block write64 failed!");
        }

        if (incAddr)
        {
            offset += sizeof(uint64_t);;
        }
    }

    return(true);
}

uint8_t PCIEDMA_IF::read8(uint8_t bar_num, uint32_t offset)
{
    struct rw_ioctl rw;
    uint8_t val;
    rw.bar_num = bar_num;
    rw.reg = offset;
    rw.value = 0;
    if (ioctl(hDev, IOCTL_PCIE_READ_8BIT, &rw) != 0)
    {
        throw(PCIEDMA_IF_Error("PCIEDMA_IF: read8 failed! \n"));
    }
    
    val = (uint8_t)rw.value;

    return(val);
}

void PCIEDMA_IF::write8(uint8_t bar_num, uint32_t offset, uint8_t val)
{
    struct rw_ioctl rw;
    rw.bar_num = bar_num;
    rw.reg = offset;
    rw.value = val;

    if (ioctl(hDev, IOCTL_PCIE_WRITE_8BIT, &rw) != 0)
    {
        throw(PCIEDMA_IF_Error("PCIEDMA_IF: write8 failed! \n"));
    }
}

uint16_t PCIEDMA_IF::read16(uint8_t bar_num, uint32_t offset)
{
    struct rw_ioctl rw;
    uint16_t val;
    rw.bar_num = bar_num;
    rw.reg = offset;
    rw.value = 0;
    if (ioctl(hDev, IOCTL_PCIE_READ_16BIT, &rw) != 0)
    {
        throw(PCIEDMA_IF_Error("PCIEDMA_IF: read16 failed! \n"));
    }
    
    val = (uint16_t)rw.value;

    return(val);
}

void PCIEDMA_IF::write16(uint8_t bar_num, uint32_t offset, uint16_t val)
{
    struct rw_ioctl rw;
    rw.bar_num = bar_num;
    rw.reg = offset;
    rw.value = val;

    if (ioctl(hDev, IOCTL_PCIE_WRITE_16BIT, &rw) != 0)
    {
        throw(PCIEDMA_IF_Error("PCIEDMA_IF: write16 failed! \n"));
    }
}

uint32_t PCIEDMA_IF::read32(uint8_t bar_num, uint32_t offset)
{
    struct rw_ioctl rw;
    uint32_t val;
    rw.bar_num = bar_num;
    rw.reg = offset;
    rw.value = 0;
    if (ioctl(hDev, IOCTL_PCIE_READ_32BIT, &rw) != 0)
    {
        throw(PCIEDMA_IF_Error("PCIEDMA_IF: read32 failed! \n"));
    }
    
    val = (uint32_t)rw.value;

    return(val);
}

void PCIEDMA_IF::write32(uint8_t bar_num, uint32_t offset, uint32_t val)
{
    struct rw_ioctl rw;
    rw.bar_num = bar_num;
    rw.reg = offset;
    rw.value = val;

    if (ioctl(hDev, IOCTL_PCIE_WRITE_32BIT, &rw) != 0)
    {
        throw(PCIEDMA_IF_Error("PCIEDMA_IF: write32 failed! \n"));
    }
}

uint64_t PCIEDMA_IF::read64(uint8_t bar_num, uint32_t offset)
{
    struct rw_ioctl rw;
    uint64_t val;
    rw.bar_num = bar_num;
    rw.reg = offset;
    rw.value = 0;
    if (ioctl(hDev, IOCTL_PCIE_READ_64BIT, &rw) != 0)
    {
        throw(PCIEDMA_IF_Error("PCIEDMA_IF: read64 failed! \n"));
    }
    
    val = (uint64_t)rw.value;

    return(val);
}

void PCIEDMA_IF::write64(uint8_t bar_num, uint32_t offset, uint64_t val)
{
    struct rw_ioctl rw;
    rw.bar_num = bar_num;
    rw.reg = offset;
    rw.value = val;

    if (ioctl(hDev, IOCTL_PCIE_WRITE_64BIT, &rw) != 0)
    {
        throw(PCIEDMA_IF_Error("PCIEDMA_IF: write64 failed! \n"));
    }
}

uint8_t PCIEDMA_IF::readConfig8(uint32_t offset)
{
    struct rw_ioctl rw;
    uint8_t val;
    rw.reg = offset;
    rw.value = 0;
    if (ioctl(hDev, IOCTL_PCIE_CFG_REG_READ_8Bit, &rw) != 0)
    {
        throw(PCIEDMA_IF_Error("PCIEDMA_IF: readConfig8 failed! \n"));
    }
    
    val = (uint8_t)rw.value;

    return(val);
}
    
void PCIEDMA_IF::writeConfig8(uint32_t offset, uint8_t val)
{
    struct rw_ioctl rw;
    
    rw.reg = offset;
    rw.value = val;

    if (ioctl(hDev, IOCTL_PCIE_CFG_REG_WRITE_8Bit, &rw) != 0)
    {
        throw(PCIEDMA_IF_Error("PCIEDMA_IF: writeConfig8 failed! \n"));
    }

}

uint16_t PCIEDMA_IF::readConfig16(uint32_t offset)
{
    struct rw_ioctl rw;
    uint16_t val;
    rw.reg = offset;
    rw.value = 0;
    if (ioctl(hDev, IOCTL_PCIE_CFG_REG_READ_16Bit, &rw) != 0)
    {
        throw(PCIEDMA_IF_Error("PCIEDMA_IF: readConfig16 failed! \n"));
    }
    
    val = (uint16_t)rw.value;

    return(val);
}
    
void PCIEDMA_IF::writeConfig16(uint32_t offset, uint16_t val)
{
    struct rw_ioctl rw;
    
    rw.reg = offset;
    rw.value = val;

    if (ioctl(hDev, IOCTL_PCIE_CFG_REG_WRITE_16Bit, &rw) != 0)
    {
        throw(PCIEDMA_IF_Error("PCIEDMA_IF: writeConfig16 failed! \n"));
    }

}

uint32_t PCIEDMA_IF::readConfig32(uint32_t offset)
{
    struct rw_ioctl rw;
    uint32_t val;
    rw.reg = offset;
    rw.value = 0;
    if (ioctl(hDev, IOCTL_PCIE_CFG_REG_READ_32Bit, &rw) != 0)
    {
        throw(PCIEDMA_IF_Error("PCIEDMA_IF: readConfig32 failed! \n"));
    }
    
    val = (uint32_t)rw.value;

    return(val);
}
    
void PCIEDMA_IF::writeConfig32(uint32_t offset, uint32_t val)
{
    struct rw_ioctl rw;
    
    rw.reg = offset;
    rw.value = val;

    if (ioctl(hDev, IOCTL_PCIE_CFG_REG_WRITE_32Bit, &rw) != 0)
    {
        throw(PCIEDMA_IF_Error("PCIEDMA_IF: writeConfig32 failed! \n"));
    }

}

int PCIEDMA_IF::dmaGenDescriptor(struct dma_ubuf_ioctl_arg *arg)
{
	if(ioctl(hDev, IOCTL_PCIEDMA_GEN_DESC, arg) < 0)
		throw(PCIEDMA_IF_Error("PCIEDMA_IF: dma generate descriptor failed! \n"));
    
    return 0;
}

int PCIEDMA_IF::dmaStart(uint8_t direction)
{
	if(ioctl(hDev, IOCTL_PCIEDMA_START, &direction) < 0)
		throw(PCIEDMA_IF_Error("PCIEDMA_IF: dma start failed! \n"));

    return 0;
}

int PCIEDMA_IF::dmaStop(uint8_t direction)
{
	if(ioctl(hDev, IOCTL_PCIEDMA_STOP, &direction) < 0)
		throw(PCIEDMA_IF_Error("PCIEDMA_IF: dma stop failed! \n"));

    return 0;
}

int PCIEDMA_IF::dmaStartWaitCompletionWithStatus(struct dma_status_ioctl_arg *status_arg)
{
	if (ioctl(hDev, IOCTL_PCIEDMA_START_WAIT_COMPLETION, status_arg) < 0)
		throw(PCIEDMA_IF_Error("PCIEDMA_IF: dma start wait completion failed! \n"));

	return 0;
}

int PCIEDMA_IF::dmaStatusGet(struct dma_status_ioctl_arg *status_arg)
{
	if(ioctl(hDev, IOCTL_PCIEDMA_STATUS_CHECK, status_arg) < 0)
		throw(PCIEDMA_IF_Error("PCIEDMA_IF: dma status check failed! \n"));
    
    return 0;
}

int PCIEDMA_IF::dmaGetDescInfo(struct dma_desc_info_ioctl_arg *info)
{
    if (ioctl(hDev, IOCTL_PCIEDMA_GET_DESC_INFO, info) < 0)
        throw(PCIEDMA_IF_Error("PCIEDMA_IF: dmaGetDescInfo failed! \n"));

    return 0;
}

int PCIEDMA_IF::dmaMeasureThroughput(struct dma_throughput_ioctl_arg *throughput_arg)
{
	if(ioctl(hDev, IOCTL_PCIEDMA_MEAS_THROUGHPUT, throughput_arg) < 0)
		throw(PCIEDMA_IF_Error("PCIEDMA_IF: dma measure throughput failed! \n"));

    return 0;
}

int PCIEDMA_IF::dmaCleanup(uint8_t direction)
{
	if(ioctl(hDev, IOCTL_PCIEDMA_CLEANUP, &direction) < 0)
		throw(PCIEDMA_IF_Error("PCIEDMA_IF: dma cleanup failed! \n"));
    
    return 0;
}


