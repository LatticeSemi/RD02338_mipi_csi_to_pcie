/* SPDX-License-Identifier: MIT */
/*   ==================================================================
 
     >>>>>>>>>>>>>>>>>>>>>>> COPYRIGHT NOTICE <<<<<<<<<<<<<<<<<<<<<<<<<
     ------------------------------------------------------------------
     Copyright (c) 2025 by Lattice Semiconductor Corporation
     ALL RIGHTS RESERVED
     ------------------------------------------------------------------
 
     DISCLAIMER:
 
    LATTICE MAKES NO WARRANTIES ON THIS FILE OR ITS CONTENTS,
    WHETHER EXPRESSED, IMPLIED, STATUTORY,
    OR IN ANY PROVISION OF THE LATTICE PROPEL LICENSE AGREEMENT OR
    COMMUNICATION WITH LICENSEE,
    AND LATTICE SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
    MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
    LATTICE DOES NOT WARRANT THAT THE FUNCTIONS CONTAINED HEREIN WILL MEET
    LICENSEE 'S REQUIREMENTS, OR THAT LICENSEE' S OPERATION OF ANY DEVICE,
    SOFTWARE OR SYSTEM USING THIS FILE OR ITS CONTENTS WILL BE
    UNINTERRUPTED OR ERROR FREE,
    OR THAT DEFECTS HEREIN WILL BE CORRECTED.
    LICENSEE ASSUMES RESPONSIBILITY FOR SELECTION OF MATERIALS TO ACHIEVE
    ITS INTENDED RESULTS, AND FOR THE PROPER INSTALLATION, USE,
    AND RESULTS OBTAINED THEREFROM.
    LICENSEE ASSUMES THE ENTIRE RISK OF THE FILE AND ITS CONTENTS PROVING
    DEFECTIVE OR FAILING TO PERFORM PROPERLY AND IN SUCH EVENT,
    LICENSEE SHALL ASSUME THE ENTIRE COST AND RISK OF ANY REPAIR, SERVICE,
    CORRECTION,
    OR ANY OTHER LIABILITIES OR DAMAGES CAUSED BY OR ASSOCIATED WITH THE
    SOFTWARE.IN NO EVENT SHALL LATTICE BE LIABLE TO ANY PARTY FOR DIRECT,
    INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES,
    INCLUDING LOST PROFITS,
    ARISING OUT OF THE USE OF THIS FILE OR ITS CONTENTS,
    EVEN IF LATTICE HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
    LATTICE 'S SOLE LIABILITY, AND LICENSEE' S SOLE REMEDY,
    IS SET FORTH ABOVE.
    LATTICE DOES NOT WARRANT OR REPRESENT THAT THIS FILE,
    ITS CONTENTS OR USE THEREOF DOES NOT INFRINGE ON THIRD PARTIES'
    INTELLECTUAL PROPERTY RIGHTS, INCLUDING ANY PATENT. IT IS THE USER' S
    RESPONSIBILITY TO VERIFY THE USER SOFTWARE DESIGN FOR CONSISTENCY AND
    FUNCTIONALITY THROUGH THE USE OF FORMAL SOFTWARE VALIDATION METHODS.
     ------------------------------------------------------------------
 
     ================================================================== */
 

#include <stdio.h>
#include <string.h>
#include <cstdint>
#include <iostream>
#include <exception>
#include <iomanip>
#include <sstream>
#include <vector>
#include <poll.h>
#include <cerrno>
#include <time.h>
#include <unistd.h>
#include <getopt.h>
#include <thread>
#include "lsc_pcie_if.h"
#include "lsc_pcie_regs.h"
#include "cap_check.h"
using namespace std;

#define DMA_ERROR (-1)

#define FPGA_RAM_SIZE_128K  0x20000  /* 128 KB */
#define FPGA_RAM_SIZE_64K   0x10000  /*  64 KB */

std::vector<uint32_t> pci_cap_ptrs;
PCIEDMA_IF *pDrvr;
static uint32_t fpga_ram_size = FPGA_RAM_SIZE_128K;

static bool g_quiet  = false;
static bool g_strict = false;

#define EXIT_OK      0
#define EXIT_FAIL    1
#define EXIT_USAGE   2
#define EXIT_DEVICE  3

#define LOGI(...) do { if (!g_quiet) printf(__VA_ARGS__); } while (0)
#define LOGE(...) do { fprintf(stderr, __VA_ARGS__); } while (0)

static uint32_t get_fpga_ram_size(uint16_t device_id) {
    
    switch (device_id) {
    case 0x9C25: return FPGA_RAM_SIZE_128K;
    case 0x9C1D: return FPGA_RAM_SIZE_64K;
    default:     return FPGA_RAM_SIZE_128K;
    }
}

/**
 * @brief Clamp an element count so the access stays within the BAR range.
 *
 * @param addr      Starting byte offset within the BAR.
 * @param count     Number of elements requested.
 * @param elem_size Size of each element in bytes (1, 2, 4, or 8).
 * @param bar_size  Total BAR size in bytes.
 * @param bar_num   BAR number (used in the warning message).
 * @return Adjusted count that fits within the BAR. May be 0.
 */
static size_t check_and_limit_write_count(uint64_t addr, size_t count, size_t elem_size,
                              uint64_t bar_size, int bar_num) {
    if ((addr + count * elem_size) > bar_size) {
        if (g_strict) {
            LOGE("Error: Write of %zu elements at 0x%lx exceeds BAR %d size (0x%lx).\n",
                   count, (unsigned long)addr, bar_num, (unsigned long)bar_size);
            return 0;
        }
        size_t orig = count;
        count = (bar_size - addr) / elem_size;
        printf("Write truncated: only %zu of %zu elements written to BAR %d at address 0x%lx.\n",
               count, orig, bar_num, (unsigned long)addr);
    }
    return count;
}

/**
 * @brief Sanitize a validation size for a given access type.
 *
 * Clamps the size to [minSize, maxSize] and rounds down to the nearest
 * multiple of the access width implied by @p type ('b'=1, 'w'=2, 'd'=4, 'q'=8).
 *
 * @param size     Requested size in bytes.
 * @param type     Access type character.
 * @param max_size Upper bound in bytes.
 * @return Adjusted size in bytes, or 0 if @p type is unknown.
 */
static size_t check_limits_for_size(size_t size, char type, size_t max_size) {
    int min_size;

    if (size > max_size) {
        printf("Set to maximum size of %zu bytes.\n", max_size);
        size = max_size;
    }

    switch (type) {
    case 'b': min_size = 1; break;
    case 'w': min_size = 2; break;
    case 'd': min_size = 4; break;
    case 'q': min_size = 8; break;
    default:
        printf("Unknown validation type: %c\n", type);
        return 0;
    }

    if (size < (size_t)min_size) {
        size = min_size;
        printf("Set to minimum size of %d bytes.\n", min_size);
    }

    if (size % min_size != 0) {
        size = (size / min_size) * min_size;
        printf("Size not divisible by %d. Rounded down to %zu bytes.\n", min_size, size);
    }

    return size;
}

/**
 * @brief Reads data from a specified BAR (Base Address Register) at a given offset and size.
 *
 * This function reads data from a device BAR memory using the specified BAR number, offset, 
 * and size. It supports 8-bit, 16-bit, 32-bit, and 64-bit reads. In strict
 * mode (CLI), an unsupported size is rejected. In menu mode, it defaults to
 * a 32-bit read.
 *
 * @param bar_num The BAR number to read from.
 * @param offset The offset within the BAR to read from.
 * @param size The size of the data to read (1, 2, 4, or 8 bytes).
 * @return 0 on success, -1 on error.
 */
static int read_bridge(uint8_t bar_num, uint32_t offset, uint8_t size)
{
    uint64_t data = 0;
    if (size == 8) {
        data = pDrvr->read64(bar_num, offset);  
    } else if (size == 4) {
        data = pDrvr->read32(bar_num, offset); 
    } else if (size == 2) {
        data = pDrvr->read16(bar_num, offset); 
    } else if (size == 1) {
        data = pDrvr->read8(bar_num, offset); 
    } else {
        if (g_strict) {
            LOGE("Error: Invalid data size %d. Must be 1, 2, 4, or 8.\n", size);
            return -1;
        }
        LOGE("Unknown data size %d. Defaulting to 32-bit read.\n", size);
        data = pDrvr->read32(bar_num, offset);    
    }
    if (g_quiet)
        printf("0x%lx\n", (unsigned long)data);
    else
        printf("\nRead %d-bit data from BAR%d offset 0x%x: 0x%lx\n",
               size * 8, bar_num, offset, (unsigned long)data);
    return 0;
}

/**
 * @brief Writes data to a specified BAR (Base Address Register) at a given offset and size.
 *
 * This function writes data to a device BAR memory using the specified BAR number, offset, 
 * size, and data. It supports 8-bit, 16-bit, 32-bit, and 64-bit writes. In
 * strict mode (CLI), an unsupported size is rejected. In menu mode, it
 * defaults to a 32-bit write.
 *
 * @param bar_num The BAR number to write to.
 * @param offset The offset within the BAR to write to.
 * @param size The size of the data to write (1, 2, 4, or 8 bytes).
 * @param data The data to be written.
 * @return 0 on success, -1 on error.
 */
static int write_bridge(uint8_t bar_num, uint32_t offset, uint8_t size, uint64_t data)
{
    if (size == 8) {
        pDrvr->write64(bar_num, offset, data); 
    } else if (size == 4) {
        pDrvr->write32(bar_num, offset, data);  
    } else if (size == 2) {
        pDrvr->write16(bar_num, offset, data);  
    } else if (size == 1) {
        pDrvr->write8(bar_num, offset, data);  
    } else {
        if (g_strict) {
            LOGE("Error: Invalid data size %d. Must be 1, 2, 4, or 8.\n", size);
            return -1;
        }
        LOGE("Unknown data size %d. Defaulting to 32-bit write.\n", size);
        pDrvr->write32(bar_num, offset, data);  
    }
    LOGI("\nWrote %d-bit data 0x%lx to BAR%d offset 0x%x\n",size*8, data, bar_num, offset);
    return 0;
}

/**
 * Format a buffer of 8 bit values (bytes) into a displayable text string.
 *
 *  00000000: 55 66 77 ...
 *  00000010: a0 b0 c0 ...
 * 
 * @param ostr the caller supplied string to return the formatted bytes in
 * @param startAddr the starting address of the data, used in address field of format
 * @param len the number of bytes to format
 * @param data the array of bytes to process
 * @return true if successful, false if error encountered
 */
bool formatBlockOfBytes(std::string &ostr, uint32_t startAddr, uint32_t len, const std::vector<uint8_t> &data) {
    if (data.empty() || len == 0) {
        return false;
    }
    std::ostringstream oss;
    uint32_t addr = startAddr & 0xFFFFFFF0; // Align address to 16-byte boundary
    uint32_t offset = startAddr - addr;    // Offset within the first line
    uint32_t totalLen = len + offset;     // Adjust length to account for alignment
    if (totalLen > 0xFFFFFFF0) { // Prevent overflow
        return false;
    }
    for (uint32_t i = 0; i < totalLen; ++i) {
        if (i % 16 == 0) { // Start a new line
            if (i > 0) {
                oss << "\n";
            }
            oss << std::hex << std::noshowbase << std::setw(8) << std::setfill('0') << addr << ":";
            addr += 16;
        }
        if (i < offset || i - offset >= len || i - offset >= data.size()) {
            // Fill blank spaces for alignment
            oss << "   ";
        } else {
            // Append the byte in hex format
            oss << " " << std::hex << std::noshowbase << std::setw(2) << std::setfill('0') << static_cast<int>(data[i - offset]);
        }
    }
    oss << "\n";
    ostr = oss.str();
    printf("%s", ostr.c_str());
    return true;
}


/**
 * Format a buffer of 16 bit values (words) into a displayable text string.
 *
 *  00000000: 5566 7788 ...
 *  00000010: a0b0 c0d0 ...
 * 
 * @param ostr the caller supplied string to return the formatted shorts in
 * @param startAddr the starting address of the data, used in address field of format
 * @param len the number of shorts to format
 * @param data the array of shorts to process
 * @return true if successful, false if error encountered
 */
bool formatBlockOfWords(std::string &ostr, uint32_t startAddr, uint32_t len, const std::vector<uint16_t> &data) {
    if (data.empty() || len == 0) {
        return false;
    }
    std::ostringstream oss;
    uint32_t addr = startAddr & 0xFFFFFFF0; 
    uint32_t offset = (startAddr - addr) / sizeof(uint16_t); 
    uint32_t totalLen = len + offset; 
    if (totalLen > 0xFFFFFFF0 / sizeof(uint16_t)) { 
        return false;
    }
    for (uint32_t i = 0; i < totalLen; ++i) {
        if (i % 8 == 0) { 
            if (i > 0) {
                oss << "\n";
            }
            oss << std::hex << std::noshowbase << std::setw(8) << std::setfill('0') << addr << ":";
            addr += 16;
        }
        if (i < offset || i - offset >= len || i - offset >= data.size()) {
            oss << "     ";  // 5 spaces to match " NNNN" format (1 space + 4 hex digits)
        } else {
            oss << " " << std::hex << std::noshowbase << std::setw(4) << std::setfill('0') << data[i - offset];
        }
    }
    oss << "\n";
    ostr = oss.str();
    printf("%s", ostr.c_str());
    return true;
}


/**
 * Format a buffer of 32 bit values (dwords) into a displayable text string.
 *
 *  00000000: 55667788 ...
 *  00000010: a0b0c0d0 aabbccdd 11223344 ...
 * 
 * @param ostr the caller supplied string to return the formatted words in
 * @param startAddr the starting address of the data, used in address field of format
 * @param len the number of words to format
 * @param data the array of words to process
 * @return true if successful, false if error encountered
 */
bool formatBlockOfDWords(std::string &ostr, uint32_t startAddr, uint32_t len, const std::vector<uint32_t> &data) {
   if (data.empty() || len == 0) {
        return false;
    }
    std::ostringstream oss;
    uint32_t addr = startAddr & 0xFFFFFFF0; 
    uint32_t offset = (startAddr - addr) / sizeof(uint32_t); 
    uint32_t totalLen = len + offset;
    if (totalLen > 0xFFFFFFF0 / sizeof(uint32_t)) {
        return false;
    }
    for (uint32_t i = 0; i < totalLen; ++i) {
        if (i % 4 == 0) {
            if (i > 0) {
                oss << "\n";
            }
            oss << std::hex << std::noshowbase << std::setw(8) << std::setfill('0') << addr << ":";
            addr += 16;
        }
        if (i < offset || i - offset >= len || i - offset >= data.size()) {
            oss << "         ";
        } else {
            oss << " " << std::hex << std::noshowbase << std::setw(8) << std::setfill('0') << data[i - offset];
        }
    }
    oss << "\n";
    ostr = oss.str();
    printf("%s", ostr.c_str());
    return true;
}

/**
 * Format a buffer of 64 bit values (qwords) into a displayable text string.
 *
 *  00000000: 1122334455667788 ...
 *  00000010: a0b0c0d0aabbccdd 1122334455667788 ...
 * 
 * @param ostr the caller supplied string to return the formatted words in
 * @param startAddr the starting address of the data, used in address field of format
 * @param len the number of words to format
 * @param data the array of words to process
 * @return true if successful, false if error encountered
 */
bool formatBlockOfQWords(std::string &ostr, uint32_t startAddr, uint32_t len, const std::vector<uint64_t> &data) {
    if (data.empty() || len == 0) {
        return false;
    }
    std::ostringstream oss;
    uint32_t addr = startAddr & 0xFFFFFFF0; 
    uint32_t offset = (startAddr - addr) / sizeof(uint64_t); 
    uint32_t totalLen = len + offset; 
    if (totalLen > 0xFFFFFFF0 / sizeof(uint64_t)) {
        return false;
    }
    for (uint32_t i = 0; i < totalLen; ++i) {
        if (i % 2 == 0) {
            if (i > 0) {
                oss << "\n";
            }
            oss << std::hex << std::noshowbase << std::setw(8) << std::setfill('0') << addr << ":";
            addr += 16;
        }
        if (i < offset || i - offset >= len || i - offset >= data.size()) {
            oss << "                 ";
        } else {
            oss << " " << std::hex << std::noshowbase << std::setw(16) << std::setfill('0') << data[i - offset];
        }
    }
    oss << "\n";
    ostr = oss.str();
    printf("%s", ostr.c_str());

    return true;
}

/**
 * @brief Validates memory by writing and reading data to/from a specified BAR.
 *
 * This function performs memory validation by writing a sequence of values to a device BAR 
 * memory at a specified BAR and offset, then reading the values back and comparing them. 
 * It supports 8-bit, 16-bit, 32-bit, and 64-bit modes. For invalid modes, it exits with an 
 * error message. Returns the validation status and populates the read buffer via pointer parameter.
 *
 * @param bar_num The BAR number to validate memory on.
 * @param size The total size of the memory region to validate.
 * @param mode The access mode (1 for 8-bit, 2 for 16-bit, 4 for 32-bit, 8 for 64-bit).
 * @param readBuf Pointer to vector that will be populated with read data (only on success).
 * @return bool indicating success (true) or failure (false).
 */
static bool validate_memory(int bar_num, size_t size, int mode, std::vector<uint64_t>* readBuf,
                            uint32_t base_addr = 0) {
    
    // Size validation is done by the caller before calling this function
    size_t numInts = size / mode;
    
    bool match = true;
    std::vector<uint64_t> writeBuf(numInts);
    
    // Resize output buffer to hold read data
    if (readBuf) {
        readBuf->resize(numInts);
    }
    uint64_t mask = ((uint64_t)1 << (mode * 8)) - 1;
    for (size_t i = 0; i < numInts; i++) {
        writeBuf[i] = (uint64_t)i & mask;
    }
    for (size_t i = 0; i < numInts; i++) {
        uint32_t addr = base_addr + (uint32_t)(i * mode);
        if (mode == 1) {
            pDrvr->write8(bar_num, addr, writeBuf[i]);
        } else if (mode == 2) {
            pDrvr->write16(bar_num, addr, writeBuf[i]);
        } else if (mode == 4) {
            pDrvr->write32(bar_num, addr, writeBuf[i]);
        } else if (mode == 8) {
            pDrvr->write64(bar_num, addr, writeBuf[i]);
        }
    }
    // Read data directly into output buffer and compare
    if (!readBuf) {
        LOGE("Error: readBuf pointer is null.\n");
        return false;
    }
    
    for (size_t i = 0; i < numInts; i++) {
        uint32_t addr = base_addr + (uint32_t)(i * mode);
        if (mode == 1) {
            (*readBuf)[i] = pDrvr->read8(bar_num, addr);
        } else if (mode == 2) {
            (*readBuf)[i] = pDrvr->read16(bar_num, addr);
        } else if (mode == 4) {
            (*readBuf)[i] = pDrvr->read32(bar_num, addr);
        } else if (mode == 8) {
            (*readBuf)[i] = pDrvr->read64(bar_num, addr);
        }
    }
    // Compare the buffers
    for (size_t i = 0; i < numInts; i++) {
        if (writeBuf[i] != (*readBuf)[i]) {
            printf("Mismatch at offset 0x%x: wrote 0x%lx, read 0x%lx\n",
                   base_addr + (uint32_t)(i * mode), writeBuf[i], (*readBuf)[i]);
            match = false;
        }
    }
    if (match) {
        printf("Memory validation successful: all [%zu bytes] values match.\n", size);
        return true;  // Return success status
    } else {
        printf("Memory validation failed: mismatches found.\n");
        // Clear output buffer on failure - don't return data for display
        if (readBuf) {
            readBuf->clear();
        }
        return false;  // Return failure status
    }
}

/**
 * @brief Get the device mode.
 *
 * This function reads the device mode (TLP, BRIDGE or DMA) from the kernel driver
 * and returns the value.
 * @return device mode value
 */
deviceMode_t getDeviceMode(void) 
{
    int mode = pDrvr->getPCIeDeviceMode();
    //printf("Device Mode: ");
    
    switch (mode) {
        case TLP:
            LOGI("TLP Mode\n");
            return TLP;
        case BRIDGE_MSI:
            LOGI("Bridge Mode (MSI)\n");
            return BRIDGE_MSI;
        case BRIDGE_MSIX:
            LOGI("Bridge Mode (MSI-X)\n");
            return BRIDGE_MSIX;
        case DMA_AXI_S:
            LOGI("DMA AXI S Mode\n");
            return DMA_AXI_S;
        case DMA:
            LOGI("DMA Mode\n");
            return DMA;
        case AXI_BRIDGE:
            LOGI("AXI Bridge Mode\n");
            return AXI_BRIDGE;
        default:
            if (mode < 0) {
                LOGE("Error reading device mode!\n");
            } else {
                LOGE("Unknown device mode: %d\n", mode);
            }
            return TLP;  //default to TLP when error
    }
}

/**
 * @brief Configures a user interrupt with a specific MSI vector value.
 *
 * This function sets the MSI vector value for a user interrupt in bridge mode.
 * The user interrupt number must be between 0 and 15, and the vector value 
 * must be between 0 and 31.
 *
 * @param usr_int The user interrupt number (0-15).
 * @param vec_val The MSI vector value (0-31).
 */
void confUsrInt(uint8_t usr_int, uint8_t vec_val)
{
    pDrvr->setUserIntMSIVector(usr_int, vec_val);
}

/**
 * @brief Validates DMA transfer size; may round down to dword alignment (in-out).
 *
 * Checks non-zero and size vs FPGA RAM first, then clears low bits of
 * transfer_size to match DMA_XFER_LEN_ALIGN (same as kernel) and prints if adjusted.
 *
 * @param fpga_ram_size Full FPGA RAM size in bytes (used as max for single-direction).
 * @param transfer_size In/out: requested size; updated when rounded down.
 * @param bidirectional If true, max allowed transfer is fpga_ram_size/2 (H2F and F2H each use a region).
 * @return true if valid, false otherwise.
 */
static bool validate_transfer_size(size_t fpga_ram_size, size_t &transfer_size,
                                   bool bidirectional = false) {
    const size_t max_transfer =
        bidirectional ? (fpga_ram_size / 2) : fpga_ram_size;

    if (transfer_size == 0) {
        LOGE("Error: Transfer size must be non-zero.\n");
        return false;
    }
    if (transfer_size > max_transfer) {
        if (g_strict) {
            LOGE("Error: Transfer size 0x%zx exceeds %s (0x%zx).\n",
                   transfer_size,
                   bidirectional ? "half FPGA RAM (bidirectional)" : "FPGA RAM size",
                   max_transfer);
            return false;
        }
        printf("Transfer size (0x%zx) exceeds %s (0x%zx) -> adjusted to 0x%zx\n",
               transfer_size,
               bidirectional ? "half FPGA RAM (bidirectional)" : "FPGA RAM size",
               max_transfer, max_transfer);
        transfer_size = max_transfer;
    }

    const size_t mask = (size_t)(DMA_XFER_LEN_ALIGN - 1);

    if (transfer_size & mask) {
        if (g_strict) {
            LOGE("Error: Transfer size 0x%zx is not %u-byte aligned.\n",
                   transfer_size, (unsigned)DMA_XFER_LEN_ALIGN);
            return false;
        }
        /* Round down to nearest DMA_XFER_LEN_ALIGN boundary. */
        size_t adjusted = transfer_size & ~mask;

        if (adjusted == 0)
            adjusted = (size_t)DMA_XFER_LEN_ALIGN;
        printf("Transfer size adjusted: 0x%zx -> 0x%zx (%u-byte / %u-DW aligned)\n",
               transfer_size, adjusted, (unsigned)DMA_XFER_LEN_ALIGN,
               (unsigned)(DMA_XFER_LEN_ALIGN / 4U));
        transfer_size = adjusted;
    }
    return true;
}

/**
 * @brief Validates FPGA address based on transfer size and FPGA RAM size limit.
 *
 * The FPGA RAM is limited to 128KB (0x20000). For a given transfer_size,
 * the fpga_addr must satisfy: fpga_addr + transfer_size <= 0x20000.
 * This means the valid range for fpga_addr is 0 to (0x20000 - transfer_size).
 *
 * @param fpga_ram_size The FPGA RAM size limit in bytes.
 * @param transfer_size The size of the DMA transfer in bytes.
 * @param fpga_addr The FPGA address to validate (passed by reference for potential modification).
 * @return true if fpga_addr is valid, false if transfer_size itself exceeds fpga_ram_size.
 */
static bool validate_fpga_addr(size_t fpga_ram_size, size_t transfer_size, uint64_t &fpga_addr) {
    // Calculate maximum valid FPGA address
    uint64_t max_fpga_addr = fpga_ram_size - transfer_size;
    
    const uint64_t DW8_ALIGNMENT = DMA_FPGA_ADDR_8DW_ALIGN;
    const uint64_t DW8_ALIGN_MASK = ~(DW8_ALIGNMENT - 1);

    if (g_strict) {
        if (fpga_addr & (DW8_ALIGNMENT - 1)) {
            LOGE("Error: FPGA address 0x%lx is not %lu-byte aligned.\n",
                 (unsigned long)fpga_addr, (unsigned long)DW8_ALIGNMENT);
            return false;
        }
        if (fpga_addr > max_fpga_addr) {
            LOGE("Error: FPGA address 0x%lx + transfer size 0x%zx exceeds FPGA RAM (0x%x).\n",
                 (unsigned long)fpga_addr, transfer_size, (unsigned)fpga_ram_size);
            return false;
        }
        return true;
    }

    // Align address to 8DW boundary (round down)
    uint64_t aligned_addr = fpga_addr & DW8_ALIGN_MASK;

    // If aligned address exceeds max, round down to max valid 8DW-aligned address
    if (aligned_addr > max_fpga_addr) {
        aligned_addr = max_fpga_addr & DW8_ALIGN_MASK;
    }

    // Report adjustment if address was changed
    if (aligned_addr != fpga_addr) {
        printf("FPGA address adjusted: 0x%lx -> 0x%lx (8DW aligned)\n", 
               fpga_addr, aligned_addr);
    }

    fpga_addr = aligned_addr;
    return true;
}

/**
 * @brief Parse a string as an unsigned 64-bit integer, rejecting trailing junk.
 *
 * @param str    Input string (e.g. argv[N]).
 * @param[out] out  Parsed value on success.
 * @param label  Name shown in the error message (e.g. "transfer size").
 * @return true on success, false if the string is empty or has trailing characters.
 */
static bool parse_uint64(const char *str, uint64_t &out, const char *label) {
    char *end;
    out = strtoull(str, &end, 0);
    if (end == str || *end != '\0') {
        LOGE("Invalid %s: %s\n", label, str);
        return false;
    }
    return true;
}

/**
 * @brief Parse a string as a signed integer, rejecting trailing junk.
 *
 * @param str    Input string (e.g. argv[N]).
 * @param[out] out  Parsed value on success.
 * @param label  Name shown in the error message (e.g. "iterations").
 * @return true on success, false if the string is empty or has trailing characters.
 */
static bool parse_int(const char *str, int &out, const char *label) {
    char *end;
    long val = strtol(str, &end, 0);
    if (end == str || *end != '\0') {
        LOGE("Invalid %s: %s\n", label, str);
        return false;
    }
    out = (int)val;
    return true;
}

/**
 * @brief Validates iteration/duration count.
 *
 * In ring mode (is_ring=true), 0 is accepted (means run indefinitely).
 * In normal mode, the value must be at least 1.
 *
 * @param count The iteration or duration count to validate.
 * @param is_ring If true, 0 is valid (infinite run); negative is rejected.
 * @return true if valid, false otherwise.
 */
static bool validate_iterations(int count, bool is_ring = false) {
    if (is_ring) {
        if (count < 0) {
            LOGE("Invalid duration: %d. Must be 0 or greater.\n", count);
            return false;
        }
    } else {
        if (count < 1) {
            LOGE("Invalid iterations: %d. Must be at least 1.\n", count);
            return false;
        }
    }
    return true;
}

/**
 * @brief Fills a buffer byte-by-byte with incremental counter data starting from 0.
 *
 * Fills the buffer with incrementing counter values: 0, 1, 2, 3, ..., wrapping at 255.
 *
 * @param buffer Pointer to the buffer to fill.
 * @param size Size of the buffer in bytes.
 */
static void fill_buffer_with_pattern(void* buffer, size_t size) {
    uint8_t* buf8 = static_cast<uint8_t*>(buffer);
    
    // Fill with counter pattern byte-by-byte: 0, 1, 2, 3, ...
    for (size_t i = 0; i < size; i++) {
        buf8[i] = static_cast<uint8_t>(i & 0xFF);
    }
}

/**
 * @brief Initializes DMA by allocating buffers and generating descriptors.
 *
 * Allocates aligned buffers, fills them with pattern data for H2F direction,
 * and generates DMA descriptors via IOCTL.
 *
 * @param buffer Reference to vector of buffer pointers (must be pre-sized to num_buffers, will be populated).
 * @param num_buffers Number of buffers to allocate.
 * @param direction DMA transfer direction (DMA_DIR_H2F or DMA_DIR_F2H).
 * @param transfer_size Size of each buffer in bytes.
 * @param fpgaAddr FPGA address (source for F2H, destination for H2F).
 * @param ring_mode If true, use ring (circular) buffer mode for continuous DMA transfers.
 * @return 0 on success, DMA_ERROR on failure.
 */
static int dma_init(std::vector<void*>& buffer, uint8_t num_buffers, enum dma_direction direction, size_t transfer_size, uint64_t fpgaAddr, bool ring_mode = false) {
    
    if (buffer.size() < num_buffers) {
        LOGE("Error: Buffer vector size (%zu) is less than num_buffers (%d).\n", buffer.size(), num_buffers);
        return DMA_ERROR;
    }
    
    struct dma_ubuf_ioctl_arg userptr_arg;
    
    // Allocate buffers
    for (uint8_t i = 0; i < num_buffers; i++) {
        buffer[i] = aligned_alloc(4096, transfer_size);
        if (buffer[i] == nullptr) {
            LOGE("Failed to allocate buffer %d.\n", i);
            // Clean up previously allocated buffers
            for (uint8_t j = 0; j < i; j++) {
                free(buffer[j]);
                buffer[j] = nullptr;
            }
            return DMA_ERROR;
        }
        memset(buffer[i], 0, transfer_size);

        // Fill buffers with pattern for H2F direction
        if (direction == DMA_DIR_H2F) 
            fill_buffer_with_pattern(buffer[i], transfer_size);
    }

    userptr_arg.addr = buffer.data(); //returns address of buffer[0]
	userptr_arg.len = transfer_size;
	userptr_arg.buf_cnt = num_buffers;
	userptr_arg.dir = direction;  
	userptr_arg.circ_buf = ring_mode ? 1 : 0;
	userptr_arg.fpga_addr = fpgaAddr;

    try {
        pDrvr->dmaGenDescriptor(&userptr_arg);
    } catch (...) {
        LOGE("DMA descriptor generation failed.\n");
        for (uint8_t j = 0; j < num_buffers; j++) {
            free(buffer[j]);
            buffer[j] = nullptr;
        }
        return DMA_ERROR;
    }

    return 0;
}

/**
 * @brief Cleans up DMA resources by releasing driver resources and freeing allocated buffers.
 *
 * First releases kernel-side DMA resources (descriptors, SG mappings, pinned pages)
 * via the driver, then frees all user-space buffers allocated during DMA initialization.
 * This should be called after DMA transfers are complete.
 *
 * @param buffer Reference to vector of buffer pointers to free.
 * @param num_buffers Number of buffers in the vector.
 * @param direction DMA transfer direction (DMA_DIR_H2F or DMA_DIR_F2H).
 * @return 0 on success, DMA_ERROR on failure.
 */
static int dma_cleanup(std::vector<void*>& buffer, uint8_t num_buffers, enum dma_direction direction) {
    int ret = 0;

    // Release driver-side DMA resources (descriptors, SG mappings, pinned pages)
    try {
        pDrvr->dmaCleanup((uint8_t)direction);
    } catch (...) {
        LOGE("Driver DMA cleanup failed.\n");
        ret = DMA_ERROR;
    }

    // Free all user-space allocated buffers
    for (uint8_t i = 0; i < num_buffers; i++) {
        if (buffer[i] != nullptr) {
            free(buffer[i]);
            buffer[i] = nullptr;
        }
    }
    
    // Clear the vector
    buffer.clear();
    
    return ret;
}

/**
 * @brief Starts DMA and waits for completion, returning raw status.
 *
 * @param direction DMA transfer direction (DMA_DIR_H2F or DMA_DIR_F2H).
 * @param[out] status_arg Populated with DMA completion status from the driver.
 * @param timeout_ms Timeout in milliseconds (0 = driver default of 1000 ms).
 * @return 0 on success, DMA_ERROR on ioctl/exception failure.
 */
static int dma_start_wait_completion(enum dma_direction direction,
                                     struct dma_status_ioctl_arg *status_arg,
                                     uint32_t timeout_ms = 0) {
    memset(status_arg, 0, sizeof(*status_arg));
    status_arg->dir = (uint8_t)direction;
    status_arg->timeout_ms = timeout_ms;

    try {
        pDrvr->dmaStartWaitCompletionWithStatus(status_arg);
    } catch (const std::exception &e) {
        LOGE("DMA %s transfer exception: %s\n",
             (direction == DMA_DIR_H2F) ? "H2F" : "F2H", e.what());
        return DMA_ERROR;
    }

    return 0;
}

/**
 * @brief Validates DMA completion status and prints results.
 *
 * Checks dma_error flag and compares completed vs expected descriptor count.
 *
 * @param status_arg DMA status returned by dma_start_wait_completion.
 * @param direction DMA transfer direction (for logging).
 * @param iter Current iteration number (1-based, for logging).
 * @param total_iters Total number of iterations (for logging).
 * @return 0 on success, DMA_ERROR on failure.
 */
static int dma_validate_status(const struct dma_status_ioctl_arg *status_arg,
                               enum dma_direction direction,
                               int iter, int total_iters) {
    const char *dir_str = (direction == DMA_DIR_H2F) ? "H2F" : "F2H";

    int err = 0;

    if (status_arg->dma_error) {
        LOGE("  [Iter %d/%d] DMA %s FAILED - status_reg: 0x%08X\n",
             iter, total_iters, dir_str, status_arg->status_reg);
        err = DMA_ERROR;
    }

    if (status_arg->completed_desc_cnt != status_arg->expected_desc_cnt) {
        LOGE("  [Iter %d/%d] %s descriptor count MISMATCH: expected=%u, completed=%u\n",
             iter, total_iters, dir_str,
             status_arg->expected_desc_cnt, status_arg->completed_desc_cnt);
        err = DMA_ERROR;
    }

    if (err == 0)
        LOGI("  [Iter %d/%d] %s DMA transfer success.\n", iter, total_iters, dir_str);

    return err;
}

/**
 * @brief Performs a single DMA transfer (H2F or F2H) over multiple iterations.
 *
 * Allocates buffers and generates descriptors once, then executes the specified
 * number of DMA transfers reusing the same descriptors. Validates descriptor
 * count and checks DMA status after each transfer.
 *
 * @param transfer_size Size of each transfer in bytes.
 * @param direction DMA transfer direction (DMA_DIR_H2F or DMA_DIR_F2H).
 * @param fpga_addr FPGA address (source for F2H, destination for H2F).
 * @param iterations Number of transfers to perform (default 1).
 * @return 0 on success, DMA_ERROR on failure.
 */
static int dma_run_single_direction(size_t transfer_size, enum dma_direction direction, uint64_t fpgaAddr, int iterations) {
    
    int ret = 0;
    uint8_t num_buffers = 1;
    std::vector<void*> buffer(num_buffers);
    const char *dir_str = (direction == DMA_DIR_H2F) ? "H2F" : "F2H";
    
    int status = dma_init(buffer, num_buffers, direction, transfer_size, fpgaAddr);
    if (status != 0) {
        LOGE("DMA initialization failed.\n");
        /* Do not need to call dma_cleanup here as failure may be due to failed descriptor generation */
        /* where descriptor not allocated and buffer has been freed in dma_init. */
        return DMA_ERROR; 
    }

    struct dma_status_ioctl_arg status_arg;
    for (int j = 0; j < iterations; j++) {
        ret = dma_start_wait_completion(direction, &status_arg);
        if (ret != 0)
            break;
        ret = dma_validate_status(&status_arg, direction, j + 1, iterations);
    }
    
    if (ret == 0 && direction == DMA_DIR_F2H && !g_quiet) {
        printf("Display F2H DMA received data? (y/n): ");
        std::string response;
        std::getline(std::cin, response);
        if (!response.empty() && (response[0] == 'y' || response[0] == 'Y')) {
            uint8_t *buf8 = static_cast<uint8_t *>(buffer[0]);
            std::vector<uint8_t> data(buf8, buf8 + transfer_size);
            std::string results;
            formatBlockOfBytes(results, fpgaAddr, transfer_size, data);
        }
    }

    if (ret == 0)
        LOGI("DMA %s: all %d transfer(s) completed successfully.\n", dir_str, iterations);
        
    status = dma_cleanup(buffer, num_buffers, direction);
    if (status != 0) {
        LOGE("DMA cleanup failed. Quit application, unload and reload driver, then re-start application to recover.\n");
        if (ret == 0)
            ret = DMA_ERROR;
    }
    
    return ret;
}

/**
 * @brief Verify that a buffer contains an incrementing byte pattern (0x00..0xFF wrap).
 *
 * The sequence does not have to start at 0; the first byte sets the expected
 * starting point and each subsequent byte must be (prev + 1) mod 256.
 *
 * @param buf      Pointer to the received data.
 * @param len      Number of bytes to check.
 * @param iter     Current iteration number (1-based, for messages).
 * @param total    Total iterations (for messages).
 * @return 0 if the pattern is valid, DMA_ERROR on mismatch.
 */
static int verify_incremental_pattern(const uint8_t *buf, size_t len,
                                      int iter, int total) {
    if (len == 0)
        return 0;

    uint8_t expected = buf[0];
    size_t mismatch_count = 0;
    size_t first_mismatch = 0;

    for (size_t i = 0; i < len; i++) {
        if (buf[i] != expected) {
            if (mismatch_count == 0)
                first_mismatch = i;
            mismatch_count++;
        }
        expected = (expected + 1) & 0xFF;
    }

    if (mismatch_count > 0) {
        uint8_t exp_at_mismatch = (buf[0] + first_mismatch) & 0xFF;
        LOGE("  [Iter %d/%d] Incremental pattern MISMATCH: %zu of %zu bytes differ "
             "(first at offset %zu: expected=0x%02X, got=0x%02X)\n",
             iter, total, mismatch_count, len,
             first_mismatch, (unsigned)exp_at_mismatch,
             (unsigned)buf[first_mismatch]);
        return DMA_ERROR;
    }

    LOGI("  [Iter %d/%d] Incremental pattern verified OK (%zu bytes, start=0x%02X)\n",
         iter, total, len, (unsigned)buf[0]);
    return 0;
}

/**
 * @brief Performs sequential H2F then F2H DMA with data validation.
 *
 * In normal (AXI-MM) mode: allocates buffers for both directions, writes a known
 * pattern via H2F and reads it back via F2H, then compares byte-for-byte.
 *
 * In AXI_S mode: only F2H is used. The FPGA streams data autonomously, so there
 * is no H2F write. The received data is verified as an incrementing byte pattern
 * (0x00..0xFF wrapping) that may start at any value.
 *
 * @param transfer_size Size of each transfer in bytes.
 * @param iterations Number of loopback iterations to perform.
 * @param fpga_addr FPGA address for both H2F and F2H transfers (default 0).
 * @param mode Device operating mode.
 * @return 0 on success, DMA_ERROR on failure.
 */
static int dma_single_direction_data_compare(size_t transfer_size, int iterations,
                                             uint64_t fpga_addr,
                                             deviceMode_t mode) {

    bool is_axi_s = (mode == DMA_AXI_S);
    int ret = 0;
    uint8_t num_buffers = 1;
    std::vector<void*> h2f_buffer(num_buffers);
    std::vector<void*> f2h_buffer(num_buffers);
    int status;

    /* --- Initialize: AXI_S only needs F2H, AXI_MM needs both --- */
    if (!is_axi_s) {
        status = dma_init(h2f_buffer, num_buffers, DMA_DIR_H2F, transfer_size, fpga_addr);
        if (status != 0) {
            LOGE("H2F DMA init failed.\n");
            return DMA_ERROR;
        }
    }

    status = dma_init(f2h_buffer, num_buffers, DMA_DIR_F2H, transfer_size, fpga_addr);
    if (status != 0) {
        LOGE("F2H DMA init failed.\n");
        if (!is_axi_s)
            dma_cleanup(h2f_buffer, num_buffers, DMA_DIR_H2F);
        return DMA_ERROR;
    }

    struct dma_status_ioctl_arg h2f_status;
    struct dma_status_ioctl_arg f2h_status;
    for (int j = 0; j < iterations; j++) {

        if (!is_axi_s) {
            /* --- H2F: write known pattern to FPGA --- */
            ret = dma_start_wait_completion(DMA_DIR_H2F, &h2f_status);
            if (ret != 0)
                break;
            ret = dma_validate_status(&h2f_status, DMA_DIR_H2F, j + 1, iterations);
        }

        /* --- F2H: read data back from FPGA --- */
        ret = dma_start_wait_completion(DMA_DIR_F2H, &f2h_status);
        if (ret != 0)
            break;
        ret = dma_validate_status(&f2h_status, DMA_DIR_F2H, j + 1, iterations);

        /* --- Verify received data --- */
        uint8_t *rx_buf = static_cast<uint8_t *>(f2h_buffer[0]);

        if (is_axi_s) {
            ret = verify_incremental_pattern(rx_buf, transfer_size, j + 1, iterations);
            if (ret != 0)
                break;
        } else {
            size_t mismatch_count = 0;
            size_t first_mismatch = 0;

            for (size_t i = 0; i < transfer_size; i++) {
                uint8_t expected = static_cast<uint8_t>(i & 0xFF);
                if (rx_buf[i] != expected) {
                    if (mismatch_count == 0)
                        first_mismatch = i;
                    mismatch_count++;
                }
            }

            if (mismatch_count > 0) {
                LOGE("  [Iter %d/%d] Data MISMATCH: %zu of %zu bytes differ "
                     "(first at offset %zu: expected=0x%02X, got=0x%02X)\n",
                     j + 1, iterations, mismatch_count, transfer_size,
                     first_mismatch,
                     (unsigned)(first_mismatch & 0xFF),
                     (unsigned)rx_buf[first_mismatch]);
                ret = DMA_ERROR;
                break;
            }

            LOGI("  [Iter %d/%d] Data verified OK (%zu bytes match)\n",
                 j + 1, iterations, transfer_size);
        }
    }

    if (ret == 0)
        LOGI("DMA data validate: all %d iteration(s) PASSED.\n", iterations);

    /* --- Cleanup --- */
    if (!is_axi_s) {
        status = dma_cleanup(h2f_buffer, num_buffers, DMA_DIR_H2F);
        if (status != 0) {
            LOGE("H2F DMA cleanup failed. Restart application to recover.\n");
            if (ret == 0)
                ret = DMA_ERROR;
        }
    }

    status = dma_cleanup(f2h_buffer, num_buffers, DMA_DIR_F2H);
    if (status != 0) {
        LOGE("F2H DMA cleanup failed. Restart application to recover.\n");
        if (ret == 0)
            ret = DMA_ERROR;
    }

    return ret;
}

/**
 * @brief Measures DMA throughput for a single direction (H2F or F2H).
 *
 * Allocates a buffer and generates descriptors once with fpgaAddr=0, then
 * invokes the kernel driver to perform the specified number of back-to-back
 * DMA transfers and measure elapsed time. Calculates and prints throughput
 * in MB/s based on the returned timing data.
 *
 * @param transfer_size Size of each transfer in bytes.
 * @param direction DMA transfer direction (DMA_DIR_H2F or DMA_DIR_F2H).
 * @param iterations Number of DMA transfers to perform.
 * @return 0 on success, DMA_ERROR on failure.
 */
static int dma_meas_single_dir_throughput(size_t transfer_size, enum dma_direction direction, int iterations) {

    int status = 0;
    uint8_t num_buffers = 1;
    std::vector<void*> buffer(num_buffers);
    const char *dir_str = (direction == DMA_DIR_H2F) ? "H2F" : "F2H";

    status = dma_init(buffer, num_buffers, direction, transfer_size, 0);
    if (status != 0) {
        LOGE("DMA %s initialization failed.\n", dir_str);
        return DMA_ERROR;
    }

    struct dma_throughput_ioctl_arg throughput_arg;
    memset(&throughput_arg, 0, sizeof(throughput_arg));
    throughput_arg.dir = (uint8_t)direction;
    throughput_arg.iterations = iterations;

    try {
        pDrvr->dmaMeasureThroughput(&throughput_arg);
    } catch (...) {
        LOGE("DMA %s throughput measurement failed.\n", dir_str);
        dma_cleanup(buffer, num_buffers, direction);
        return DMA_ERROR;
    }

    uint64_t elapsed_ns = throughput_arg.end_time_in_ns - throughput_arg.start_time_in_ns;
    uint64_t total_bytes = (uint64_t)transfer_size * iterations;
    double elapsed_sec = (double)elapsed_ns / 1e9;
    double throughput_mbps = ((double)total_bytes / (1024.0 * 1024.0)) / elapsed_sec;

    if (g_quiet)
        printf("result=PASS cmd=%s throughput=%.2f size=0x%zx iterations=%d\n",
               (direction == DMA_DIR_H2F) ? "th" : "tf", throughput_mbps, transfer_size, iterations);
    else
        printf("DMA %s Throughput: %.2f MB/s (%d x %zu bytes in %.8f s)\n",
               dir_str, throughput_mbps, iterations, transfer_size, elapsed_sec);

    status = dma_cleanup(buffer, num_buffers, direction);
    if (status != 0) {
        LOGE("DMA %s cleanup failed.\n", dir_str);
        return DMA_ERROR;
    }

    return status;
}

/**
 * @brief Measures bidirectional DMA throughput using two threads.
 *
 * Initializes DMA for both H2F and F2H, then launches two threads that each
 * call dmaMeasureThroughput. Throughput is calculated from the start/end
 * times returned in the dma_throughput_ioctl_arg by the library.
 *
 * @param transfer_size Size of each transfer in bytes.
 * @param iterations Number of DMA transfers per direction.
 * @return 0 on success, DMA_ERROR on failure.
 */
static int dma_meas_bidirection_throughput(size_t transfer_size, int iterations) {

    uint8_t num_buffers = 1;
    std::vector<void*> h2f_buffer(num_buffers);
    std::vector<void*> f2h_buffer(num_buffers);
    int h2f_result = 0, f2h_result = 0;
    struct dma_throughput_ioctl_arg h2f_arg, f2h_arg;

    if (dma_init(h2f_buffer, num_buffers, DMA_DIR_H2F, transfer_size, 0) != 0) {
        LOGE("DMA H2F initialization failed.\n");
        return DMA_ERROR;
    }

    if (dma_init(f2h_buffer, num_buffers, DMA_DIR_F2H, transfer_size, fpga_ram_size/2) != 0) {
        LOGE("DMA F2H initialization failed.\n");
        dma_cleanup(h2f_buffer, num_buffers, DMA_DIR_H2F);
        return DMA_ERROR;
    }

    memset(&h2f_arg, 0, sizeof(h2f_arg));
    h2f_arg.dir = (uint8_t)DMA_DIR_H2F;
    h2f_arg.iterations = iterations;

    memset(&f2h_arg, 0, sizeof(f2h_arg));
    f2h_arg.dir = (uint8_t)DMA_DIR_F2H;
    f2h_arg.iterations = iterations;

    std::thread t_h2f([&]() {
        try {
            pDrvr->dmaMeasureThroughput(&h2f_arg);
        } catch (...) {
            h2f_result = DMA_ERROR;
        }
    });

    std::thread t_f2h([&]() {
        try {
            pDrvr->dmaMeasureThroughput(&f2h_arg);
        } catch (...) {
            f2h_result = DMA_ERROR;
        }
    });

    t_h2f.join();
    t_f2h.join();

    if (h2f_result == 0 && f2h_result == 0) {
        uint64_t total_bytes = (uint64_t)transfer_size * iterations;

        uint64_t elapsed_ns;
        double elapsed_sec, h2f_mbps, f2h_mbps;

        elapsed_ns = h2f_arg.end_time_in_ns - h2f_arg.start_time_in_ns;
        elapsed_sec = (double)elapsed_ns / 1e9;
        h2f_mbps = ((double)total_bytes / (1024.0 * 1024.0)) / elapsed_sec;

        elapsed_ns = f2h_arg.end_time_in_ns - f2h_arg.start_time_in_ns;
        elapsed_sec = (double)elapsed_ns / 1e9;
        f2h_mbps = ((double)total_bytes / (1024.0 * 1024.0)) / elapsed_sec;

        if (g_quiet) {
            printf("result=PASS cmd=tb h2f_throughput=%.2f f2h_throughput=%.2f size=0x%zx iterations=%d\n",
                   h2f_mbps, f2h_mbps, transfer_size, iterations);
        } else {
            printf("DMA H2F Throughput: %.2f MB/s (%d x %zu bytes in %.6f s)\n",
                   h2f_mbps, iterations, transfer_size, elapsed_sec);
            printf("DMA F2H Throughput: %.2f MB/s (%d x %zu bytes in %.6f s)\n",
                   f2h_mbps, iterations, transfer_size, elapsed_sec);
        }
    } else {
        LOGE("Bidirectional DMA failed: H2F=%d, F2H=%d\n", h2f_result, f2h_result);
    }

    dma_cleanup(h2f_buffer, num_buffers, DMA_DIR_H2F);
    dma_cleanup(f2h_buffer, num_buffers, DMA_DIR_F2H);

    return (h2f_result == 0 && f2h_result == 0) ? 0 : DMA_ERROR;
}

/**
 * @brief Measures DMA ring buffer throughput over a timed duration using descriptor count snapshots.
 *
 * Initializes DMA in ring buffer mode (circBuf=1), starts the transfer, then uses
 * poll() on stdin to wait for the specified duration while remaining responsive to
 * user cancellation. Reads the FPGA descriptor count register at start and end to
 * calculate throughput from the delta.
 *
 * @param transfer_size Size of each descriptor transfer in bytes.
 * @param direction DMA transfer direction (DMA_DIR_H2F or DMA_DIR_F2H).
 * @param duration_sec Measurement duration in seconds; 0 means run until user types 'c'.
 * @return 0 on success, DMA_ERROR on failure.
 */
static int dma_meas_ring_throughput(size_t transfer_size, enum dma_direction direction, int duration_sec) {

    int status = 0;
    uint8_t num_buffers = 1;
    std::vector<void*> buffer(num_buffers);
    const char *dir_str = (direction == DMA_DIR_H2F) ? "H2F" : "F2H";
    uint32_t count_start, count_end;
    uint32_t total_descriptors = 0;

    status = dma_init(buffer, num_buffers, direction, transfer_size, 0, true);
    if (status != 0) {
        LOGE("DMA %s ring initialization failed.\n", dir_str);
        return DMA_ERROR;
    }

    try {
        struct dma_desc_info_ioctl_arg desc_info = {};

        desc_info.dir = (uint8_t)direction;
        desc_info.buf_idx = 0;
        pDrvr->dmaGetDescInfo(&desc_info);
        total_descriptors = desc_info.total_descriptors;
        if (!desc_info.circ_buffer_on) {
            LOGE("DMA %s ring test requires circular-buffer mode (circ_buffer_on=0).\n", dir_str);
            dma_cleanup(buffer, num_buffers, direction);
            return DMA_ERROR;
        }
    } catch (...) {
        LOGE("DMA %s failed to get DMA transfer info.\n", dir_str);
        dma_cleanup(buffer, num_buffers, direction);
        return DMA_ERROR;
    }

    if (total_descriptors == 0) {
        LOGE("DMA %s total descriptor count is zero.\n", dir_str);
        dma_cleanup(buffer, num_buffers, direction);
        return DMA_ERROR;
    }

    /* Start DMA — in ring buffer mode, it runs continuously */
    try {
        pDrvr->dmaStart((uint8_t)direction);
    } catch (...) {
        LOGE("DMA %s ring start failed.\n", dir_str);
        dma_cleanup(buffer, num_buffers, direction);
        return DMA_ERROR;
    }

#if 1
    if (duration_sec == 0) {
        LOGI("Running DMA %s ring transfer until stopped (type 'c' + Enter)...\n", dir_str);
    } else {
        LOGI("Measuring DMA %s ring throughput for %d seconds... (type 'c' + Enter to cancel)\n",
             dir_str, duration_sec);
    }

    uint32_t desc_count_reg = (direction == DMA_DIR_H2F) ?
                               H2F_CPLT_DESC_COUNT_REG : F2H_CPLT_DESC_COUNT_REG;

    /* Snapshot start: read descriptor count register and record time back-to-back */
    struct timespec time_start, time_now;
    count_start = pDrvr->readReg32(desc_count_reg);
    clock_gettime(CLOCK_MONOTONIC, &time_start);

    /* Wait for duration_sec (or indefinitely if duration_sec == 0); wake on stdin */
    struct pollfd pfd;
    pfd.fd = STDIN_FILENO;
    pfd.events = POLLIN;
    bool cancelled = false;
    int timeout_ms = (duration_sec > 0) ? (duration_sec * 1000) : -1;

    while (true) {
        int poll_ret = poll(&pfd, 1, timeout_ms);

        if (poll_ret == 0)
            break;

        if (poll_ret < 0) {
            if (errno == EINTR)
                /* Skip the rest of this loop iteration; next iteration calls poll() again. */
                continue;
            perror("poll");
            break;
        }

        if (poll_ret > 0 && (pfd.revents & POLLIN)) {
            std::string input;
            std::getline(std::cin, input);
            if (input == "c") {
                cancelled = true;
                break;
            }
            if (duration_sec == 0)
                /* Infinite wait: skip timeout_ms recalculation below; poll again with -1. */
                continue;
        }

        clock_gettime(CLOCK_MONOTONIC, &time_now);
        timeout_ms = (int)((double)duration_sec * 1000.0 -
                           (double)(time_now.tv_sec - time_start.tv_sec) * 1000.0 -
                           (double)(time_now.tv_nsec - time_start.tv_nsec) / 1e6);
        if (timeout_ms <= 0)
            break;
    }

    if (cancelled) {
        if (duration_sec == 0) 
            LOGI("DMA %s ring transfer stopped.\n", dir_str);
        else
             LOGI("DMA %s ring throughput measurement cancelled.\n", dir_str);
    } else {
        /* Snapshot end: read descriptor count register and record time back-to-back */
        count_end = pDrvr->readReg32(desc_count_reg);
        clock_gettime(CLOCK_MONOTONIC, &time_now);

        /* Calculate throughput */
        double elapsed_sec = (double)(time_now.tv_sec - time_start.tv_sec) +
                             (double)(time_now.tv_nsec - time_start.tv_nsec) / 1e9;

        uint32_t desc_completed;
        if (count_end > count_start) {
            desc_completed = count_end - count_start;
            //LOGI("count_end %d, count_start %d\n", count_end,count_start);
        }
        else
            LOGE("Error count_end %d smaller than count_start %d\n", count_end,count_start);

        double cycles = (double)desc_completed / (double)total_descriptors;
        double total_bytes = cycles * (double)transfer_size;
        double throughput_mbps = (total_bytes / (1024.0 * 1024.0)) / elapsed_sec;

        if (g_quiet)
            printf("result=PASS cmd=%s throughput=%.2f size=0x%zx duration=%.3f\n",
                   (direction == DMA_DIR_H2F) ? "thr" : "tfr", throughput_mbps, transfer_size, elapsed_sec);
        else
            printf("DMA %s Ring Throughput: %.2f MB/s (%u descriptors, %.3f cycles, %.0f bytes in %.3f s)\n",
                   dir_str, throughput_mbps, desc_completed, cycles, total_bytes, elapsed_sec);
    }

#else
    sleep(duration_sec);

#endif

    /* Stop the ring buffer DMA before cleanup */
    try {
        pDrvr->dmaStop((uint8_t)direction);
    } catch (...) {
        LOGE("DMA %s ring stop failed.\n", dir_str);
    }

    status = dma_cleanup(buffer, num_buffers, direction);
    if (status != 0) {
        LOGE("DMA %s ring cleanup failed.\n", dir_str);
        return DMA_ERROR;
    }

    return status;
}

/**
 * @brief Displays information about PCIe BARs (Base Address Registers).
 *
 * This function retrieves and displays information about the PCIe BARs, including 
 * the BAR number, physical start address, and size. If device mode is bridge or DMA, 
 * it marks the first BAR as containing FPGA registers.
 *
 * @param mode The device operating mode.
 */
void showBars(deviceMode_t mode)
{
    struct PCIResourceInfo PCIinfo;
    pDrvr->getPCIBarInfo(&PCIinfo);

    printf("\nPCIe BAR Info:\n");
    printf("numBARs: %d\n", PCIinfo.numBARs);
    for (uint32_t i = 0; i < PCIinfo.numBARs; i++)
    {
        printf("BAR %d:\t", PCIinfo.BAR[i].nBAR);
        printf("Addr 0x%lx \t", PCIinfo.BAR[i].physStartAddr);
        /*printf("flags=0x%x memMapped=%d \t",
               PCIinfo.BAR[i].flags, PCIinfo.BAR[i].memMapped);*/
        if (i == 0) {
            if (mode != TLP) {
                printf("Size %d Bytes \t   [FPGA Registers]\n", PCIinfo.BAR[i].size);
            }
            else {
                printf("Size %d Bytes \t\n", PCIinfo.BAR[i].size);
            }
            
        }
        else {
            printf("Size %d Bytes \t\n", PCIinfo.BAR[i].size);
        }
    }
}

/**
 * @brief Parses DMA transfer arguments from the input stream.
 *
 * Reads transfer_size (hex or decimal), iterations (decimal), and fpga_addr
 * (hex or decimal, optional) from the stream. Then validates and aligns
 * fpga_addr against the given FPGA RAM size limit.
 *
 * @param iss Input stream containing the DMA command arguments.
 * @param fpga_ram_size FPGA RAM size limit in bytes.
 * @param transfer_size Output: parsed transfer size in bytes.
 * @param iterations Output: parsed iteration count.
 * @param fpga_addr Output: parsed and 8DW-aligned FPGA address.
 * @return true on success, false on any parse or validation error.
 */
static bool parse_dma_transfer_args(std::istringstream& iss, size_t fpga_ram_size,
                                    size_t& transfer_size, int& iterations, uint64_t& fpga_addr) {
    std::string size_str;
    if (!(iss >> size_str)) {
        printf("Failed to read transfer size. Please provide a valid size.\n");
        return false;
    }
    uint64_t raw_size;
    if (!parse_uint64(size_str.c_str(), raw_size, "transfer size"))
        return false;
    transfer_size = (size_t)raw_size;

    if (!(iss >> std::dec >> iterations)) {
        printf("Failed to read iterations. Please provide count in decimal.\n");
    }

    if (!validate_iterations(iterations))
        return false;

    std::string addr_str;
    if (!(iss >> addr_str)) {
        fpga_addr = 0;
    } else {
        if (!parse_uint64(addr_str.c_str(), fpga_addr, "FPGA address"))
            return false;
    }

    if (!validate_transfer_size(fpga_ram_size, transfer_size)) {
        return false;
    }

    if (!validate_fpga_addr(fpga_ram_size, transfer_size, fpga_addr)) {
        printf("DMA operation cancelled due to invalid FPGA address.\n");
        return false;
    }

    return true;
}

/**
 * @brief Parses DMA throughput arguments from the input stream.
 *
 * Reads transfer_size (hex or decimal) and iterations (decimal) from the stream.
 *
 * @param iss Input stream containing the DMA command arguments.
 * @param fpga_ram_size FPGA RAM size limit in bytes.
 * @param transfer_size Output: parsed transfer size in bytes.
 * @param count Output: parsed iteration count (normal mode; must be > 0) or duration in seconds
 *        (ring mode; 0 or greater).
 * @param is_ring If true, the second argument is parsed as duration in seconds instead of iterations.
 * @param bidirectional If true, validate_transfer_size caps at fpga_ram_size/2 (e.g. tb command).
 * @return true on success, false on any parse or validation error.
 */
static bool parse_dma_throughput_args(std::istringstream& iss, size_t fpga_ram_size,
                                      size_t& transfer_size, int& count, bool is_ring = false,
                                      bool bidirectional = false) {
    std::string size_str;
    const char *count_label = is_ring ? "duration (seconds)" : "iterations";

    if (!(iss >> size_str)) {
        printf("Failed to read transfer size. Please provide a valid size.\n");
        return false;
    }
    uint64_t raw_size;
    if (!parse_uint64(size_str.c_str(), raw_size, "transfer size"))
        return false;
    transfer_size = (size_t)raw_size;

    if (!(iss >> std::dec >> count)) {
        printf("Failed to read %s. Please provide a value in decimal.\n", count_label);
        return false;
    }

    if (!validate_iterations(count, is_ring))
        return false;

    if (!validate_transfer_size(fpga_ram_size, transfer_size, bidirectional))
        return false;

    return true;
}

/**
 * @brief Displays the PCIe Menu.
 *
 * This function prints the available commands and their descriptions for the PCIe 
 * menu. It provides options for dumping PCI configuration space, setting or 
 * showing BARs, reading and writing BARs, validating memory, showing help, and exiting.
 */
void showHelp(deviceMode_t mode)
{
    printf("\n===================================================== PCIe Menu =====================================================\n");
    printf("|  c                                                              - Dump PCI Config Space\n");
    printf("|  b           [bar_number]                                       - Set/Show BARs\n");
    printf("|  r[b|w|d|q]  [addr] [count]                                     - Read b=8bit, w=16bit, d=32bit, q=64bit\n");
    printf("|  w[b|w|d|q]  [addr] [data1 data2 ... dataN]                     - Write b=8bit, w=16bit, d=32bit, q=64bit\n");
    printf("|  v[b|w|d|q]  [size]                                             - Validate Memory b=8bit, w=16bit, d=32bit, q=64bit\n");
    printf("|  df          [transfer_size] [iterations] [fpga_addr]           - DMA F2H\n");
    printf("|  dh          [transfer_size] [iterations] [fpga_addr]           - DMA H2F\n");  
    printf("|  dv          [transfer_size] [iterations] [fpga_addr]           - DMA H2F and F2H with data validation\n");
    printf("|  tf          [transfer_size] [iterations]                       - DMA Throughput F2H\n");
    printf("|  th          [transfer_size] [iterations]                       - DMA Throughput H2F\n");
    printf("|  tb          [transfer_size] [iterations]                       - DMA Throughput bidirectional\n");
    printf("|  tfr         [transfer_size] [duration<sec>]                    - DMA Throughput F2H Ring\n");
    printf("|  thr         [transfer_size] [duration<sec>]                    - DMA Throughput H2F Ring\n");
    if (mode == BRIDGE_MSI) {
    printf("|  u           [usr_int: 0 - 15] [vector_val: 0 - 31]             - Configure User Interrupt\n");
    }
    
    printf("|  h                                                              - Show Help\n");
    printf("|  q,x                                                            - Quit/Exit\n");
    printf("=======================================================================================================================\n");
}

/**
 * @brief Runs the PCIe Menu.
 *
 * This function provides an interactive menu for performing various PCIe-related 
 * operations. It allows users to display PCI configuration space, 
 * set or show BARs, read and write BARs, validate memory, and display help. The menu 
 * processes user commands in a loop until the user chooses to exit.
 *
 * @param PCIinfo Pointer to the PCI resource information structure.
 * @param deviceMode The current device operating mode.
 */
void runMenu(const struct PCIResourceInfo *PCIinfo, deviceMode_t deviceMode) 
{
    bool done;
    std::string line;
    done = false;
    int bar_num = 0;
    while (!done) {
        showHelp(deviceMode);
        printf("Current BAR: %d\n", bar_num);
        printf("Enter command: ");
        fflush(stdout);  // Force output to be displayed immediately
        std::getline(std::cin, line);

        std::istringstream iss(line);
        std::string cmd_str;
        std::string results;
        iss >> cmd_str;
        if (cmd_str.length() == 1) {    
            switch (cmd_str[0]) {
                case 'q': // quit
                case 'x':
                case 'Q':
                case 'X':
                    printf("Exiting debug menu.\n");
                    done = true;
                    break;
                case 'c':
                case 'C':    
                {
                    std::vector<uint8_t> buf;
                    buf.resize(LINE_BUFFER_SIZE);
                    printf("\n\n======= PCI Config Registers ==========\n");
                    if (pDrvr->getPCIConfigRegs(buf.data())) {
                        printf("\nPCI Config Registers (0x00-0x3f):\n");
                        formatBlockOfBytes(results, PCI_CFG_START, PCI_CFG_END, buf);
                        printf("\nPCI Config Registers (0x40-0xff):\n");
                        std::vector<uint8_t> subBuf(buf.begin() + 0x40, buf.end());
                        formatBlockOfBytes(results, PCI_CAP_START, PCI_CAP_END, subBuf);
                    }
                    else {
                        printf("Error reading PCI Config Registers\n");
                    }  
                    break;    
                }  
                case 'h': //help
                case 'H':
                case '?':
                    showHelp(deviceMode);
                    break;       
                case 'b': // Show BARs
                {
                    int new_bar_num;
                    showBars(deviceMode);
                    if (!(iss >> new_bar_num)) {
                        printf("\n");
                    } else if (new_bar_num >= static_cast<int>(PCIinfo->numBARs)) {
                        printf("Invalid BAR number: %d. It must be less than %u (numBars).\n", new_bar_num, PCIinfo->numBARs);
                    } else {
                        bar_num = new_bar_num;
                        printf("BAR number set to %d.\n", bar_num);
                    }
                    break;
                }    
                case 'u': // Configure User Interrupt
                {
                    int usr_int = 0;
                    int vec_val = 0;
                    if (!(iss >> std::dec >> usr_int)) {
                        printf("Failed to read user interrupt number. Please provide a valid number.\n");
                        break;
                    }
                    if (usr_int < 0 || usr_int > 15) {
                        printf("Invalid user interrupt number: %d. It must be between 0 and 15.\n", usr_int);
                        break;
                    }
                    if (!(iss >> std::dec >> vec_val)) {
                        printf("Failed to read vector value. Please provide a valid number.\n");
                        break;
                    }   
                    if (vec_val < 0 || vec_val > 31) {
                        printf("Invalid vector value: %d. It must be between 0 and 31.\n", vec_val);
                        break;
                    }                 
                    if (!iss.fail()) {
                        confUsrInt(usr_int, vec_val);
                        printf("User Interrupt %d configured with vector value %d.\n", usr_int, vec_val);
                    }
                    break;
                }
            }
        }
        else if (cmd_str.length() == 2) {
            char operation = cmd_str[0];
            char type = cmd_str[1];

            switch (operation) {
                case 'r': // Read Operation
                {
                    size_t count = 1; // Default to reading 1 byte/word/dword/qword
                    uint64_t addr = 0; // Default address
                    std::string token;
                    if (!(iss >> token) || !parse_uint64(token.c_str(), addr, "address")) {
                        break;
                    }
                    if (!(iss >> std::dec >> count)) {
                        printf("Failed to read count. Please provide count in decimal.\n");
                        // count = 1;
                    }    
                    if (addr >= PCIinfo->BAR[bar_num].size) {
                        printf("Address exceed range of BAR %d. Please provide a valid address.\n", bar_num);
                        break;
                    }                 
                    if (!iss.fail()) {
                        switch(type) {
                        case 'b': 
                            {
                                if ( (addr + count - 1) >= PCIinfo->BAR[bar_num].size) {
                                    //adjust the count to the maximum possible value
                                    count = PCIinfo->BAR[bar_num].size - addr;
                                    printf("Exceed range of BAR %d. Count adjusted to %zu.\n", bar_num, count);
                                }
                                std::vector<uint8_t> buf(count);
                                printf("Reading %zu bytes from address 0x%lx\n", count, addr);
                                printf("Read Data (8-bit):\n");
                                if (count == 1) {
                                    buf[0] = pDrvr->read8(bar_num, addr);
                                } 
                                else if (count > 1){
                                    pDrvr->readBlock8(bar_num, addr, buf, count);
                                }
                                formatBlockOfBytes(results, addr, count, buf);
                                break;
                            }
                        case 'w': 
                            {
                                /* Round down address to nearest 16-bit (2-byte) alignment
                                to ease display formatting */
                                addr = addr & ~(sizeof(uint16_t) - 1);
                                if ( (addr + (count*sizeof(uint16_t)) - 1) >= PCIinfo->BAR[bar_num].size) {
                                    //adjust the count to the maximum possible value
                                    count = (PCIinfo->BAR[bar_num].size - addr) / sizeof(uint16_t);
                                    printf("Exceed range of BAR %d. Count adjusted to %zu.\n", bar_num, count);
                                }
                                std::vector<uint16_t> buf(count);
                                printf("Reading %zu words from address 0x%lx\n", count, addr);
                                printf("Read Data (16-bit):\n");
                                if (count == 1) {
                                    buf[0] = pDrvr->read16(bar_num, addr);
                                } 
                                else if (count > 1){
                                    pDrvr->readBlock16(bar_num, addr, buf, count);
                                }
                                formatBlockOfWords(results, addr, count, buf);
                                break;
                            }
                        case 'd': 
                            {
                                /* Round down address to nearest 32-bit (4-byte) alignment
                                to ease display formatting */
                                addr = addr & ~(sizeof(uint32_t) - 1);
                                if ( (addr + (count*sizeof(uint32_t)) - 1) >= PCIinfo->BAR[bar_num].size) {
                                    //adjust the count to the maximum possible value
                                    count = (PCIinfo->BAR[bar_num].size - addr) / sizeof(uint32_t);
                                    printf("Exceed range of BAR %d. Count adjusted to %zu.\n", bar_num, count);
                                }
                                std::vector<uint32_t> buf(count);
                                printf("Reading %zu dwords from address 0x%lx\n", count, addr);
                                printf("Read Data (32-bit):\n");
                                if (count == 1) {
                                    buf[0] = pDrvr->read32(bar_num, addr);
                                } 
                                else if (count > 1){
                                    pDrvr->readBlock32(bar_num, addr, buf, count);
                                }
                                formatBlockOfDWords(results, addr, count, buf);
                                break;
                            }
                        case 'q': 
                            {
                                if (deviceMode != TLP) {
                                    printf("64-bit read operation not supported.\n");
                                    break;
                                }
                                /* Round down address to nearest 64-bit (8-byte) alignment
                                to ease display formatting */
                                addr = addr & ~(sizeof(uint64_t) - 1);
                                if ( (addr + (count*sizeof(uint64_t)) - 1) >= PCIinfo->BAR[bar_num].size) {
                                    //adjust the count to the maximum possible value
                                    count = (PCIinfo->BAR[bar_num].size - addr) / sizeof(uint64_t);
                                    printf("Exceed range of BAR %d. Count adjusted to %zu.\n", bar_num, count);
                                }
                                std::vector<uint64_t> buf(count);
                                printf("Reading %zu qwords from address 0x%lx\n", count, addr);
                                printf("Read Data (64-bit):\n");
                                if (count == 1) {
                                    buf[0] = pDrvr->read64(bar_num, addr);
                                } 
                                else if (count > 1){
                                    pDrvr->readBlock64(bar_num, addr, buf, count);
                                }
                                formatBlockOfQWords(results, addr, count, buf);
                                break;
                            }
                        default:
                            printf("Unknown read type: %c\n", type);
                            break;                            
                        }
                    }
                    break;
                }
                case 'w': // Write Operation
                {
                    std::vector<uint64_t> data_vals; // Use uint64_t to hold any size data during parsing
                    uint64_t val;
                    uint64_t addr = 0; // Default address
                    std::string token;
                    if (!(iss >> token) || !parse_uint64(token.c_str(), addr, "address")) {
                        break;
                    }
                    if (addr >= PCIinfo->BAR[bar_num].size) {
                        printf("Write rejected: address 0x%lx exceeds BAR %d range (size 0x%x).\n",
                               (unsigned long)addr, bar_num, PCIinfo->BAR[bar_num].size);
                        break;
                    }
                    while ((iss >> token) && parse_uint64(token.c_str(), val, "data")) {
                        data_vals.push_back(val);
                    }         
                    if (!data_vals.empty()) {
                        switch (type) {
                            case 'b': 
                            {
                                size_t count = check_and_limit_write_count(addr, data_vals.size(),
                                    sizeof(uint8_t), PCIinfo->BAR[bar_num].size, bar_num);
                                if (count == 0)
                                    break;

                                std::vector<uint8_t> buf(count);
                                if (count == 1) {
                                    buf[0] = static_cast<uint8_t>(data_vals[0]);
                                    pDrvr->write8(bar_num, addr, buf[0]);
                                }
                                else {
                                    for (size_t i = 0; i < count; ++i)
                                        buf[i] = static_cast<uint8_t>(data_vals[i]);
                                    pDrvr->writeBlock8(bar_num, addr, buf, count);
                                }
                                printf("Wrote %zu bytes to offset 0x%lx in BAR %d.\n",
                                       count, (unsigned long)addr, bar_num);
                                break;
                            }
                            case 'w': 
                            {
                                size_t count = check_and_limit_write_count(addr, data_vals.size(),
                                    sizeof(uint16_t), PCIinfo->BAR[bar_num].size, bar_num);
                                if (count == 0)
                                    break;

                                std::vector<uint16_t> buf(count);
                                if (count == 1) {
                                    buf[0] = static_cast<uint16_t>(data_vals[0]);
                                    pDrvr->write16(bar_num, addr, buf[0]);
                                }
                                else {
                                    for (size_t i = 0; i < count; ++i)
                                        buf[i] = static_cast<uint16_t>(data_vals[i]);
                                    pDrvr->writeBlock16(bar_num, addr, buf, count);
                                }
                                printf("Wrote %zu words to offset 0x%lx in BAR %d.\n",
                                       count, (unsigned long)addr, bar_num);
                                break;
                            }
                            case 'd': 
                            {
                                size_t count = check_and_limit_write_count(addr, data_vals.size(),
                                    sizeof(uint32_t), PCIinfo->BAR[bar_num].size, bar_num);
                                if (count == 0)
                                    break;
                                
                                std::vector<uint32_t> buf(count);
                                if (count == 1) {
                                    buf[0] = static_cast<uint32_t>(data_vals[0]);
                                    pDrvr->write32(bar_num, addr, buf[0]);
                                }
                                else {
                                    for (size_t i = 0; i < count; ++i)
                                        buf[i] = static_cast<uint32_t>(data_vals[i]);
                                    pDrvr->writeBlock32(bar_num, addr, buf, count);
                                }
                                printf("Wrote %zu dwords to offset 0x%lx in BAR %d.\n",
                                       count, (unsigned long)addr, bar_num);
                                break;
                            }
                            case 'q': 
                            {
                                if (deviceMode != TLP) {
                                    printf("64-bit write operation not supported.\n");
                                    break;
                                }
                                size_t count = check_and_limit_write_count(addr, data_vals.size(),
                                    sizeof(uint64_t), PCIinfo->BAR[bar_num].size, bar_num);
                                if (count == 0)
                                    break;
                                std::vector<uint64_t> buf(count);
                                if (count == 1) {
                                    buf[0] = static_cast<uint64_t>(data_vals[0]);
                                    pDrvr->write64(bar_num, addr, buf[0]);
                                }
                                else {
                                    for (size_t i = 0; i < count; ++i)
                                        buf[i] = static_cast<uint64_t>(data_vals[i]);
                                    pDrvr->writeBlock64(bar_num, addr, buf, count);
                                }
                                printf("Wrote %zu qwords to offset 0x%lx in BAR %d.\n",
                                       count, (unsigned long)addr, bar_num);
                                break;
                            }
                            default:
                                printf("Unknown write type: %c\n", type);
                                break;
                        }
                    } 
                    else {
                        printf("Invalid write command format. Usage: w[b|w|d|q] <addr> <data_1>...<data_n>\n");
                    }   
                    break;
                }   
                case 'v':
                {
                    if ( (bar_num == 0) && (deviceMode != TLP))
                    {
                        printf("Memory validation is not supported for BAR 0 in non-TLP mode.\n");
                        break;
                    }
                    size_t size = 1024;
                    uint64_t raw_size;
                    std::string token;
                    if (!(iss >> token) || !parse_uint64(token.c_str(), raw_size, "size")) {
                        printf("Failed to read size. Using default value: %zu\n", size);
                    } else {
                        size = (size_t)raw_size;
                    }

                    size_t max_size = (deviceMode == AXI_BRIDGE) ? 4096 : 16384;
                    size = check_limits_for_size(size, type, max_size);
                    if (size > 0) {
                        // Allocate buffer for read data
                        std::vector<uint64_t> readBuf;
                        std::string results;
                        
                        int access_width = 0;
                        switch(type) {
                            case 'b': access_width = 1; break;
                            case 'w': access_width = 2; break;
                            case 'd': access_width = 4; break;
                            case 'q': access_width = 8; break;
                            default:
                                printf("Unknown validation type: %c\n", type);
                                break;
                        }
                        if (access_width == 8 && deviceMode != TLP) {
                            printf("64-bit validation not supported.\n");
                            access_width = 0;
                        }
                        if (access_width > 0) {
                            uint32_t base_addr = (deviceMode == AXI_BRIDGE) ? 0x7000 : 0;
                            printf("Validating %zu bytes of %d-bit memory region in BAR %d at offset 0x%x...\n",
                                   size, access_width * 8, bar_num, base_addr);
                            if (validate_memory(bar_num, size, access_width, &readBuf, base_addr)) {
                                printf("Display validated data? (y/n): ");
                                std::string response;
                                std::getline(std::cin, response);
                                if (!response.empty() && (response[0] == 'y' || response[0] == 'Y')) {
                                    switch(type) {
                                        case 'b': {
                                            std::vector<uint8_t> data(readBuf.size());
                                            for (size_t i = 0; i < readBuf.size(); i++)
                                                data[i] = static_cast<uint8_t>(readBuf[i] & 0xFF);
                                            printf("Validated Data (8-bit):\n");
                                            formatBlockOfBytes(results, 0, readBuf.size(), data);
                                            break;
                                        }
                                        case 'w': {
                                            std::vector<uint16_t> data(readBuf.size());
                                            for (size_t i = 0; i < readBuf.size(); i++)
                                                data[i] = static_cast<uint16_t>(readBuf[i] & 0xFFFF);
                                            printf("Validated Data (16-bit):\n");
                                            formatBlockOfWords(results, 0, readBuf.size(), data);
                                            break;
                                        }
                                        case 'd': {
                                            std::vector<uint32_t> data(readBuf.size());
                                            for (size_t i = 0; i < readBuf.size(); i++)
                                                data[i] = static_cast<uint32_t>(readBuf[i] & 0xFFFFFFFF);
                                            printf("Validated Data (32-bit):\n");
                                            formatBlockOfDWords(results, 0, readBuf.size(), data);
                                            break;
                                        }
                                        case 'q':
                                            printf("Validated Data (64-bit):\n");
                                            formatBlockOfQWords(results, 0, readBuf.size(), readBuf);
                                            break;
                                        default:
                                            break;
                                    }
                                }
                            }
                        }
                        break;
                    }
                    break;
                }
                
                case 'd': // DMA Operation
                {
                    if (deviceMode != DMA && deviceMode != DMA_AXI_S && deviceMode != AXI_BRIDGE) {
                        printf("DMA is not supported on this device.\n");
                        break;
                    }
                    size_t transfer_size = 0x1000;
                    int iterations = 1;
                    uint64_t fpga_addr = 0;

                    if (!parse_dma_transfer_args(iss, fpga_ram_size, transfer_size, iterations, fpga_addr)) {
                        break;
                    }
                    switch(type) {
                        case 'f': 
                        {
                            printf("\nInitiating F2H DMA, transfer size: %zu bytes, iterations: %d, fpga address: 0x%lx\n",
                                   transfer_size, iterations, (unsigned long)fpga_addr);
                            int run_status = 0;
                            run_status = dma_run_single_direction(transfer_size, DMA_DIR_F2H, fpga_addr, iterations);
                            if (run_status != 0) {
                                printf("DMA F2H transfer failed.\n");
                                break;
                            }
                            break;
                        }   
                        case 'h': 
                        {
                            printf("\nInitiating H2F DMA, transfer size: %zu bytes, iterations: %d, fpga address: 0x%lx\n",
                                   transfer_size, iterations, (unsigned long)fpga_addr);
                            int run_status = 0;
                            run_status = dma_run_single_direction(transfer_size, DMA_DIR_H2F, fpga_addr, iterations);
                            if (run_status != 0) {
                                printf("DMA H2F transfer failed.\n");
                                break;
                            }
                            break;
                        } 
                        case 'v': 
                        {
                            printf("\nInitiating H2F + F2H DMA validation, transfer size: %zu bytes, iterations: %d, fpga address: 0x%lx\n",
                                   transfer_size, iterations, (unsigned long)fpga_addr);
                            int run_status = 0;
                            run_status = dma_single_direction_data_compare(transfer_size, iterations,
                                                                            fpga_addr, deviceMode);
                            if (run_status != 0) {
                                printf("DMA validation failed.\n");
                                break;
                            }
                            break;
                        }
                        default:
                            printf("Unknown command: %s\n", cmd_str.c_str());
                            break;
                    }
                    break;
                }

                case 't': // DMA Throughput Operation
                {
                    if (deviceMode != DMA && deviceMode != DMA_AXI_S && deviceMode != AXI_BRIDGE) {
                        printf("DMA is not supported on this device.\n");
                        break;
                    }
                    size_t transfer_size = 0x1000;
                    int iterations = 1;

                    if (!parse_dma_throughput_args(iss, fpga_ram_size, transfer_size, iterations,
                                                    false, type == 'b')) {
                        break;
                    }
                    switch(type) {
                        case 'f': 
                            {
                                int run_status = dma_meas_single_dir_throughput(transfer_size, DMA_DIR_F2H, iterations);
                                if (run_status != 0) {
                                    printf("DMA F2H throughput measurement failed.\n");
                                    break;
                                }
                                break;
                            }
                        case 'h': 
                            {
                                int run_status = dma_meas_single_dir_throughput(transfer_size, DMA_DIR_H2F, iterations);
                                if (run_status != 0) {
                                    printf("DMA H2F throughput measurement failed.\n");
                                    break;
                                }
                                break;
                            }
                        case 'b': 
                            {
                                int run_status = dma_meas_bidirection_throughput(transfer_size, iterations);
                                if (run_status != 0) {
                                    printf("DMA H2F and F2H bidirectional throughput measurement failed.\n");
                                    break;
                                }
                                break;
                            }
                        default:
                            printf("Unknown command: %s\n", cmd_str.c_str());
                            break;
                    }
                    break;
                }

                default:
                    printf("Unknown command: %s\n", cmd_str.c_str());
                    showHelp(deviceMode);
                    continue; // Skip to the next iteration to avoid processing further 
            }
        }
        else if (cmd_str.length() == 3) {
            char operation = cmd_str[0];
            char type = cmd_str[1];
            char mode = cmd_str[2];

            switch (operation) {
                case 't': // DMA Throughput (ring buffer mode)
                {
                    if (deviceMode != DMA && deviceMode != DMA_AXI_S) {
                        printf("DMA ring buffer throughput is not supported on this device.\n");
                        break;
                    }
                    if (mode != 'r') {
                        printf("Unknown mode: %c. Use 'r' for ring buffer.\n", mode);
                        break;
                    }
                    size_t transfer_size = 0x1000;
                    int duration_sec = 1;

                    if (!parse_dma_throughput_args(iss, fpga_ram_size, transfer_size, duration_sec, true)) {
                        break;
                    }
                    switch (type) {
                        case 'f':
                        {
                            int run_status = dma_meas_ring_throughput(transfer_size, DMA_DIR_F2H, duration_sec);
                            if (run_status != 0) {
                                printf("DMA F2H ring throughput measurement failed.\n");
                            }
                            break;
                        }
                        case 'h':
                        {
                            int run_status = dma_meas_ring_throughput(transfer_size, DMA_DIR_H2F, duration_sec);
                            if (run_status != 0) {
                                printf("DMA H2F ring throughput measurement failed.\n");
                            }
                            break;
                        }
                        default:
                            printf("Unknown direction: %c. Use 'f' for F2H or 'h' for H2F.\n", type);
                            break;
                    }
                    break;
                }
                default:
                    printf("Unknown command: %s\n", cmd_str.c_str());
                    showHelp(deviceMode);
                    continue;
            }
        }
        else {
            printf("Unknown command: %s\n", cmd_str.c_str());
            showHelp(deviceMode);
            continue;
        }
    }
}   

/* ============================================================
 *  CLI – getopt_long option tables
 * ============================================================ */

static struct option global_long_opts[] = {
    {"quiet",   no_argument, NULL, 'q'},
    {"help",    no_argument, NULL, 'h'},
    {NULL, 0, NULL, 0}
};

static struct option bar_long_opts[] = {
    {"bar",    required_argument, NULL, 'b'},
    {"offset", required_argument, NULL, 'o'},
    {"size",   required_argument, NULL, 's'},
    {"data",   required_argument, NULL, 'd'},
    {"help",   no_argument,       NULL, 'h'},
    {NULL, 0, NULL, 0}
};

static struct option dma_long_opts[] = {
    {"size",       required_argument, NULL, 's'},
    {"addr",       required_argument, NULL, 'a'},
    {"iterations", required_argument, NULL, 'n'},
    {"help",       no_argument,       NULL, 'h'},
    {NULL, 0, NULL, 0}
};

static void cli_usage(const char *prog) {
    printf("Usage:\n");
    printf("  %s                                     No args: launches interactive menu\n", prog);
    printf("  %s -h|--help                           Show this help message\n", prog);
    printf("  %s -q <command> [options]              Run a command in quiet mode\n", prog);
    printf("  %s <command> [options]                 Run a command\n", prog);
    printf("\nCommand (must be first argument, followed by its options):\n");
    printf("  rr  -b <bar> -o <offset> -s <size>               Register read\n");
    printf("  wr  -b <bar> -o <offset> -s <size> -d <data>     Register write\n");
    printf("  dh  -s <size> [-a <fpga_addr>]                   DMA H2F single transfer\n");
    printf("  df  -s <size> [-a <fpga_addr>]                   DMA F2H single transfer\n");
    printf("  dv  -s <size> [-a <fpga_addr>]                   DMA data validate\n");
    printf("  th  -s <size> -n <iterations>                    DMA H2F throughput\n");
    printf("  tf  -s <size> -n <iterations>                    DMA F2H throughput\n");
    printf("  tb  -s <size> -n <iterations>                    DMA bidir throughput\n");
    printf("  thr -s <size> -n <duration_sec>                  DMA H2F ring throughput\n");
    printf("  tfr -s <size> -n <duration_sec>                  DMA F2H ring throughput\n");
    printf("  cap                                              Print PCI capabilities\n");
    printf("\nOptions:\n");
    printf("  -h                Show per-command help when used after a command\n");
    printf("  -b <bar>          BAR number\n");
    printf("  -o <offset>       Register offset\n");
    printf("  -s <size>         Transfer size or register size\n");
    printf("  -d <data>         Data value to write\n");
    printf("  -a <fpga_addr>    FPGA address (default: 0)\n");
    printf("  -n <count>        Iterations or duration in seconds\n");
    printf("\nExamples:\n");
    printf("  %s rr -b 0 -o 0x10 -s 4\n", prog);
    printf("  %s -q th -s 0x20000 -n 5000\n", prog);
    printf("  %s dh -s 0x1000 -a 0x0\n", prog);
}

/* ============================================================
 *  CLI – per-command handlers
 * ============================================================ */

static int cmd_cap(void) {
#ifdef PRINT_DETAILED_CAPABILITIES
    if (!g_quiet)
        printf("Printing PCI Capabilities in Detailed Mode\n");
    print_pci_cap(true);
    return EXIT_OK;
#else
    LOGE("Detailed capability print is disabled. "
         "Enable PRINT_DETAILED_CAPABILITIES to use 'cap'.\n");
    return EXIT_FAIL;
#endif
}

static int cmd_rr(int argc, char **argv, const struct PCIResourceInfo *pci, deviceMode_t deviceMode) {
    int bar_num = -1;
    uint64_t offset = 0;
    int reg_size = -1;
    bool offset_set = false;

    optind = 1;
    int opt;
    while ((opt = getopt_long(argc, argv, "b:o:s:h", bar_long_opts, NULL)) != -1) {
        switch (opt) {
            case 'b': if (!parse_int(optarg, bar_num, "BAR number")) return EXIT_USAGE; break;
            case 'o': if (!parse_uint64(optarg, offset, "offset")) return EXIT_USAGE; offset_set = true; break;
            case 's': if (!parse_int(optarg, reg_size, "register size")) return EXIT_USAGE; break;
            case 'h':
                printf("Usage: pcie_app rr -b <bar> -o <offset> -s <size>\n");
                return EXIT_OK;
            default: return EXIT_USAGE;
        }
    }

    if (bar_num < 0 || !offset_set || reg_size < 0) {
        LOGE("Error: -b, -o, and -s are required for rr.\n");
        return EXIT_USAGE;
    }
    if (reg_size == 8 && deviceMode != TLP) {
        LOGE("Error: 64-bit read not supported in this mode.\n");
        return EXIT_FAIL;
    }
    if (bar_num >= (int)pci->numBARs) {
        LOGE("Error: Invalid BAR number %d (must be < %u).\n", bar_num, pci->numBARs);
        return EXIT_FAIL;
    }
    {
        uint32_t bar_sz = pci->BAR[bar_num].size;
        if (offset >= bar_sz || offset + (uint64_t)reg_size > (uint64_t)bar_sz) {
            LOGE("Error: offset/access exceeds BAR %d range (offset 0x%lx, access %d bytes, BAR size 0x%x bytes).\n",
                 bar_num, (unsigned long)offset, reg_size, bar_sz);
            return EXIT_FAIL;
        }
    }

    if (read_bridge((uint8_t)bar_num, (uint32_t)offset, (uint8_t)reg_size) != 0)
        return EXIT_FAIL;
    return EXIT_OK;
}

static int cmd_wr(int argc, char **argv, const struct PCIResourceInfo *pci, deviceMode_t deviceMode) {
    int bar_num = -1;
    uint64_t offset = 0;
    int reg_size = -1;
    uint64_t data = 0;
    bool offset_set = false, data_set = false;

    optind = 1;
    int opt;
    while ((opt = getopt_long(argc, argv, "b:o:s:d:h", bar_long_opts, NULL)) != -1) {
        switch (opt) {
            case 'b': if (!parse_int(optarg, bar_num, "BAR number")) return EXIT_USAGE; break;
            case 'o': if (!parse_uint64(optarg, offset, "offset")) return EXIT_USAGE; offset_set = true; break;
            case 's': if (!parse_int(optarg, reg_size, "register size")) return EXIT_USAGE; break;
            case 'd': if (!parse_uint64(optarg, data, "data")) return EXIT_USAGE; data_set = true; break;
            case 'h':
                printf("Usage: pcie_app wr -b <bar> -o <offset> -s <size> -d <data>\n");
                return EXIT_OK;
            default: return EXIT_USAGE;
        }
    }

    if (bar_num < 0 || !offset_set || reg_size < 0 || !data_set) {
        LOGE("Error: -b, -o, -s, and -d are required for wr.\n");
        return EXIT_USAGE;
    }
    if (reg_size == 8 && deviceMode != TLP) {
        LOGE("Error: 64-bit write not supported in this mode.\n");
        return EXIT_FAIL;
    }
    if (bar_num >= (int)pci->numBARs) {
        LOGE("Error: Invalid BAR number %d (must be < %u).\n", bar_num, pci->numBARs);
        return EXIT_FAIL;
    }
    {
        uint32_t bar_sz = pci->BAR[bar_num].size;
        if (offset >= bar_sz || offset + (uint64_t)reg_size > (uint64_t)bar_sz) {
            LOGE("Error: offset/access exceeds BAR %d range (offset 0x%lx, access %d bytes, BAR size 0x%x bytes).\n",
                 bar_num, (unsigned long)offset, reg_size, bar_sz);
            return EXIT_FAIL;
        }
    }

    if (write_bridge((uint8_t)bar_num, (uint32_t)offset, (uint8_t)reg_size, data) != 0)
        return EXIT_FAIL;
    if (g_quiet)
        printf("OK\n");
    return EXIT_OK;
}

static int cmd_dma_single(int argc, char **argv, deviceMode_t deviceMode,
                         enum dma_direction direction) {
    uint64_t raw_size = 0;
    uint64_t fpga_addr = 0;
    bool size_set = false, addr_set = false;
    const char *dir_str = (direction == DMA_DIR_H2F) ? "H2F" : "F2H";

    optind = 1;
    int opt;
    while ((opt = getopt_long(argc, argv, "s:a:h", dma_long_opts, NULL)) != -1) {
        switch (opt) {
            case 's': if (!parse_uint64(optarg, raw_size, "transfer size")) return EXIT_USAGE; size_set = true; break;
            case 'a': if (!parse_uint64(optarg, fpga_addr, "FPGA address")) return EXIT_USAGE; addr_set = true; break;
            case 'h':
                printf("Usage: pcie_app %s -s <size> [-a <fpga_addr>]\n",
                       (direction == DMA_DIR_H2F) ? "dh" : "df");
                return EXIT_OK;
            default: return EXIT_USAGE;
        }
    }

    if (!size_set) {
        LOGE("Error: -s <size> is required for %s.\n", dir_str);
        return EXIT_USAGE;
    }

    size_t transfer_size = (size_t)raw_size;
    if (!validate_transfer_size(fpga_ram_size, transfer_size))
        return EXIT_FAIL;
    if (!validate_fpga_addr(fpga_ram_size, transfer_size, fpga_addr))
        return EXIT_FAIL;

    if (!g_quiet)
        printf("%s DMA single transfer: size=0x%zx, fpga_addr=0x%lx\n",
               dir_str, transfer_size, (unsigned long)fpga_addr);

    int ret = dma_run_single_direction(transfer_size, direction, fpga_addr, 1);
    if (ret != 0) {
        LOGE("result=FAIL cmd=%s\n", (direction == DMA_DIR_H2F) ? "dh" : "df");
        return EXIT_FAIL;
    }
    if (g_quiet)
        printf("result=PASS cmd=%s size=0x%zx fpga_addr=0x%lx\n",
               (direction == DMA_DIR_H2F) ? "dh" : "df", transfer_size, (unsigned long)fpga_addr);
    return EXIT_OK;
}

static int cmd_dma_validate(int argc, char **argv, deviceMode_t deviceMode) {
    uint64_t raw_size = 0;
    uint64_t fpga_addr = 0;
    bool size_set = false;

    optind = 1;
    int opt;
    while ((opt = getopt_long(argc, argv, "s:a:h", dma_long_opts, NULL)) != -1) {
        switch (opt) {
            case 's': if (!parse_uint64(optarg, raw_size, "transfer size")) return EXIT_USAGE; size_set = true; break;
            case 'a': if (!parse_uint64(optarg, fpga_addr, "FPGA address")) return EXIT_USAGE; break;
            case 'h':
                printf("Usage: pcie_app dv -s <size> [-a <fpga_addr>]\n");
                return EXIT_OK;
            default: return EXIT_USAGE;
        }
    }

    if (!size_set) {
        LOGE("Error: -s <size> is required for dv.\n");
        return EXIT_USAGE;
    }

    size_t transfer_size = (size_t)raw_size;
    if (!validate_transfer_size(fpga_ram_size, transfer_size))
        return EXIT_FAIL;
    if (!validate_fpga_addr(fpga_ram_size, transfer_size, fpga_addr))
        return EXIT_FAIL;

    if (!g_quiet)
        printf("DMA data validate: size=0x%zx, fpga_addr=0x%lx\n",
               transfer_size, (unsigned long)fpga_addr);

    int ret = dma_single_direction_data_compare(transfer_size, 1, fpga_addr, deviceMode);
    if (ret != 0) {
        LOGE("result=FAIL cmd=dv\n");
        return EXIT_FAIL;
    }
    if (g_quiet)
        printf("result=PASS cmd=dv size=0x%zx fpga_addr=0x%lx\n", transfer_size, (unsigned long)fpga_addr);
    return EXIT_OK;
}

static int cmd_dma_throughput(int argc, char **argv, deviceMode_t deviceMode,
                              enum dma_direction direction, bool bidirectional) {
    uint64_t raw_size = 0;
    int iterations = -1;
    bool size_set = false;
    const char *cmd_name = bidirectional ? "tb" :
                           (direction == DMA_DIR_H2F) ? "th" : "tf";

    optind = 1;
    int opt;
    while ((opt = getopt_long(argc, argv, "s:n:h", dma_long_opts, NULL)) != -1) {
        switch (opt) {
            case 's': if (!parse_uint64(optarg, raw_size, "transfer size")) return EXIT_USAGE; size_set = true; break;
            case 'n': if (!parse_int(optarg, iterations, "iterations")) return EXIT_USAGE; break;
            case 'h':
                printf("Usage: pcie_app %s -s <size> -n <iterations>\n", cmd_name);
                return EXIT_OK;
            default: return EXIT_USAGE;
        }
    }

    if (!size_set || iterations < 0) {
        LOGE("Error: -s and -n are required for %s.\n", cmd_name);
        return EXIT_USAGE;
    }

    size_t transfer_size = (size_t)raw_size;
    if (!validate_transfer_size(fpga_ram_size, transfer_size, bidirectional))
        return EXIT_FAIL;
    if (!validate_iterations(iterations))
        return EXIT_FAIL;

    int ret;
    if (bidirectional)
        ret = dma_meas_bidirection_throughput(transfer_size, iterations);
    else
        ret = dma_meas_single_dir_throughput(transfer_size, direction, iterations);

    if (ret != 0) {
        LOGE("result=FAIL cmd=%s\n", cmd_name);
        return EXIT_FAIL;
    }
    return EXIT_OK;
}

static int cmd_dma_ring(int argc, char **argv, deviceMode_t deviceMode,
                        enum dma_direction direction) {
    uint64_t raw_size = 0;
    int duration_sec = -1;
    bool size_set = false;
    const char *cmd_name = (direction == DMA_DIR_H2F) ? "thr" : "tfr";

    if (deviceMode != DMA && deviceMode != DMA_AXI_S) {
        LOGE("Error: DMA ring buffer throughput is not supported on this device.\n");
        return EXIT_DEVICE;
    }

    optind = 1;
    int opt;
    while ((opt = getopt_long(argc, argv, "s:n:h", dma_long_opts, NULL)) != -1) {
        switch (opt) {
            case 's': if (!parse_uint64(optarg, raw_size, "transfer size")) return EXIT_USAGE; size_set = true; break;
            case 'n': if (!parse_int(optarg, duration_sec, "duration")) return EXIT_USAGE; break;
            case 'h':
                printf("Usage: pcie_app %s -s <size> -n <duration_sec>\n", cmd_name);
                return EXIT_OK;
            default: return EXIT_USAGE;
        }
    }

    if (!size_set || duration_sec < 0) {
        LOGE("Error: -s and -n are required for %s.\n", cmd_name);
        return EXIT_USAGE;
    }

    size_t transfer_size = (size_t)raw_size;
    if (!validate_transfer_size(fpga_ram_size, transfer_size))
        return EXIT_FAIL;
    if (!validate_iterations(duration_sec, true))
        return EXIT_FAIL;
    if (g_quiet && duration_sec == 0) {
        LOGE("Error: duration (-n) must be > 0 in quiet mode (no interactive stdin).\n");
        return EXIT_USAGE;
    }

    int ret = dma_meas_ring_throughput(transfer_size, direction, duration_sec);
    if (ret != 0) {
        LOGE("result=FAIL cmd=%s\n", cmd_name);
        return EXIT_FAIL;
    }
    return EXIT_OK;
}

/**
 * @brief Entry point for the PCIe application.
 *
 * Parses global options (-q, -h) via getopt_long, then dispatches to
 * per-command handlers that parse their own named flags. Falls back to
 * the interactive menu when no command is given.
 *
 * @param argc The number of command-line arguments.
 * @param argv The array of command-line arguments.
 * @return Returns 0 on successful execution, non-zero on error.
 */
int main(int argc, char *argv[])
{
    struct PCIResourceInfo PCIinfo;
    uint32_t numBars = 1;
    deviceMode_t deviceMode = DMA;

    /* ---- Phase 1: parse global options (stop at first non-option) ---- */
    int opt;
    while ((opt = getopt_long(argc, argv, "+qh", global_long_opts, NULL)) != -1) {
        switch (opt) {
            case 'q': g_quiet = true;  break;
            case 'h': cli_usage(argv[0]); return EXIT_OK;
            default:  cli_usage(argv[0]); return EXIT_USAGE;
        }
    }

    /* ---- Build device name with board index (default 0) ---- */
    char devName[64];
    snprintf(devName, sizeof(devName), "%s%d", PCIE_DRIVER_NAME, 0);

    /* ---- Initialise hardware ---- */
    try {
        pDrvr = new PCIEDMA_IF(devName);
    }
    catch(std::exception &e) {
        ERRORSTR(e.what());
        return EXIT_DEVICE;
    }
    store_pci_cap();
    pDrvr->getPCIBarInfo(&PCIinfo);
    numBars = PCIinfo.numBARs;
   
    uint16_t vendorId = PCIinfo.PCICfgReg[0] | (PCIinfo.PCICfgReg[1] << 8);
    uint16_t deviceId = PCIinfo.PCICfgReg[2] | (PCIinfo.PCICfgReg[3] << 8);
    LOGI("Device Name: %s\n", devName);
    LOGI("Vendor ID: 0x%04x, Device ID: 0x%04x\n", vendorId, deviceId);
    LOGI("PCI Location: Bus %d, Device %d, Function %d\n",
         PCIinfo.bus, PCIinfo.device, PCIinfo.function);

    deviceMode = getDeviceMode();
    fpga_ram_size = get_fpga_ram_size(deviceId);

    /* ---- No command → interactive menu ---- */
    if (optind >= argc) {
        if (g_quiet) {
            LOGE("Error: -q option requires a command.\n");
            cli_usage(argv[0]);
            return EXIT_USAGE;
        }
        print_pci_cap_summary();
        showBars(deviceMode);
        runMenu(&PCIinfo, deviceMode);
        return EXIT_OK;
    }

    /* ---- Phase 2: dispatch on command name ---- */
    g_strict = true;

    const char *cmd = argv[optind];
    int cmd_argc = argc - optind;
    char **cmd_argv = argv + optind;

    if (!strcmp(cmd, "cap"))
        return cmd_cap();

    if (!strcmp(cmd, "rr"))
        return cmd_rr(cmd_argc, cmd_argv, &PCIinfo, deviceMode);

    if (!strcmp(cmd, "wr"))
        return cmd_wr(cmd_argc, cmd_argv, &PCIinfo, deviceMode);

    /* DMA commands require a DMA-capable device mode */
    if (!strcmp(cmd, "dh") || !strcmp(cmd, "df") || !strcmp(cmd, "dv") ||
        !strcmp(cmd, "th") || !strcmp(cmd, "tf") || !strcmp(cmd, "tb") ||
        !strcmp(cmd, "thr") || !strcmp(cmd, "tfr")) {

        if (deviceMode != DMA && deviceMode != DMA_AXI_S && deviceMode != AXI_BRIDGE) {
            LOGE("Error: DMA is not supported on this device.\n");
            return EXIT_DEVICE;
        }

        if (!strcmp(cmd, "dh"))
            return cmd_dma_single(cmd_argc, cmd_argv, deviceMode, DMA_DIR_H2F);
        if (!strcmp(cmd, "df"))
            return cmd_dma_single(cmd_argc, cmd_argv, deviceMode, DMA_DIR_F2H);
        if (!strcmp(cmd, "dv"))
            return cmd_dma_validate(cmd_argc, cmd_argv, deviceMode);

        if (!strcmp(cmd, "th"))
            return cmd_dma_throughput(cmd_argc, cmd_argv, deviceMode, DMA_DIR_H2F, false);
        if (!strcmp(cmd, "tf"))
            return cmd_dma_throughput(cmd_argc, cmd_argv, deviceMode, DMA_DIR_F2H, false);
        if (!strcmp(cmd, "tb"))
            return cmd_dma_throughput(cmd_argc, cmd_argv, deviceMode, DMA_DIR_H2F, true);

        if (!strcmp(cmd, "thr"))
            return cmd_dma_ring(cmd_argc, cmd_argv, deviceMode, DMA_DIR_H2F);
        if (!strcmp(cmd, "tfr"))
            return cmd_dma_ring(cmd_argc, cmd_argv, deviceMode, DMA_DIR_F2H);
    }

    LOGE("Unknown command: %s\n", cmd);
    cli_usage(argv[0]);
    return EXIT_USAGE;
}
