// SPDX-License-Identifier: MIT
/*
 * ==================================================================
 *
 * >>>>>>>>>>>>>>>>>>>>> COPYRIGHT NOTICE <<<<<<<<<<<<<<<<<<<<<<<<<
 * ------------------------------------------------------------------
 * Copyright (c) 2019-2024 by Lattice Semiconductor Corporation
 * ALL RIGHTS RESERVED
 * ------------------------------------------------------------------
 *
 * DISCLAIMER:
 *
 * LATTICE MAKES NO WARRANTIES ON THIS FILE OR ITS CONTENTS,
 * WHETHER EXPRESSED, IMPLIED, STATUTORY,
 * OR IN ANY PROVISION OF THE LATTICE PROPEL LICENSE AGREEMENT OR
 * COMMUNICATION WITH LICENSEE,
 * AND LATTICE SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
 * MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
 * LATTICE DOES NOT WARRANT THAT THE FUNCTIONS CONTAINED HEREIN WILL MEET
 * LICENSEE 'S REQUIREMENTS, OR THAT LICENSEE' S OPERATION OF ANY DEVICE,
 * SOFTWARE OR SYSTEM USING THIS FILE OR ITS CONTENTS WILL BE
 * UNINTERRUPTED OR ERROR FREE,
 * OR THAT DEFECTS HEREIN WILL BE CORRECTED.
 * LICENSEE ASSUMES RESPONSIBILITY FOR SELECTION OF MATERIALS TO ACHIEVE
 * ITS INTENDED RESULTS, AND FOR THE PROPER INSTALLATION, USE,
 * AND RESULTS OBTAINED THEREFROM.
 * LICENSEE ASSUMES THE ENTIRE RISK OF THE FILE AND ITS CONTENTS PROVING
 * DEFECTIVE OR FAILING TO PERFORM PROPERLY AND IN SUCH EVENT,
 * LICENSEE SHALL ASSUME THE ENTIRE COST AND RISK OF ANY REPAIR, SERVICE,
 * CORRECTION,
 * OR ANY OTHER LIABILITIES OR DAMAGES CAUSED BY OR ASSOCIATED WITH THE
 * SOFTWARE.IN NO EVENT SHALL LATTICE BE LIABLE TO ANY PARTY FOR DIRECT,
 * INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES,
 * INCLUDING LOST PROFITS,
 * ARISING OUT OF THE USE OF THIS FILE OR ITS CONTENTS,
 * EVEN IF LATTICE HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * LATTICE 'S SOLE LIABILITY, AND LICENSEE' S SOLE REMEDY,
 * IS SET FORTH ABOVE.
 * LATTICE DOES NOT WARRANT OR REPRESENT THAT THIS FILE,
 * ITS CONTENTS OR USE THEREOF DOES NOT INFRINGE ON THIRD PARTIES'
 * INTELLECTUAL PROPERTY RIGHTS, INCLUDING ANY PATENT. IT IS THE USER' S
 * RESPONSIBILITY TO VERIFY THE USER SOFTWARE DESIGN FOR CONSISTENCY AND
 * FUNCTIONALITY THROUGH THE USE OF FORMAL SOFTWARE VALIDATION METHODS.
 * ------------------------------------------------------------------
 *
 * ==================================================================
 */
#ifndef __PCIE_H__
#define __PCIE_H__

#include <linux/version.h>
#include <linux/interrupt.h>
#include <linux/pci.h>
#include <linux/kernel.h>
#include <linux/cdev.h>
#include "pcie_regs.h"

/* Include common definitions shared with user-space */
#include "../include/pcie_common.h"

/* Change these defines to increase number of boards supported by the driver */
#define NUM_BARS MAX_PCI_BARS
#define NUM_BOARDS 1           /* Only 1 board supported by the driver */
#define MAX_BOARDS (NUM_BOARDS)
#define MINORS_PER_BOARD 1     /* 1 minor number per discrete device */
#define MAX_MINORS (MAX_BOARDS * MINORS_PER_BOARD)

// NOTE: these assume the first minor number is always 0, which is probably safe ;-)
#define MINOR_TO_BOARD(a)     (a / MINORS_PER_BOARD)
#define MINOR_TO_FUNCTION(a)  (a & (MINORS_PER_BOARD - 1))

#define VENDOR_ID   0x1204
#define DEVICE_ID   0x9C25

#define MAX_NUM_MSI_VEC 4

#define BAR0 0
#define BAR1 1

/**
 * @struct PCI_Dev_BAR
 * @brief Represents a PCI device's Base Address Register (BAR) details.
 *
 * @member pci_addr Physical bus address of the BAR (assigned by the PCI system), used in mmap.
 * @member kvm_addr Virtual address of the BAR mapped into kernel space, used in ioremap.
 * @member len Length of the BAR region.
 * @member pci_start Start address of the BAR, gathered from pci_resource_*().
 * @member pci_end End address of the BAR, gathered from pci_resource_*().
 * @member pci_flags Flags associated with the BAR, gathered from pci_resource_*().
 * @member bar Index of the BAR.
 * @member memType Memory type of the BAR (e.g., I/O or memory-mapped).
 * @member dataSize Size of the data associated with the BAR.
 */
struct PCI_Dev_BAR {
	void *pci_addr; /* the physical bus address of the BAR (assigned by PCI system), used in mmap */
	void *kvm_addr; /* the virtual address of a BAR mapped into kernel space, used in ioremap */
	uint64_t len;
	uint64_t pci_start;   /* info gathered from pci_resource_*() */
	uint64_t pci_end;
	uint64_t pci_flags;
	int bar;
	int memType;
	int dataSize;
};

/**
 * @struct PCIE_Board
 * @brief Represents a PCIe board with device information, and control settings.
 *
 * This structure encapsulates the details of a PCIe board, PCI device
 * information, control BAR addresses, and various configuration parameters.
 *
 * @member pdev Pointer to the PCI device structure associated with the board.
 * @member cdev Character device structure for the PCIe board.
 * @member ctrlBARaddr Array of pointers to control BAR addresses.
 * @member Dev_BARs Array of BAR (Base Address Register) configurations for the device.
 * @member PCICfgRegs Array of PCI configuration registers.
 * @member ID Unique identifier for the PCIe board.
 * @member demoID Identifier for the demo application running on the board.
 * @member function PCIe function number of the board.
 * @member OpenToken Atomic variable to track the open state of the board.
 * @member majorNum Major device number for the PCIe board.
 * @member minorNum Minor device number for the PCIe board.
 * @member PCIeMaxPayloadSize Maximum payload size supported by the PCIe board.
 * @member PCIeMaxReadReqSize Maximum read request size supported by the PCIe board.
 * @member PCIeRCBSize Read Completion Boundary size for the PCIe board.
 * @member PCIeLinkWidth PCIe link width (number of lanes) for the board.
 * @member irq_vec Array of interrupt vector numbers allocated for the board.
 * @member num_irqs Number of interrupt vectors allocated for the board.
 * @member IRQ Interrupt request line associated with the PCIe board.
 * @member numBars Number of BARs (Base Address Registers) available on the board.
 * @member mmapBAR BAR number used for memory mapping.
 * @member ctrlBAR BAR number used for control operations.
 * @member msi Indicates whether MSI (Message Signaled Interrupts) is enabled.
 * @member msix Indicates whether MSI-X (Extended Message Signaled Interrupts) is enabled.
 */
struct PCIE_Board {
	struct pci_dev *pdev;
	struct cdev cdev;
	void *ctrlBARaddr[NUM_BARS];
	struct PCI_Dev_BAR Dev_BARs[NUM_BARS];
	uint32_t PCICfgRegs[256/4];
	uint32_t ID;
	uint32_t function;
	atomic_t OpenToken;
	uint32_t majorNum;
	uint32_t minorNum;
	uint32_t PCIeMaxPayloadSize;
	uint32_t PCIeMaxReadReqSize;
	uint32_t PCIeRCBSize;
	uint32_t PCIeLinkWidth;
	uint32_t irq_vec[32];
	uint32_t num_irqs;
	uint32_t IRQ;
	uint8_t numBars;
	uint8_t mmapBAR;
	uint8_t ctrlBAR;
	bool msi;
	bool msix;
};


/**
 * @struct PCIE
 * @brief Main driver structure for managing PCIe boards.
 *
 * @member Board Array of PCIe boards managed by the driver.
 * @member sysfs Top entry point of pcie_lattice in /sys/class.
 * @member drvrDevNum Starting [MAJOR][MINOR] device number for this driver.
 * @member numBoards Total number of boards controlled by the driver.
 */
struct PCIE {
	struct PCIE_Board Board[NUM_BOARDS];
	struct class *sysfs;
	dev_t drvrDevNum;
	uint8_t numBoards;
};

#endif //__PCIE_H__
