// SPDX-License-Identifier: MIT
/*   ==================================================================

    >>>>>>>>>>>>>>>>>>>>>>> COPYRIGHT NOTICE <<<<<<<<<<<<<<<<<<<<<<<<<
    ------------------------------------------------------------------
    Copyright (c) 2025 by Lattice Semiconductor Corporation
    ALL RIGHTS RESERVED
    ------------------------------------------------------------------

    DISCLAIMER:

   LATTICE MAKES NO WARRANTIES ON THIS FILE OR ITS CONTENTS,
   WHETHER EXPRESSED, IMPLIED, STATUTORY,
   OR IN ANY PROVISION OF THE LATTICE PROPEL LICENSE AGREEMENT OR
   COMMUNICATION WITH LICENSEE,
   AND LATTICE SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
   MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
   LATTICE DOES NOT WARRANT THAT THE FUNCTIONS CONTAINED HEREIN WILL MEET
   LICENSEE 'S REQUIREMENTS, OR THAT LICENSEE' S OPERATION OF ANY DEVICE,
   SOFTWARE OR SYSTEM USING THIS FILE OR ITS CONTENTS WILL BE
   UNINTERRUPTED OR ERROR FREE,
   OR THAT DEFECTS HEREIN WILL BE CORRECTED.
   LICENSEE ASSUMES RESPONSIBILITY FOR SELECTION OF MATERIALS TO ACHIEVE
   ITS INTENDED RESULTS, AND FOR THE PROPER INSTALLATION, USE,
   AND RESULTS OBTAINED THEREFROM.
   LICENSEE ASSUMES THE ENTIRE RISK OF THE FILE AND ITS CONTENTS PROVING
   DEFECTIVE OR FAILING TO PERFORM PROPERLY AND IN SUCH EVENT,
   LICENSEE SHALL ASSUME THE ENTIRE COST AND RISK OF ANY REPAIR, SERVICE,
   CORRECTION,
   OR ANY OTHER LIABILITIES OR DAMAGES CAUSED BY OR ASSOCIATED WITH THE
   SOFTWARE.IN NO EVENT SHALL LATTICE BE LIABLE TO ANY PARTY FOR DIRECT,
   INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES,
   INCLUDING LOST PROFITS,
   ARISING OUT OF THE USE OF THIS FILE OR ITS CONTENTS,
   EVEN IF LATTICE HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
   LATTICE 'S SOLE LIABILITY, AND LICENSEE' S SOLE REMEDY,
   IS SET FORTH ABOVE.
   LATTICE DOES NOT WARRANT OR REPRESENT THAT THIS FILE,
   ITS CONTENTS OR USE THEREOF DOES NOT INFRINGE ON THIRD PARTIES'
   INTELLECTUAL PROPERTY RIGHTS, INCLUDING ANY PATENT. IT IS THE USER' S
   RESPONSIBILITY TO VERIFY THE USER SOFTWARE DESIGN FOR CONSISTENCY AND
   FUNCTIONALITY THROUGH THE USE OF FORMAL SOFTWARE VALIDATION METHODS.
    ------------------------------------------------------------------

    ================================================================== */

#ifndef __PCIE_IF_H__
#define __PCIE_IF_H__

#include <unistd.h>
#include <syslog.h>
#include <iostream>
#include <cstdint>
#include <vector>
#include <exception>

/* Include common definitions shared with kernel driver */
#include "../include/pcie_common.h"

using namespace std;

/* User-space specific definitions */
#define MAX_DEV_FILENAME_SIZE 1024  
#define MAX_FUNCTION_NAME_SIZE 64   
#define MAX_FRIENDLY_NAME_SIZE 32

#define ERRORSTR(a) syslog(LOG_ERR, "%s", a); cout<<a

#define LINE_BUFFER_SIZE 256

#define PCI_CFG_START 0x00
#define PCI_CFG_END 0x40
#define PCI_CAP_START 0x40
#define PCI_CAP_END 0xc0

typedef int HANDLE;

/**
 * @brief PCIE Interface Class
 *
 * This class provides the actual basic read/write access to hardware registers.
 * This class implements the only the common methods used by all PCIe driver interfaces.
 *
 * @note The actual implementation details are not provided here.
 */
class PCIE_IF
{

public:
    PCIE_IF(const char *pDeviceName);

    ~PCIE_IF();
    int getFileDescriptor() const { return hDev; }
    bool getPCIConfigRegs(uint8_t *pCfg);
    int getPCIeDeviceMode();
    bool getPCIBarInfo(struct PCIResourceInfo *pInfo);
    void setUserIntMSIVector(uint8_t usr_vec_num, uint8_t vec_val);

    uint8_t readReg8(uint32_t offset);
    void writeReg8(uint32_t offset, uint8_t val);
    uint16_t readReg16(uint32_t offset);
    void writeReg16(uint32_t offset, uint16_t val);
    uint32_t readReg32(uint32_t aoffsetddr);
    void writeReg32(uint32_t offset, uint32_t val);
    uint64_t readReg64(uint32_t offset);
    void writeReg64(uint32_t offset, uint64_t val);
    uint8_t read8(uint8_t bar_num, uint32_t offset);
    void write8(uint8_t bar_num, uint32_t offset, uint8_t val);
    uint16_t read16(uint8_t bar_num, uint32_t offset);
    void write16(uint8_t bar_num, uint32_t offset, uint16_t val);
    uint32_t read32(uint8_t bar_num, uint32_t offset);
    void write32(uint8_t bar_num, uint32_t offset, uint32_t val);
    uint64_t read64(uint8_t bar_num, uint32_t offset);
    void write64(uint8_t bar_num, uint32_t offset, uint64_t val);
    uint8_t readConfig8(uint32_t offset);
    void writeConfig8(uint32_t offset, uint8_t val);  
    uint16_t readConfig16(uint32_t offset);
    void writeConfig16(uint32_t offset, uint16_t val);  
    uint32_t readConfig32(uint32_t offset);
    void writeConfig32(uint32_t offset, uint32_t val);    

    
    /* Block Access Methods */
    bool readBlock8(uint8_t bar_num, uint32_t offset, std::vector<uint8_t> &val, size_t len, bool incAddr=true);
    bool writeBlock8(uint8_t bar_num, uint32_t offset, const std::vector<uint8_t> &val, size_t len, bool incAddr=true);
    bool readBlock16(uint8_t bar_num, uint32_t offset, std::vector<uint16_t> &val, size_t len, bool incAddr=true);
    bool writeBlock16(uint8_t bar_num, uint32_t offset, const std::vector<uint16_t> &val, size_t len, bool incAddr=true);
    bool readBlock32(uint8_t bar_num, uint32_t offset, std::vector<uint32_t> &val, size_t len, bool incAddr=true);
    bool writeBlock32(uint8_t bar_num, uint32_t offset, const std::vector<uint32_t> &val, size_t len, bool incAddr=true);
    bool readBlock64(uint8_t bar_num, uint32_t offset, std::vector<uint64_t> &val, size_t len, bool incAddr=true);
    bool writeBlock64(uint8_t bar_num, uint32_t offset, const std::vector<uint64_t> &val, size_t len, bool incAddr=true);

protected:
    HANDLE hDev;
    struct PCIResourceInfo PCIinfo;
private:

};


/**
 * Exception class for objects in the Lattice PCIe driver module.
 * This type of exception is thrown if an occurs deep in the
 * driver code and execution can not continue.  The top-level
 * code can determine the exception cause by displaying the
 * char string returned by the what() method.
 */
class PCIE_IF_Error : public exception 
{ 
    public:
        PCIE_IF_Error(char *s) {msg = s;}
        virtual const char *what(void) const throw()
        {
            return(msg);
        }

    private:
        char *msg;
        
};

#endif


