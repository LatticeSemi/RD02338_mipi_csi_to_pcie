/* SPDX-License-Identifier: MIT */
/*
 *   ==================================================================
 *
 *     >>>>>>>>>>>>>>>>>>>>>>> COPYRIGHT NOTICE <<<<<<<<<<<<<<<<<<<<<<<<<
 *     ------------------------------------------------------------------
 *     Copyright (c) 2026 by Lattice Semiconductor Corporation
 *     ALL RIGHTS RESERVED
 *     ------------------------------------------------------------------
 *
 *     DISCLAIMER:
 *
 *    LATTICE MAKES NO WARRANTIES ON THIS FILE OR ITS CONTENTS,
 *    WHETHER EXPRESSED, IMPLIED, STATUTORY,
 *    OR IN ANY PROVISION OF THE LATTICE PROPEL LICENSE AGREEMENT OR
 *    COMMUNICATION WITH LICENSEE,
 *    AND LATTICE SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
 *    MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
 *    LATTICE DOES NOT WARRANT THAT THE FUNCTIONS CONTAINED HEREIN WILL MEET
 *    LICENSEE 'S REQUIREMENTS, OR THAT LICENSEE' S OPERATION OF ANY DEVICE,
 *    SOFTWARE OR SYSTEM USING THIS FILE OR ITS CONTENTS WILL BE
 *    UNINTERRUPTED OR ERROR FREE,
 *    OR THAT DEFECTS HEREIN WILL BE CORRECTED.
 *    LICENSEE ASSUMES RESPONSIBILITY FOR SELECTION OF MATERIALS TO ACHIEVE
 *    ITS INTENDED RESULTS, AND FOR THE PROPER INSTALLATION, USE,
 *    AND RESULTS OBTAINED THEREFROM.
 *    LICENSEE ASSUMES THE ENTIRE RISK OF THE FILE AND ITS CONTENTS PROVING
 *    DEFECTIVE OR FAILING TO PERFORM PROPERLY AND IN SUCH EVENT,
 *    LICENSEE SHALL ASSUME THE ENTIRE COST AND RISK OF ANY REPAIR, SERVICE,
 *    CORRECTION,
 *    OR ANY OTHER LIABILITIES OR DAMAGES CAUSED BY OR ASSOCIATED WITH THE
 *    SOFTWARE.IN NO EVENT SHALL LATTICE BE LIABLE TO ANY PARTY FOR DIRECT,
 *    INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES,
 *    INCLUDING LOST PROFITS,
 *    ARISING OUT OF THE USE OF THIS FILE OR ITS CONTENTS,
 *    EVEN IF LATTICE HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 *    LATTICE 'S SOLE LIABILITY, AND LICENSEE' S SOLE REMEDY,
 *    IS SET FORTH ABOVE.
 *    LATTICE DOES NOT WARRANT OR REPRESENT THAT THIS FILE,
 *    ITS CONTENTS OR USE THEREOF DOES NOT INFRINGE ON THIRD PARTIES'
 *    INTELLECTUAL PROPERTY RIGHTS, INCLUDING ANY PATENT. IT IS THE USER' S
 *    RESPONSIBILITY TO VERIFY THE USER SOFTWARE DESIGN FOR CONSISTENCY AND
 *    FUNCTIONALITY THROUGH THE USE OF FORMAL SOFTWARE VALIDATION METHODS.
 *     ------------------------------------------------------------------
 *
 *     ==================================================================
 */
#ifndef LSC_PCIE_H
#define LSC_PCIE_H

/* Include appropriate headers based on kernel vs userspace */
#ifdef __KERNEL__
    #include <linux/types.h>
    #include <linux/ioctl.h>
#else
    #include <stdint.h>
    #include <stdbool.h>
    #include <sys/ioctl.h>
#endif

/* Shared driver name macro for both kernel module and user-space interface */
#define PCIE_DRIVER_NAME "lscpcie_dma"

/* Driver version - appears in modinfo output, accessible to both kernel and userspace */
#define DRV_MODULE_VERSION "26.01.00"

/* Common constants */
#ifndef MAX_PCI_BARS
#define MAX_PCI_BARS 6
#endif

/* DMA xfer: per-buffer length must be non-zero and a multiple of this (dword) */
/* see validate_dma_xfer_params */
#define DMA_XFER_LEN_ALIGN		4U
/* FPGA device offset for DMA must be a multiple of this (8 doublewords) */
#define DMA_FPGA_ADDR_8DW_ALIGN		32U

#define PCIE_MAGIC 'Z'

/**
 * @brief PCIE IOCTL Definitions
 *
 * This section defines various IOCTL commands used for PCIE communication.
 * Each command corresponds to a specific operation or configuration.
 * These definitions are shared between kernel driver and user-space library.
 */
#define IOCTL_PCIE_GET_DEVICE_MODE               _IOR(PCIE_MAGIC, 0, int)
#define IOCTL_PCIE_READ_8BIT                     _IOR(PCIE_MAGIC, 1, int)
#define IOCTL_PCIE_READ_16BIT                    _IOR(PCIE_MAGIC, 2, int)
#define IOCTL_PCIE_READ_32BIT                    _IOR(PCIE_MAGIC, 3, int)
#define IOCTL_PCIE_READ_64BIT                    _IOR(PCIE_MAGIC, 4, int)
#define IOCTL_PCIE_GET_RESOURCES                 _IOR(PCIE_MAGIC, 5, struct PCIResourceInfo)
#define IOCTL_PCIE_WRITE_8BIT                    _IOW(PCIE_MAGIC, 6, int)
#define IOCTL_PCIE_WRITE_16BIT                   _IOW(PCIE_MAGIC, 7, int)
#define IOCTL_PCIE_WRITE_32BIT                   _IOW(PCIE_MAGIC, 8, int)
#define IOCTL_PCIE_WRITE_64BIT                   _IOW(PCIE_MAGIC, 9, int)
#define IOCTL_PCIE_CFG_REG_READ_8Bit             _IOR(PCIE_MAGIC, 10, int)
#define IOCTL_PCIE_CFG_REG_WRITE_8Bit            _IOWR(PCIE_MAGIC, 11, int)
#define IOCTL_PCIE_CFG_REG_READ_16Bit            _IOR(PCIE_MAGIC, 12, int)
#define IOCTL_PCIE_CFG_REG_WRITE_16Bit           _IOWR(PCIE_MAGIC, 13, int)
#define IOCTL_PCIE_CFG_REG_READ_32Bit            _IOR(PCIE_MAGIC, 14, int)
#define IOCTL_PCIE_CFG_REG_WRITE_32Bit           _IOWR(PCIE_MAGIC, 15, int)
#define IOCTL_PCIE_GET_CAP_LIST                  _IOR(PCIE_MAGIC, 16, pci_cap_list_add_t)
#define IOCTL_PCIE_USR_VEC_ALLOC                 _IOW(PCIE_MAGIC, 17, struct usr_vec_data)
#define IOCTL_PCIEDMA_GEN_DESC                   _IOW(PCIE_MAGIC, 18, struct dma_ubuf_ioctl_arg)
#define IOCTL_PCIEDMA_START_WAIT_COMPLETION      _IOWR(PCIE_MAGIC, 19, struct dma_status_ioctl_arg)
#define IOCTL_PCIEDMA_STATUS_CHECK               _IOWR(PCIE_MAGIC, 20, struct dma_status_ioctl_arg)
#define IOCTL_PCIEDMA_CLEANUP                    _IOW(PCIE_MAGIC, 21, uint8_t)
#define IOCTL_PCIEDMA_MEAS_THROUGHPUT            _IOWR(PCIE_MAGIC, 22, struct dma_throughput_ioctl_arg)
#define IOCTL_PCIEDMA_START                      _IOW(PCIE_MAGIC, 23, uint8_t)
#define IOCTL_PCIEDMA_STOP                       _IOW(PCIE_MAGIC, 24, uint8_t)
#define IOCTL_PCIEDMA_GET_DESC_INFO              _IOWR(PCIE_MAGIC, 25, struct dma_desc_info_ioctl_arg)

/**
 * struct usr_vec_data - User interrupt vector data
 * @usr_int: User interrupt enable/disable flag
 * @vec_val: Interrupt vector value
 *
 * This structure is used to pass interrupt vector information
 * between user-space and the driver.
 */
struct usr_vec_data {
	uint8_t usr_int;
	uint8_t vec_val;
};

/**
 * @struct rw_ioctl
 * @brief Represents arguments for a PCIe read/write IOCTL operation.
 *
 * @param value Value to be read or written.
 * @param reg Register offset for the operation.
 * @param bar_num BAR number associated with the operation.
 */
struct rw_ioctl {
	uint64_t value;
	uint32_t reg;
	uint8_t bar_num;
};

/**
 * @struct PCI_BAR
 * @brief Represents a PCI Base Address Register (BAR).
 *
 * @param physStartAddr Physical start address of the BAR.
 * @param nBAR Index of the BAR.
 * @param size Size of the BAR region (0 if unused).
 * @param flags pci_resource_flags() (Linux IORESOURCE_* in kernel).
 * @param memMapped Driver mapped this BAR (pci_ioremap_bar).
 */
struct PCI_BAR {
	uint64_t physStartAddr;
	uint32_t nBAR;
	uint32_t size;
	uint32_t flags;
	bool memMapped;
};

/**
 * @struct PCIResourceInfo
 * @brief Represents PCI resource information for a device.
 *
 * @param BAR Array of Base Address Registers (BARs) for the PCI device.
 * @param PCICfgReg Array of PCI configuration registers.
 * @param numBARs Count of PCI BARs with non-zero resource (available to map).
 * @param intrVector Interrupt vector assigned to the PCI device.
 * @param hasInterrupt Indicates if the PCI device has an interrupt capability.
 * @param bus PCI bus number.
 * @param device PCI device number.
 * @param function PCI function number.
 */
struct PCIResourceInfo {
	struct PCI_BAR BAR[MAX_PCI_BARS];
	uint8_t PCICfgReg[256];
	uint32_t numBARs;
	uint32_t intrVector;
	uint8_t bus;
	uint8_t device;
	uint8_t function;
	bool hasInterrupt;
};

/**
 * @enum deviceMode_t
 * @brief PCIe device modes
 *
 * Defines the different modes that the PCIe device can operate in.
 * This enum is shared between kernel driver and userspace applications.
 */
typedef enum {
	TLP = 1,     /* TLP (Transaction Layer Packet) mode */
	BRIDGE_MSI,  /* Bridge mode with MSI */
	BRIDGE_MSIX, /* Bridge mode with MSI-X */
	AXI_BRIDGE,
	DMA,         /* DMA mode */
	DMA_AXI_S    /* DMA AXI S mode */
} deviceMode_t;

/**
 * @brief DMA transfer direction enumeration
 *
 * Specifies the direction of DMA transfers between host and FPGA.
 */
enum dma_direction {
	DMA_DIR_H2F,       /* Host to FPGA */
	DMA_DIR_F2H,       /* FPGA to Host */
	NUM_DMA_DIRECTIONS /* must be last -- used for direction validation */
};

// IOCTL Operations.
/**
 * @struct dma_ubuf_ioctl_arg
 * @brief Represents arguments for a DMA buffer operation.
 *
 * @param addr Address of the DMA buffer.
 * @param len Length of the DMA buffer.
 * @param buf_cnt Number of buffers.
 * @param dir Direction of the DMA operation.
 * @param circ_buf Circular buffer flag.
 * @param fpga_addr FPGA offset address (must be 32-byte / 8-DW aligned).
 * @param len Per-buffer length (non-zero, 4-byte / dword aligned).
 */
struct dma_ubuf_ioctl_arg {
	void **addr;
	uint64_t fpga_addr;
	size_t len;   /* per buf must has the same size*/
	int buf_cnt;
	uint8_t  dir;
	uint8_t  circ_buf;
};

struct dma_throughput_ioctl_arg {
	uint64_t start_time_in_ns;
	uint64_t end_time_in_ns;
	int iterations;
	uint8_t dir;
};

struct dma_status_ioctl_arg {
	uint32_t timeout_ms; /* wait for dma_done; 0 = driver default (1000 ms) */
	uint32_t status_reg;
	uint32_t completed_desc_cnt;
	uint32_t expected_desc_cnt;
	uint8_t dir;
	bool dma_error;
};

/**
 * struct dma_desc_info_ioctl_arg - DMA descriptor counts (no HW desc table copy).
 *
 * Used for ring throughput (total_descriptors) and multi-buffer setup.
 *
 * @dir:                [in]  DMA_DIR_H2F or DMA_DIR_F2H.
 * @buf_idx:            [in]  User buffer index (0 .. ubuf_cnt-1).
 * @mapped_nents:       [out] HW descriptor count for @buf_idx.
 * @total_descriptors:  [out] Sum of descriptors across all buffers on this channel.
 * @ubuf_cnt:           [out] Number of user buffers currently mapped.
 * @circ_buffer_on:     [out] True if ring/circular-buffer mode is active (sanity check).
 */
struct dma_desc_info_ioctl_arg {
	uint8_t  dir;
	uint16_t buf_idx;

	uint32_t mapped_nents;
	uint32_t total_descriptors;
	uint16_t ubuf_cnt;
	bool     circ_buffer_on;
};

#endif /* LSC_PCIE_H */
