/* SPDX-License-Identifier: MIT */
/*
 * Lattice Semiconductor PCIe DMA Driver - DMA Engine Interface
 *
 * In-module API for the DMA engine library (lsc_pcie_dma.c).  These
 * functions are called from lsc_pcie_cdev.c and lsc_pcie_core.c within
 * lscpcie_dma.ko.  External software uses the char device and
 * ioctl definitions in include/lsc_pcie.h, not exported kernel symbols.
 *
 * Copyright (c) 2026 by Lattice Semiconductor Corporation
 * ALL RIGHTS RESERVED
 */

#ifndef __LSC_PCIE_DMA_H__
#define __LSC_PCIE_DMA_H__

#include "lsc_pcie_core.h"

/* desc_ctrl field bits */
#define DESC_CTRL_EOP 0x00000001
#define DESC_CTRL_INT 0x00000002

/* Contiguous descriptor count encoding in desc_ctrl bits[15:8] */
#define CONT_DESC_MAX 64
#define CONT_DESC_64  0

/**
 * struct dma_completion_result - Kernel-side DMA completion status.
 * @status_reg:         Raw DMA status register value at completion.
 * @completed_desc_cnt: Number of HW descriptors completed.
 * @expected_desc_cnt:  Number of HW descriptors submitted.
 * @error:              True if status_reg indicates a DMA error.
 */
struct dma_completion_result {
	u32  status_reg;
	u32  completed_desc_cnt;
	u32  expected_desc_cnt;
	bool error;
};

/**
 * struct dma_irq_ops - Per-channel DMA IRQ dispatch callbacks.
 * @eop:      End-of-packet completion callback.
 * @desc_int: Descriptor interrupt completion callback.
 * @err:      DMA error callback.
 */
struct dma_irq_ops {
	void (*eop)(struct lsc_pcie *pBrd, enum dma_direction dir,
		    u32 status_reg, u32 comp_desc_cnt, void *priv);
	void (*desc_int)(struct lsc_pcie *pBrd, enum dma_direction dir,
			 u32 status_reg, u32 comp_desc_cnt, void *priv);
	void (*err)(struct lsc_pcie *pBrd, enum dma_direction dir,
		    u32 status_reg, void *priv);
};

/* H2F DMA status register fields, mapped from H2F_DMA_STS hardware bits. */
struct h2f_dma_sts {
	u32 rsvd;
	bool dma_len_err;
	bool h2f_dest_addr_err;
	bool h2f_src_addr_err;
	bool desc_addr_err;
	bool axi_write_err;
	bool h2f_cplto_err;
	bool h2f_cpl_err;
	bool desc_cplto_err;
	bool desc_cpl_err;
	bool dma_int_done;
	bool dma_eop_done;
	bool busy;
};

/* F2H DMA status register fields, mapped from F2H_DMA_STS hardware bits. */
struct f2h_dma_sts {
	u32 rsvd;
	bool axi_st_data_l_err;
	bool axi_st_data_s_err;
	bool dma_len_err;
	bool f2h_dest_addr_err;
	bool f2h_src_addr_err;
	bool desc_addr_err;
	bool axi_read_err;
	u8 rsvd_2;
	bool desc_cplto_err;
	bool desc_cpl_err;
	bool dma_int_done;
	bool dma_eop_done;
	bool busy;
};

/* ---- DMA register I/O (inline, usable by any translation unit) ---- */

/**
 * dma_read_reg32 - Read a 32-bit register from the DMA register BAR.
 * @pBrd: Board context.
 * @offset: Byte offset within the DMA register region.
 *
 * Return: The 32-bit register value.
 */
static inline u32 dma_read_reg32(struct lsc_pcie *pBrd, u32 offset)
{
	return readl(pBrd->dma.dma_reg_base + offset);
}

/**
 * dma_write_reg32 - Write a 32-bit register in the DMA register BAR.
 * @pBrd: Board context.
 * @offset: Byte offset within the DMA register region.
 * @val: Value to write.
 */
static inline void dma_write_reg32(struct lsc_pcie *pBrd, u32 offset, u32 val)
{
	writel(val, pBrd->dma.dma_reg_base + offset);
	/* Ensure MMIO write completes before subsequent operations */
	wmb();
}

/**
 * ctrl_read_reg32 - Read a 32-bit register from the control register BAR.
 * @pBrd: Board context.
 * @offset: Byte offset within the control register region.
 *
 * Return: The 32-bit register value.
 */
static inline u32 ctrl_read_reg32(struct lsc_pcie *pBrd, u32 offset)
{
	return readl(pBrd->dma.ctrl_reg_base + offset);
}

/**
 * ctrl_write_reg32 - Write a 32-bit register in the control register BAR.
 * @pBrd: Board context.
 * @offset: Byte offset within the control register region.
 * @val: Value to write.
 */
static inline void ctrl_write_reg32(struct lsc_pcie *pBrd, u32 offset, u32 val)
{
	writel(val, pBrd->dma.ctrl_reg_base + offset);
	/* Ensure MMIO write completes before subsequent operations */
	wmb();
}

/* ---- Buffer and descriptor management ---- */

/** @see validate_dma_xfer_params() in lsc_pcie_dma.c for full documentation. */
int  validate_dma_xfer_params(struct device *dev, u8 dir, int buf_cnt,
			      u64 fpga_addr, size_t len);
/** @see dma_ubuf_map() in lsc_pcie_dma.c for full documentation. */
int  dma_ubuf_map(struct lsc_pcie *pBrd, void **uaddr, int len,
		  int buf_cnt, enum dma_direction direction);
/** @see dma_ubuf_unmap() in lsc_pcie_dma.c for full documentation. */
void dma_ubuf_unmap(struct lsc_pcie *pBrd, enum dma_direction direction);
/** @see dma_gen_desc() in lsc_pcie_dma.c for full documentation. */
int  dma_gen_desc(struct lsc_pcie *pBrd, enum dma_direction dir,
		  u64 fpga_addr, u8 circ_buff);
/** @see dma_desc_free() in lsc_pcie_dma.c for full documentation. */
void dma_desc_free(struct lsc_pcie *pBrd, enum dma_direction direction);
/** @see dma_xfer_cleanup() in lsc_pcie_dma.c for full documentation. */
void dma_xfer_cleanup(struct lsc_pcie *pBrd, enum dma_direction direction);

/* ---- Transfer control ---- */

/** @see dma_start() in lsc_pcie_dma.c for full documentation. */
int dma_start(struct lsc_pcie *pBrd, enum dma_direction direction);
/** @see dma_stop() in lsc_pcie_dma.c for full documentation. */
int dma_stop(struct lsc_pcie *pBrd, enum dma_direction direction);
/** @see dma_start_and_wait() in lsc_pcie_dma.c for full documentation. */
int dma_start_and_wait(struct lsc_pcie *pBrd, enum dma_direction direction,
		       u32 timeout_ms, const struct dma_irq_ops *ops,
		       void *ops_priv, struct dma_completion_result *result);

/* ---- DMA status ---- */

/** @see dma_get_h2f_dma_status() in lsc_pcie_dma.c for full documentation. */
struct h2f_dma_sts dma_get_h2f_dma_status(struct lsc_pcie *pBrd);
/** @see dma_get_f2h_dma_status() in lsc_pcie_dma.c for full documentation. */
struct f2h_dma_sts dma_get_f2h_dma_status(struct lsc_pcie *pBrd);
/** @see dma_status_has_error() in lsc_pcie_dma.c for full documentation. */
bool dma_status_has_error(struct lsc_pcie *pBrd, u32 status_reg);
/** @see dma_status_check() in lsc_pcie_dma.c for full documentation. */
int  dma_status_check(struct lsc_pcie *pBrd,
		      struct dma_status_ioctl_arg *status);

/* ---- Throughput measurement ---- */

/** @see dma_measure_throughput_chained() in lsc_pcie_dma.c for full documentation. */
int  dma_measure_throughput_chained(struct lsc_pcie *pBrd,
				    struct dma_throughput_ioctl_arg *throughput_arg);

/* ---- DMA IRQ dispatch ops registration ---- */

/** @see pcie_register_dma_irq_ops() in lsc_pcie_dma.c for full documentation. */
void pcie_register_dma_irq_ops(struct lsc_pcie *pBrd, enum dma_direction dir,
			       const struct dma_irq_ops *ops, void *priv);
/** @see pcie_unregister_dma_irq_ops() in lsc_pcie_dma.c for full documentation. */
void pcie_unregister_dma_irq_ops(struct lsc_pcie *pBrd,
				 enum dma_direction dir);
/** Default IRQ ops: wakes waiters on EOP, logs errors. */
extern const struct dma_irq_ops dma_irq_default_ops;

/* ---- ISR top-halves (registered by core during MSI/MSI-X setup) ---- */

/** @see dma_f2h_irq_handler() in lsc_pcie_dma.c for full documentation. */
irqreturn_t dma_f2h_irq_handler(int irq, void *arg);
/** @see dma_h2f_irq_handler() in lsc_pcie_dma.c for full documentation. */
irqreturn_t dma_h2f_irq_handler(int irq, void *arg);
/** @see axi_bridge_err_irq_handler() in lsc_pcie_dma.c for full documentation. */
irqreturn_t axi_bridge_err_irq_handler(int irq, void *arg);

/* ---- MSI vector programming (DMA/ctrl regs) ---- */

/** @see lsc_program_dma_msi_vector() in lsc_pcie_dma.c for full documentation. */
void lsc_program_dma_msi_vector(struct lsc_pcie *pBrd);

/* ---- DMA interrupt mask programming ---- */

/** @see lsc_program_dma_irq_mask() in lsc_pcie_dma.c for full documentation. */
void lsc_program_dma_irq_mask(struct lsc_pcie *pBrd, enum dma_direction dir,
			      u32 mask);

#endif /* __LSC_PCIE_DMA_H__ */
