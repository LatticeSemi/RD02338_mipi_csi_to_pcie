/* SPDX-License-Identifier: MIT */
/*
 * Lattice Semiconductor PCIe DMA Driver - Character Device Interface
 *
 * Copyright (c) 2026 by Lattice Semiconductor Corporation
 * ALL RIGHTS RESERVED
 */

#ifndef __LSC_PCIE_CDEV_H__
#define __LSC_PCIE_CDEV_H__

#include "lsc_pcie_core.h"

/**
 * lsc_pcie_cdev_init - Allocate chrdev region and create sysfs class.
 *
 * Module-wide setup called once from module_init().  Registers a dynamic
 * major/minor range for up to MAX_MINORS device nodes and creates the
 * sysfs class used by device_create() in lsc_pcie_cdev_create().
 *
 * Return: 0 on success, negative errno on failure.
 */
int lsc_pcie_cdev_init(void);

/**
 * lsc_pcie_cdev_cleanup - Destroy sysfs class and free chrdev region.
 *
 * Module-wide teardown called once from module_exit().  Reverses
 * lsc_pcie_cdev_init() and destroys the IDA used for minor allocation.
 */
void lsc_pcie_cdev_cleanup(void);

/**
 * lsc_pcie_cdev_create - Create a character device node for one PCIe board.
 * @pBrd: Per-board state (struct lsc_cdev is embedded in struct lsc_pcie).
 * @pdev: PCI device used as the parent for device_create().
 *
 * Allocates a unique minor number, registers the cdev, and creates the
 * /dev/<DRV_MODULE_NAME>N sysfs node.  Called from probe after
 * lsc_pcie_device_open() succeeds.
 *
 * Return: 0 on success, negative errno on failure.
 */
int lsc_pcie_cdev_create(struct lsc_pcie *pBrd, struct pci_dev *pdev);

/**
 * lsc_pcie_cdev_destroy - Remove the character device node for one board.
 * @pBrd: Per-board state whose chrdev was created by lsc_pcie_cdev_create().
 *
 * Destroys the sysfs device entry, deletes the cdev, and frees the minor
 * number.  Called from remove before lsc_pcie_device_close().
 */
void lsc_pcie_cdev_destroy(struct lsc_pcie *pBrd);

#endif /* __LSC_PCIE_CDEV_H__ */
