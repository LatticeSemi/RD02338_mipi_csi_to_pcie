#!/bin/bash
./exedemo.sh -c rr -b 0 -o 0 -s 4
./exedemo.sh -c wr -b 1 -o 0 -s 4 -d 0x12345678
./exedemo.sh -c rr -b 1 -o 0 -s 4