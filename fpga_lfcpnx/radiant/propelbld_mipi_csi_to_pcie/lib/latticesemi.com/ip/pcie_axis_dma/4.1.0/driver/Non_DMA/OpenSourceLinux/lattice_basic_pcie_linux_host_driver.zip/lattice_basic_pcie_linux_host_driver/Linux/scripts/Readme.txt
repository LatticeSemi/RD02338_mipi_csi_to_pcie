To compile app, lib and driver:
Run "sudo ./compile.sh"

To load driver:
Run "sudo ./install_drv.sh"

To load demo application:
Run "./exedemo.sh"

