#!/bin/bash

# Function to display usage
usage() {
    echo "Usage:"
    echo "  $0                          No args: launches interactive menu"
    echo "  $0 -h|--help                Show this help message"
    echo "  $0 <command> [options]      Run a specific command"
    echo ""
    echo "Command (must be first argument, followed by its options):"
    echo "  rr       BAR read            -b bar_num -o offset -s size"
    echo "  wr       BAR write           -b bar_num -o offset -s size -d data"
    echo "  dh       H2F DMA             -s size [-a fpga_addr]"
    echo "  df       F2H DMA             -s size [-a fpga_addr]"
    echo "  dv       DMA data validate   -s size [-a fpga_addr]"
    echo "  th       H2F throughput      -s size -n iterations"
    echo "  tf       F2H throughput      -s size -n iterations"
    echo "  tb       Bidir throughput    -s size -n iterations"
    echo "  thr      H2F ring throughput -s size -n duration_sec"
    echo "  tfr      F2H ring throughput -s size -n duration_sec"
    echo "  cap      Print detailed PCI capabilities"
    echo ""
    echo "Options:"
    echo "  -q            Quiet mode (only print results, for automation)"
    echo "  -b bar_num    BAR number"
    echo "  -o offset     Register offset"
    echo "  -s size       Transfer size or register size"
    echo "  -d data       Data value to write"
    echo "  -a fpga_addr  FPGA address (default: 0)"
    echo "  -n count      Iterations or duration in seconds"
    echo ""
    echo "Examples:"
    echo "  $0 dh -s 0x1000 -a 0xe0"
    echo "  $0 th -q -s 0x20000 -n 5000"
    echo "  $0 rr -b 0 -o 0x118 -s 4"
    echo "  $0 wr -b 1 -o 0x118 -s 4 -d 0xabcd1234"
    exit "${1:-1}"
}

# Grab the command from the first positional argument
cmd="${1:-}"
if [ "$cmd" = "-h" ] || [ "$cmd" = "--help" ]; then
    usage 0
fi
if [ -n "$cmd" ] && [ "${cmd:0:1}" = "-" ]; then
    echo "Error: Command must come before options (got '$cmd')." >&2
    echo "       Example: $0 dh -q -s 0x1000" >&2
    usage
fi
if [ -n "$cmd" ]; then
    shift
fi

# Initialize optional arguments
quiet=""
bar_num=""
offset=""
size=""
data=""
fpga_addr=""
iterations=""

# Parse command line arguments
help=""
while getopts ":qhb:o:s:d:a:n:" opt; do
    case $opt in
        q) quiet="-q"
        ;;
        h) help="-h"
        ;;
        b) bar_num="$OPTARG"
        ;;
        o) offset="$OPTARG"
        ;;
        s) size="$OPTARG"
        ;;
        d) data="$OPTARG"
        ;;
        a) fpga_addr="$OPTARG"
        ;;
        n) iterations="$OPTARG"
        ;;
        \?) echo "Invalid option -$OPTARG" >&2
            usage
        ;;
        :) echo "Option -$OPTARG requires an argument." >&2
            usage
        ;;
    esac
done

# Pass -h through to pcie_app for per-command help; show script usage if no command
if [ -n "$help" ]; then
    if [ -n "$cmd" ]; then
        cd ../app_src || { echo "Error: Failed to cd to ../app_src"; exit 1; }
        ./pcie_app "$cmd" -h
        exit $?
    else
        usage 0
    fi
fi

# Reject unexpected positional arguments
shift $((OPTIND - 1))
if [ $# -gt 0 ]; then
    echo "Error: Unexpected argument(s): $*" >&2
    usage
fi

# Validate command and arguments
case $cmd in
    cap)
        ;;
    rr)
        if [ -z "$bar_num" ] || [ -z "$offset" ] || [ -z "$size" ]; then
            echo "Error: -b bar_num, -o offset, and -s size are required for $cmd command." >&2
            usage
        fi
        ;;
    wr)
        if [ -z "$bar_num" ] || [ -z "$offset" ] || [ -z "$size" ] || [ -z "$data" ]; then
            echo "Error: -b bar_num, -o offset, -s size, and -d data are required for wr command." >&2
            usage
        fi
        ;;
    dh|df|dv)
        if [ -z "$size" ]; then
            echo "Error: -s size is required for $cmd command." >&2
            usage
        fi
        ;;
    th|tf|tb)
        if [ -z "$size" ] || [ -z "$iterations" ]; then
            echo "Error: -s size and -n iterations are required for $cmd command." >&2
            usage
        fi
        ;;
    thr|tfr)
        if [ -z "$size" ] || [ -z "$iterations" ]; then
            echo "Error: -s size and -n duration_sec are required for $cmd command." >&2
            usage
        fi
        ;;
    "")
        if [ -n "$quiet" ]; then
            echo "Error: -q option requires a command." >&2
            usage
        fi
        echo "No command provided. Running pcie_app with default settings."
        ;;
    *)
        echo "Error: Unknown command '$cmd'." >&2
        usage
        ;;
esac

# Build argument list and execute
cd ../app_src || { echo "Error: Failed to cd to ../app_src"; exit 1; }

args=()
[ -n "$quiet" ] && args+=("$quiet")

case "$cmd" in
    cap)
        args+=("$cmd")
        ;;
    "")
        ;;
    rr)
        args+=("$cmd" -b "$bar_num" -o "$offset" -s "$size")
        ;;
    wr)
        args+=("$cmd" -b "$bar_num" -o "$offset" -s "$size" -d "$data")
        ;;
    dh|df|dv)
        args+=("$cmd" -s "$size")
        [ -n "$fpga_addr" ] && args+=(-a "$fpga_addr")
        ;;
    th|tf|tb|thr|tfr)
        args+=("$cmd" -s "$size" -n "$iterations")
        ;;
    *)
        echo "Error: Unknown command '$cmd'."
        usage
        ;;
esac

./pcie_app "${args[@]}"
exit $?
